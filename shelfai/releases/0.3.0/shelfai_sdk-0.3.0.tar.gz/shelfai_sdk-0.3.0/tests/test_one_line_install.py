"""``shelfai_sdk.wrap`` / ``install``: ShelfAI in one line, configured from the environment."""

from __future__ import annotations

import asyncio
import shlex
import sys
from types import SimpleNamespace

import pytest

import shelfai_sdk
from shelfai_sdk import integration as integration_module


class FakeShelf:
    created = 0

    def __init__(self, **kwargs):
        FakeShelf.created += 1
        self.kwargs = kwargs
        self.wrap_calls = 0
        self.replay_callback = None
        self.closed = False
        self.last_trace_id = None
        self.transport = SimpleNamespace(flushes=0)
        self.transport.flush = lambda: setattr(self.transport, "flushes", self.transport.flushes + 1)

    def wrap(self, client):
        self.wrap_calls += 1
        original = client.messages.create
        client.messages.create = lambda **kwargs: ("recorded", original(**kwargs))
        return client

    def set_replay(self, callback):
        self.replay_callback = callback

    def replay_app(self):
        shelf = self

        async def app(scope, receive, send):
            await send({"served_by": shelf, "callback": shelf.replay_callback})

        return app

    def close(self):
        self.closed = True


def provider_client():
    return SimpleNamespace(messages=SimpleNamespace(create=lambda **kwargs: kwargs))


class FakeApp:
    def __init__(self):
        self.routes = []
        self.shutdown_handlers = []

    def add_route(self, path, asgi, methods):
        self.routes.append((path, asgi, tuple(methods)))

    def add_event_handler(self, event, handler):
        self.shutdown_handlers.append((event, handler))


def configure(monkeypatch, **extra):
    monkeypatch.setenv("SHELFAI_API_KEY", "sk_shelfai_test")
    monkeypatch.setenv("SHELFAI_AGENT_ID", "agent-under-test")
    for name, value in extra.items():
        monkeypatch.setenv(name, value)


@pytest.fixture(autouse=True)
def fresh_shared_integration(monkeypatch):
    for name in integration_module._SHARED_SETTINGS:
        monkeypatch.delenv(name, raising=False)
    monkeypatch.setattr(integration_module, "_SHARED_SHELF_CLASS", FakeShelf)
    FakeShelf.created = 0
    integration_module._reset_shared()
    yield
    integration_module._reset_shared()


def test_unconfigured_wrap_hands_back_the_same_untouched_client():
    client = provider_client()
    original_create = client.messages.create

    assert shelfai_sdk.wrap(client) is client
    assert client.messages.create is original_create
    assert shelfai_sdk.last_trace_id() is None
    assert FakeShelf.created == 0


def test_configured_wrap_records_every_client_through_one_shelf(monkeypatch):
    configure(monkeypatch)
    first, second = provider_client(), provider_client()

    assert shelfai_sdk.wrap(first) is first
    assert shelfai_sdk.wrap(second) is second
    assert first.messages.create(model="m")[0] == "recorded"
    assert second.messages.create(model="m")[0] == "recorded"
    assert FakeShelf.created == 1
    assert shelfai_sdk.shared_integration().status.active


def test_wrapping_a_client_again_does_not_record_twice(monkeypatch):
    configure(monkeypatch)
    client = provider_client()

    shelfai_sdk.wrap(client)
    shelfai_sdk.wrap(client)

    assert shelfai_sdk.shared_integration().shelf.wrap_calls == 1
    assert client.messages.create(model="m") == ("recorded", {"model": "m"})


def test_settings_loaded_after_the_first_wrap_still_take_effect(monkeypatch):
    early = provider_client()
    assert shelfai_sdk.wrap(early) is early  # e.g. before load_dotenv()

    configure(monkeypatch)
    later = provider_client()
    shelfai_sdk.wrap(later)

    assert later.messages.create(model="m")[0] == "recorded"
    assert FakeShelf.created == 1


def test_an_active_integration_is_never_swapped_under_wrapped_clients(monkeypatch):
    configure(monkeypatch)
    client = provider_client()
    shelfai_sdk.wrap(client)
    shelf = shelfai_sdk.shared_integration().shelf

    monkeypatch.setenv("SHELFAI_AGENT_ID", "renamed-agent")
    shelfai_sdk.wrap(provider_client())

    assert shelfai_sdk.shared_integration().shelf is shelf
    assert not shelf.closed
    assert FakeShelf.created == 1


def test_a_wrap_failure_hands_back_the_original_client(monkeypatch):
    configure(monkeypatch)

    class BrokenShelf(FakeShelf):
        def wrap(self, client):
            client.messages.create = lambda **_kwargs: "half-wrapped"
            raise ValueError("provider adapter failed")

    monkeypatch.setattr(integration_module, "_SHARED_SHELF_CLASS", BrokenShelf)
    client = provider_client()
    original_create = client.messages.create

    assert shelfai_sdk.wrap(client) is client
    assert client.messages.create is original_create
    status = shelfai_sdk.shared_integration().status
    assert (status.reason, status.error_type) == ("wrap_failed", "ValueError")


def test_install_does_nothing_while_shelfai_is_unconfigured():
    app = FakeApp()

    shelfai_sdk.install(app)

    assert app.routes == []
    assert app.shutdown_handlers == []


def test_install_once_per_app_and_the_endpoint_follows_the_current_replay(monkeypatch):
    configure(monkeypatch)
    app = FakeApp()

    shelfai_sdk.install(app)
    shelfai_sdk.install(app)
    assert len(app.routes) == 1
    path, endpoint, methods = app.routes[0]
    assert (path, methods) == ("/shelfai/replay", ("POST",))
    assert len(app.shutdown_handlers) == 1

    def rerun_workflow():
        return "trace_replayed"

    # Replay named after install still reaches the mounted endpoint.
    shelfai_sdk.wrap(provider_client(), replay=rerun_workflow)
    sent = []

    async def send(message):
        sent.append(message)

    asyncio.run(endpoint({}, None, send))
    assert sent[0]["callback"] is rerun_workflow
    assert sent[0]["served_by"] is shelfai_sdk.shared_integration().shelf


def test_replay_script_runs_with_its_arguments_and_returns_the_run_trace(monkeypatch, tmp_path):
    configure(monkeypatch)
    marker = tmp_path / "ran.txt"
    script = tmp_path / "rerun.py"
    script.write_text(
        "import sys\n"
        "from pathlib import Path\n"
        "import shelfai_sdk\n"
        f"Path({str(marker)!r}).write_text(' '.join(sys.argv[1:]))\n"
        "shelfai_sdk.shared_integration().shelf.last_trace_id = 'trace_from_replay'\n"
        "raise SystemExit(0)\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("SHELFAI_REPLAY", "rerun.py --call-llm --topic 'two words'")
    argv_before = sys.argv[:]

    shelfai_sdk.wrap(provider_client())
    callback = shelfai_sdk.shared_integration().shelf.replay_callback

    assert callback() == "trace_from_replay"
    assert marker.read_text() == "--call-llm --topic two words"
    assert sys.argv == argv_before


def test_a_failing_replay_script_fails_the_replay_not_the_app(monkeypatch, tmp_path):
    configure(monkeypatch)
    (tmp_path / "broken.py").write_text("raise SystemExit(3)\n", encoding="utf-8")
    monkeypatch.chdir(tmp_path)

    shelfai_sdk.wrap(provider_client(), replay="broken.py")
    callback = shelfai_sdk.shared_integration().shelf.replay_callback

    with pytest.raises(RuntimeError, match="failure status"):
        callback()


@pytest.mark.parametrize(
    "command",
    [
        "-m agent_pkg.run --call-llm",
        "python -m agent_pkg.run --call-llm",
        "python3 agent_pkg/run.py --call-llm",
        f"{shlex.quote(sys.executable)} agent_pkg/run.py --call-llm",
    ],
)
def test_replay_accepts_the_ways_agents_are_usually_started(monkeypatch, tmp_path, command):
    configure(monkeypatch)
    for name in [name for name in sys.modules if name.split(".")[0] == "agent_pkg"]:
        monkeypatch.delitem(sys.modules, name)
    package = tmp_path / "agent_pkg"
    package.mkdir()
    (package / "__init__.py").write_text("", encoding="utf-8")
    marker = tmp_path / "ran.txt"
    (package / "run.py").write_text(
        "import sys\n"
        "from pathlib import Path\n"
        f"Path({str(marker)!r}).write_text(' '.join(sys.argv[1:]))\n",
        encoding="utf-8",
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(str(tmp_path))
    path_before = sys.path[:]

    shelfai_sdk.wrap(provider_client(), replay=command)
    shelfai_sdk.shared_integration().shelf.replay_callback()

    assert marker.read_text() == "--call-llm"
    assert sys.path == path_before


def test_a_missing_replay_script_keeps_recording(monkeypatch, tmp_path):
    configure(monkeypatch, SHELFAI_REPLAY="no-such-script.py")
    monkeypatch.chdir(tmp_path)
    client = provider_client()

    shelfai_sdk.wrap(client)

    assert client.messages.create(model="m")[0] == "recorded"
    assert shelfai_sdk.shared_integration().status.reason == "replay_not_configured"


def test_flush_and_last_trace_id_use_the_shared_integration(monkeypatch):
    shelfai_sdk.flush()  # unconfigured: nothing to flush, no error

    configure(monkeypatch)
    shelfai_sdk.wrap(provider_client())
    shelf = shelfai_sdk.shared_integration().shelf
    shelf.last_trace_id = "trace_latest"

    shelfai_sdk.flush()

    assert shelf.transport.flushes == 1
    assert shelfai_sdk.last_trace_id() == "trace_latest"


def test_auto_import_records_every_provider_client_created_afterwards(monkeypatch):
    import types

    class Anthropic:
        def __init__(self, api_key=None):
            self.api_key = api_key
            self.messages = SimpleNamespace(create=lambda **kwargs: kwargs)

    class OpenAI:
        def __init__(self):
            self.chat = SimpleNamespace(completions=SimpleNamespace(create=lambda **kwargs: kwargs))

    fake_anthropic = types.ModuleType("anthropic")
    fake_anthropic.Anthropic = Anthropic
    fake_openai = types.ModuleType("openai")
    fake_openai.OpenAI = OpenAI
    monkeypatch.setitem(sys.modules, "anthropic", fake_anthropic)
    monkeypatch.setitem(sys.modules, "openai", fake_openai)
    configure(monkeypatch)

    from shelfai_sdk import auto

    auto.enable()  # the first import may already have done this
    assert getattr(Anthropic.__init__, "__shelfai_auto__", False)
    assert getattr(OpenAI.__init__, "__shelfai_auto__", False)
    assert auto.enable() == []  # instrumenting twice is a no-op

    client = Anthropic(api_key="provider-key")
    assert client.api_key == "provider-key"
    assert client.messages.create(model="m")[0] == "recorded"
    assert shelfai_sdk.shared_integration().shelf.wrap_calls == 1


def test_auto_leaves_clients_alone_while_shelfai_is_unconfigured(monkeypatch):
    from shelfai_sdk import auto

    class Anthropic:
        def __init__(self):
            self.messages = SimpleNamespace(create=lambda **kwargs: kwargs)

    auto.instrument_class(Anthropic)
    client = Anthropic()

    assert client.messages.create(model="m") == {"model": "m"}
    assert FakeShelf.created == 0


def test_the_launcher_runs_a_script_like_python_does(monkeypatch, tmp_path):
    from shelfai_sdk import auto

    (tmp_path / "helper.py").write_text("VALUE = 'imported from the script folder'\n", encoding="utf-8")
    marker = tmp_path / "out.txt"
    script = tmp_path / "agent.py"
    script.write_text(
        "import sys\n"
        "import helper\n"
        "from pathlib import Path\n"
        f"Path({str(marker)!r}).write_text(helper.VALUE + ' ' + ' '.join(sys.argv[1:]))\n",
        encoding="utf-8",
    )
    monkeypatch.setattr(sys, "argv", ["python"])
    monkeypatch.setattr(sys, "path", list(sys.path))

    auto.run_script([str(script), "--call-llm"])
    assert marker.read_text() == "imported from the script folder --call-llm"

    monkeypatch.chdir(tmp_path)
    monkeypatch.syspath_prepend(str(tmp_path))
    auto.run_script(["-m", "agent", "--as-module"])
    assert marker.read_text() == "imported from the script folder --as-module"

    with pytest.raises(SystemExit, match="usage"):
        auto.run_script([])
