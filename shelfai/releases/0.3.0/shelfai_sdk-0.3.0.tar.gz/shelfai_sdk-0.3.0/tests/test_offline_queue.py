import os
import stat

import pytest

from shelfai_sdk import queue as queue_module
from shelfai_sdk.queue import OfflineQueue


def test_offline_queue_persists_rows(tmp_path):
    queue = OfflineQueue(str(tmp_path))
    queue.enqueue_many("agent-1", ['{"name":"a"}', '{"name":"b"}'], "2026-04-01T00:00:00Z")

    rows = queue.oldest(limit=10)
    assert len(rows) == 2


def test_offline_queue_marks_delivered(tmp_path):
    queue = OfflineQueue(str(tmp_path))
    queue.enqueue_many("agent-1", ['{"name":"a"}'], "2026-04-01T00:00:00Z")
    ids = [int(row["id"]) for row in queue.oldest(limit=10)]
    queue.mark_delivered(ids)

    assert queue.count() == 0


def _unwritable_root(tmp_path):
    blocker = tmp_path / "not-a-directory"
    blocker.write_text("", encoding="utf-8")
    return str(blocker / "queue")


@pytest.mark.skipif(not hasattr(os, "getuid"), reason="POSIX permissions")
def test_fallback_queue_folder_is_private_to_this_user(tmp_path, monkeypatch):
    fallback = tmp_path / "tmp" / "shelfai-sdk-test"
    monkeypatch.setattr(queue_module, "_fallback_queue_root", lambda: fallback)

    queue = OfflineQueue(_unwritable_root(tmp_path))

    assert queue.available
    assert queue.root == fallback / "queue"
    assert stat.S_IMODE(fallback.stat().st_mode) == 0o700


@pytest.mark.skipif(not hasattr(os, "getuid"), reason="POSIX permissions")
def test_a_loose_fallback_queue_folder_is_tightened(tmp_path, monkeypatch):
    fallback = tmp_path / "shelfai-sdk-test"
    fallback.mkdir()
    fallback.chmod(0o777)
    monkeypatch.setattr(queue_module, "_fallback_queue_root", lambda: fallback)

    assert OfflineQueue(_unwritable_root(tmp_path)).available
    assert stat.S_IMODE(fallback.stat().st_mode) == 0o700


def test_a_symlinked_fallback_queue_folder_is_refused(tmp_path, monkeypatch):
    elsewhere = tmp_path / "someone-elses"
    elsewhere.mkdir()
    fallback = tmp_path / "shelfai-sdk-test"
    fallback.symlink_to(elsewhere, target_is_directory=True)
    monkeypatch.setattr(queue_module, "_fallback_queue_root", lambda: fallback)

    queue = OfflineQueue(_unwritable_root(tmp_path))

    assert not queue.available
    assert not (elsewhere / "queue").exists()
