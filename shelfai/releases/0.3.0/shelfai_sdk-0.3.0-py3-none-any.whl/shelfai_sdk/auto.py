"""Record every Anthropic and OpenAI client the process creates: ``import shelfai_sdk.auto``.

Importing this module makes each new provider client pass through
:func:`shelfai_sdk.wrap`, so nothing else in the application changes. Like
``wrap``, it does nothing until SHELFAI_API_KEY and SHELFAI_AGENT_ID are set,
and a failure leaves the client exactly as the provider built it.

To record an agent without touching its code, start it through this module,
with the arguments you would give ``python``:
``python -m shelfai_sdk.auto path/to/script.py [args...]`` or
``python -m shelfai_sdk.auto -m package.module [args...]``.
"""

from __future__ import annotations

import functools
import importlib
import shlex
import sys
from typing import Any

from .integration import _python_entry_point, run_python_entry_point, wrap

PROVIDER_CLIENTS = (
    ("anthropic", "Anthropic"),
    ("anthropic", "AsyncAnthropic"),
    ("openai", "OpenAI"),
    ("openai", "AsyncOpenAI"),
    ("openai", "AzureOpenAI"),
    ("openai", "AsyncAzureOpenAI"),
)
_MARKER = "__shelfai_auto__"


def instrument_class(cls: Any) -> bool:
    """Wrap every instance of ``cls`` created from now on; False if already done."""

    original_init = cls.__init__
    if getattr(original_init, _MARKER, False):
        return False

    @functools.wraps(original_init)
    def __init__(self, *args: Any, **kwargs: Any) -> None:
        original_init(self, *args, **kwargs)
        wrap(self)

    setattr(__init__, _MARKER, True)
    cls.__init__ = __init__
    return True


def enable() -> list[str]:
    """Instrument whichever provider SDKs are installed; returns the classes patched."""

    patched: list[str] = []
    for module_name, class_name in PROVIDER_CLIENTS:
        try:
            cls = getattr(importlib.import_module(module_name), class_name)
            if instrument_class(cls):
                patched.append(f"{module_name}.{class_name}")
        except Exception:  # noqa: BLE001 - not installed, or an SDK version without it
            continue
    return patched


def run_script(argv: list[str]) -> None:
    """Start a script or module with recording on (``python -m shelfai_sdk.auto ...``).

    Takes the same arguments as ``python``: ``SCRIPT [ARGS...]`` or
    ``-m MODULE [ARGS...]``.
    """

    if not argv:
        raise SystemExit("usage: python -m shelfai_sdk.auto SCRIPT|-m MODULE [ARGS...]")
    kind, target, args = _python_entry_point(shlex.join(argv))
    run_python_entry_point(kind, target, args)


enable()

if __name__ == "__main__":
    run_script(sys.argv[1:])
