"""Fail-open, application-scoped ShelfAI integration helpers."""

from __future__ import annotations

import atexit
from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass
import inspect
import os
from pathlib import Path
import runpy
import shlex
import sys
import threading
from typing import Any, Callable, Optional, Type, Union
import weakref

from .generic_tools import wrap_tool, wrap_tools


_FALSE_VALUES = {"", "0", "false", "no", "off", "disabled"}


def _close_safely(shelf: Any) -> None:
    try:
        shelf.close()
    except Exception:
        pass


@dataclass
class IntegrationStatus:
    """Credential-free state suitable for logs and health endpoints."""

    requested: bool
    active: bool
    wrapped: bool
    reason: str
    error_type: Optional[str] = None


class _UnavailableReplayApp:
    """ASGI callable that answers 503 while ShelfAI is inactive."""

    async def __call__(self, _scope, _receive, send) -> None:
        body = b'{"error":"replay_unavailable"}'
        await send(
            {
                "type": "http.response.start",
                "status": 503,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode("ascii")),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


_unavailable_replay_app = _UnavailableReplayApp()


class ShelfAIIntegration:
    """Own one optional ShelfAI instance and its application lifecycle."""

    def __init__(
        self,
        *,
        client: Any,
        shelf: Any = None,
        status: IntegrationStatus,
    ) -> None:
        self.client = client
        self.shelf = shelf
        self.status = status
        self._closed = False
        self._finalizer = weakref.finalize(self, _close_safely, shelf) if shelf is not None else None
        self._installed_apps = _IdentitySet()

    def replay_app(self):
        """Return a mount-safe ASGI app that fails replay requests closed."""

        if self.shelf is None:
            return _UnavailableReplayApp()
        try:
            return self.shelf.replay_app()
        except Exception:
            return _UnavailableReplayApp()

    @property
    def last_trace_id(self) -> Optional[str]:
        """Trace ID of the most recent captured provider call, if any."""

        if self.shelf is None:
            return None
        return getattr(self.shelf, "last_trace_id", None)

    def install(self, app: Any, *, path: str = "/shelfai/replay", asgi: Any = None) -> "ShelfAIIntegration":
        """Attach the replay endpoint and shutdown flush to a Starlette/FastAPI app.

        The endpoint is registered as an exact ``POST`` route (no trailing-slash
        redirect, so the registered hook URL can be exactly ``.../shelfai/replay``)
        and telemetry is flushed when the application's lifespan ends. The call
        never raises: an application that cannot host the route keeps working.
        Installing on the same app again does nothing.
        """

        if not self._installed_apps.add(app):
            return self
        try:
            if asgi is None:
                asgi = self.replay_app()
            add_route = getattr(app, "add_route", None)
            if callable(add_route):
                add_route(path, asgi, methods=["POST"])
            else:
                mount = getattr(app, "mount", None)
                if callable(mount):
                    mount(path, asgi)
        except Exception as exc:  # noqa: BLE001 - fail open
            self.status.reason = "replay_route_not_installed"
            self.status.error_type = type(exc).__name__
        try:
            self._install_shutdown(app)
        except Exception as exc:  # noqa: BLE001 - fail open
            self.status.error_type = type(exc).__name__
        return self

    def _install_shutdown(self, app: Any) -> None:
        router = getattr(app, "router", None)
        existing = getattr(router, "lifespan_context", None)
        if router is not None and callable(existing):
            integration = self

            @asynccontextmanager
            async def lifespan(application):
                async with existing(application) as state:
                    try:
                        yield state
                    finally:
                        integration.close()

            router.lifespan_context = lifespan
            return
        add_event_handler = getattr(app, "add_event_handler", None)
        if callable(add_event_handler):
            add_event_handler("shutdown", self.close)

    def handoff(self, value: Any, **kwargs: Any) -> Any:
        """Optionally annotate durable lineage while preserving the value."""

        if self.shelf is None:
            return value
        try:
            return self.shelf.handoff(value, **kwargs)
        except Exception:
            return value

    def tool(
        self,
        func: Optional[Callable[..., Any]] = None,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        stage: Optional[str] = None,
    ):
        """Instrument an ordinary callable as a generic tool.

        Supports both direct wrapping (``integration.tool(fn)``) and decorator
        forms (``@integration.tool`` or ``@integration.tool(name="search")``).
        Inactive integrations return the original function unchanged.
        """

        def decorate(candidate: Callable[..., Any]) -> Callable[..., Any]:
            if self.shelf is None:
                return candidate
            return wrap_tool(
                self.shelf,
                candidate,
                name=name,
                description=description,
                stage=stage,
            )

        if func is None:
            return decorate
        return decorate(func)

    def tools(self, tools: Any, *, stage: Optional[str] = None) -> Any:
        """Wrap a list, tuple, or mapping registry of callables once."""

        if self.shelf is None:
            return tools
        return wrap_tools(self.shelf, tools, stage=stage)

    @contextmanager
    def _safe_execution(self):
        if self.shelf is None:
            yield
            return
        try:
            scope = self.shelf.execution()
            scope.__enter__()
        except Exception:
            yield
            return
        try:
            yield
        except BaseException as exc:
            try:
                scope.__exit__(type(exc), exc, exc.__traceback__)
            except Exception:
                pass
            raise
        else:
            try:
                scope.__exit__(None, None, None)
            except Exception:
                pass

    def run(self, callback: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Run a workflow under one trace identity when ShelfAI is active."""

        with self._safe_execution():
            return callback(*args, **kwargs)

    async def run_async(self, callback: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Async-aware counterpart to :meth:`run`."""

        with self._safe_execution():
            result = callback(*args, **kwargs)
            if inspect.isawaitable(result):
                return await result
            return result

    def deactivate(self, reason: str, error: Optional[BaseException] = None) -> None:
        """Safely disable a failed adapter without exposing exception details."""

        shelf = self.shelf
        self.shelf = None
        if self._finalizer is not None and self._finalizer.alive:
            self._finalizer.detach()
        if shelf is not None:
            _close_safely(shelf)
        self._closed = True
        self.status.active = False
        self.status.wrapped = False
        self.status.reason = str(reason)
        self.status.error_type = type(error).__name__ if error is not None else None

    def close(self) -> None:
        """Flush and close telemetry without affecting application shutdown."""

        if self._closed:
            return
        self._closed = True
        if self.shelf is None:
            return
        if self._finalizer is not None and self._finalizer.alive:
            self._finalizer.detach()
        try:
            self.shelf.close()
        except Exception as exc:
            self.status.active = False
            self.status.reason = "close_failed"
            self.status.error_type = type(exc).__name__

    def __enter__(self) -> "ShelfAIIntegration":
        return self

    def __exit__(self, _exc_type, _exc, _tb) -> None:
        self.close()

    async def __aenter__(self) -> "ShelfAIIntegration":
        return self

    async def __aexit__(self, _exc_type, _exc, _tb) -> None:
        self.close()


def _requested(enabled: Optional[bool], *, configured_credentials: bool = False) -> bool:
    if enabled is not None:
        return bool(enabled)
    configured = os.getenv("SHELFAI_ENABLED")
    if configured is not None:
        return configured.strip().lower() not in _FALSE_VALUES
    return configured_credentials or bool(os.getenv("SHELFAI_API_KEY") and os.getenv("SHELFAI_AGENT_ID"))


def _snapshot_provider_callables(client: Any, bindings: list[tuple[Any, str, Any]]) -> bool:
    """Recognize and snapshot every raw-provider entry point wrappers mutate."""

    messages = getattr(client, "messages", None)
    create = getattr(messages, "create", None)
    if callable(create):
        bindings.append((messages, "create", create))
        stream = getattr(messages, "stream", None)
        if callable(stream):
            bindings.append((messages, "stream", stream))

    chat = getattr(client, "chat", None)
    completions = getattr(chat, "completions", None) if chat is not None else None
    create = getattr(completions, "create", None)
    if callable(create):
        bindings.append((completions, "create", create))

    responses = getattr(client, "responses", None)
    create = getattr(responses, "create", None)
    if callable(create):
        bindings.append((responses, "create", create))
    return bool(bindings)


def _restore_provider_callables(bindings: list[tuple[Any, str, Any]]) -> None:
    for owner, name, original in reversed(bindings):
        try:
            setattr(owner, name, original)
        except Exception:
            pass


def integrate(
    *,
    client: Any,
    replay: Optional[Callable[..., Any]] = None,
    enabled: Optional[bool] = None,
    shelf_class: Optional[Type[Any]] = None,
    **kwargs: Any,
) -> ShelfAIIntegration:
    """Optionally wrap ``client`` while preserving it on every setup failure."""

    requested = _requested(
        enabled,
        configured_credentials=bool(kwargs.get("api_key") and kwargs.get("agent_id")),
    )
    if not requested:
        return ShelfAIIntegration(
            client=client,
            status=IntegrationStatus(False, False, False, "disabled"),
        )

    if shelf_class is None:
        from .client import ShelfAI

        shelf_class = ShelfAI

    shelf = None
    bindings: list[tuple[Any, str, Any]] = []
    try:
        supported = _snapshot_provider_callables(client, bindings)
        shelf = shelf_class(replay=replay, **kwargs)
        wrapped = shelf.wrap(client)
    except Exception as exc:
        _restore_provider_callables(bindings)
        if shelf is not None:
            _close_safely(shelf)
        return ShelfAIIntegration(
            client=client,
            status=IntegrationStatus(True, False, False, "configuration_failed", type(exc).__name__),
        )

    was_wrapped = supported or wrapped is not client
    if not was_wrapped:
        _close_safely(shelf)
        return ShelfAIIntegration(
            client=client,
            status=IntegrationStatus(True, False, False, "unsupported_client"),
        )
    return ShelfAIIntegration(
        client=wrapped,
        shelf=shelf,
        status=IntegrationStatus(True, True, True, "active"),
    )


def connect(
    *,
    replay: Optional[Callable[..., Any]] = None,
    enabled: Optional[bool] = None,
    shelf_class: Optional[Type[Any]] = None,
    **kwargs: Any,
) -> ShelfAIIntegration:
    """Create an optional ShelfAI lifecycle handle without a raw model client."""

    requested = _requested(
        enabled,
        configured_credentials=bool(kwargs.get("api_key") and kwargs.get("agent_id")),
    )
    if not requested:
        return ShelfAIIntegration(
            client=None,
            status=IntegrationStatus(False, False, False, "disabled"),
        )
    if shelf_class is None:
        from .client import ShelfAI

        shelf_class = ShelfAI
    try:
        shelf = shelf_class(replay=replay, **kwargs)
    except Exception as exc:
        return ShelfAIIntegration(
            client=None,
            status=IntegrationStatus(True, False, False, "configuration_failed", type(exc).__name__),
        )
    return ShelfAIIntegration(
        client=None,
        shelf=shelf,
        status=IntegrationStatus(True, True, False, "active"),
    )


class _IdentitySet:
    """Objects seen so far, by identity, without keeping them alive when possible."""

    def __init__(self) -> None:
        self._weak: "weakref.WeakSet[Any]" = weakref.WeakSet()
        self._ids: set[int] = set()
        self._lock = threading.Lock()

    def add(self, item: Any) -> bool:
        """Remember ``item``; False when it was already there."""

        with self._lock:
            try:
                if item in self._weak:
                    return False
                self._weak.add(item)
                return True
            except TypeError:
                # Not weak-referenceable: fall back to identity. Such objects are
                # rare (slots without __weakref__); an id can be reused after
                # the object dies, which at worst skips one wrap.
                if id(item) in self._ids:
                    return False
                self._ids.add(id(item))
                return True

    def discard(self, item: Any) -> None:
        with self._lock:
            try:
                self._weak.discard(item)
            except TypeError:
                self._ids.discard(id(item))


# --- One-line setup -----------------------------------------------------------
#
# ``wrap`` and ``install`` share one process-wide integration configured from
# SHELFAI_* environment variables, so an application needs no ShelfAI objects
# of its own:
#
#     client = shelfai_sdk.wrap(anthropic.Anthropic())
#
# While ShelfAI is unconfigured every call hands back what it was given, and the
# settings are read again on the next call, so a late-loaded .env still works.
# Once active, the integration stays put (clients wrapped earlier keep
# recording) and is flushed when the process exits.

_SHARED_SETTINGS = (
    "SHELFAI_ENABLED",
    "SHELFAI_API_URL",
    "SHELFAI_API_KEY",
    "SHELFAI_AGENT_ID",
    "SHELFAI_CAPTURE_MODE",
    "SHELFAI_SENSITIVE_MODE",
    "SHELFAI_ENVIRONMENT",
    "SHELFAI_REPLAY",
    "SHELFAI_REPLAY_SECRET",
)
# Tests swap in a fake; None means the real ShelfAI client.
_SHARED_SHELF_CLASS: Optional[Type[Any]] = None

_shared_lock = threading.RLock()
_shared: Optional[ShelfAIIntegration] = None
_shared_settings: Optional[tuple[Optional[str], ...]] = None
_explicit_replay: Any = None
_wrapped_clients = _IdentitySet()
_exit_flush_registered = False

ReplayWorkflow = Union[Callable[..., Any], str]


def _current_settings() -> tuple[Optional[str], ...]:
    return tuple(os.environ.get(name) for name in _SHARED_SETTINGS)


def _same_replay(left: Any, right: Any) -> bool:
    return left is right or (isinstance(left, str) and left == right)


def _python_entry_point(command: str) -> tuple[str, str, list[str]]:
    """Parse a Python command line into (kind, target, args).

    Accepts the forms people already use to start an agent: ``path/to/script.py
    --flag``, ``-m package.module --flag``, and either of those after a Python
    interpreter (``python``, ``python3``, or the running interpreter's path).
    """

    argv = shlex.split(command)
    if argv and (
        os.path.basename(argv[0]).startswith("python")
        or os.path.abspath(argv[0]) == os.path.abspath(sys.executable)
    ) and not argv[0].endswith(".py"):
        argv = argv[1:]
    if not argv:
        raise ValueError("Python command is empty.")
    if argv[0] == "-m":
        if len(argv) < 2:
            raise ValueError("Python command names no module after -m.")
        return "module", argv[1], argv[2:]
    script = Path(argv[0]).expanduser()
    if not script.is_absolute():
        script = Path.cwd() / script
    script = script.resolve(strict=True)
    if not script.is_file():
        raise ValueError("Python command must name a script file or a module.")
    return "script", str(script), argv[1:]


def run_python_entry_point(kind: str, target: str, args: list[str]) -> None:
    """Run a script or module as ``__main__`` in this process, the way ``python`` would."""

    if kind == "module":
        sys.argv = [target, *args]
        runpy.run_module(target, run_name="__main__", alter_sys=True)
        return
    sys.path.insert(0, os.path.dirname(target))
    sys.argv = [target, *args]
    runpy.run_path(target, run_name="__main__")


def _script_replay(command: str) -> Callable[[], Optional[str]]:
    """Replay by rerunning a Python command in this process.

    ``command`` is how the workflow is normally started, e.g.
    ``"scripts/run_agent.py --flag"`` or ``"python -m mypkg.run --flag"``. Its
    model calls go through wrapped clients, so the run records under the
    replay, and the replay handler gets back that run's trace ID.
    """

    kind, target, args = _python_entry_point(command)

    def run_workflow() -> Optional[str]:
        saved_argv, saved_path = sys.argv[:], sys.path[:]
        try:
            run_python_entry_point(kind, target, args)
        except SystemExit as exc:
            if exc.code not in (None, 0):
                raise RuntimeError("Replay command exited with a failure status.") from None
        finally:
            sys.argv, sys.path[:] = saved_argv, saved_path
        return last_trace_id()

    return run_workflow


def _replay_callback() -> Optional[Callable[..., Any]]:
    replay = _explicit_replay if _explicit_replay is not None else os.environ.get("SHELFAI_REPLAY")
    if replay is None or callable(replay):
        return replay
    if isinstance(replay, str):
        return _script_replay(replay) if replay.strip() else None
    raise TypeError("replay must be a callable or a script command string.")


def _attach_replay(integration: ShelfAIIntegration) -> None:
    """Point the integration's ShelfAI client at the current replay workflow."""

    shelf = integration.shelf
    if shelf is None:
        return
    try:
        callback = _replay_callback()
        set_replay = getattr(shelf, "set_replay", None)
        if callable(set_replay):
            set_replay(callback)
    except Exception as exc:  # noqa: BLE001 - a bad replay setting must not stop recording
        integration.status.reason = "replay_not_configured"
        integration.status.error_type = type(exc).__name__


def _flush_shared_at_exit() -> None:
    integration = _shared
    if integration is not None:
        integration.close()


def shared_integration(*, replay: Optional[ReplayWorkflow] = None) -> ShelfAIIntegration:
    """The process-wide integration behind :func:`wrap` and :func:`install`.

    Configured from SHELFAI_* environment variables; ``SHELFAI_REPLAY`` can name
    a replay script command. A ``replay`` passed here replaces that setting.
    """

    global _shared, _shared_settings, _explicit_replay, _exit_flush_registered
    settings = _current_settings()
    with _shared_lock:
        replay_changed = replay is not None and not _same_replay(replay, _explicit_replay)
        if replay_changed:
            _explicit_replay = replay
        inactive = _shared is None or _shared.shelf is None
        if inactive and (_shared is None or settings != _shared_settings):
            # Not recording yet: (re)read the settings. An active integration is
            # never replaced, so clients wrapped earlier keep recording.
            _shared = connect(shelf_class=_SHARED_SHELF_CLASS)
            _shared_settings = settings
            _attach_replay(_shared)
            if not _exit_flush_registered:
                atexit.register(_flush_shared_at_exit)
                _exit_flush_registered = True
        elif replay_changed:
            _attach_replay(_shared)
        return _shared


class _SharedReplayApp:
    """Replay endpoint that always serves the shared integration's current handler."""

    async def __call__(self, scope, receive, send) -> None:
        integration = _shared
        app = integration.replay_app() if integration is not None else _unavailable_replay_app
        await app(scope, receive, send)


def wrap(client: Any, *, replay: Optional[ReplayWorkflow] = None) -> Any:
    """Record ``client``'s model calls in ShelfAI; the one line an application needs.

    Returns the same client, instrumented when SHELFAI_API_KEY and
    SHELFAI_AGENT_ID are set and untouched otherwise. Wrapping a client twice is
    harmless, and a setup failure hands the client back unchanged.
    """

    integration = shared_integration(replay=replay)
    shelf = integration.shelf
    if shelf is None or client is None or not _wrapped_clients.add(client):
        return client
    bindings: list[tuple[Any, str, Any]] = []
    try:
        _snapshot_provider_callables(client, bindings)
        wrapped = shelf.wrap(client)
    except Exception as exc:  # noqa: BLE001 - fail open
        _restore_provider_callables(bindings)
        _wrapped_clients.discard(client)
        integration.status.reason = "wrap_failed"
        integration.status.error_type = type(exc).__name__
        return client
    if wrapped is not client:
        _wrapped_clients.add(wrapped)
    return wrapped


def install(
    app: Any,
    *,
    replay: Optional[ReplayWorkflow] = None,
    path: str = "/shelfai/replay",
) -> ShelfAIIntegration:
    """Give a Starlette/FastAPI app ShelfAI's replay endpoint and shutdown flush.

    Does nothing while ShelfAI is unconfigured, or for an app already installed.
    """

    integration = shared_integration(replay=replay)
    if integration.status.requested:
        integration.install(app, path=path, asgi=_SharedReplayApp())
    return integration


def last_trace_id() -> Optional[str]:
    """Trace ID of the most recent model call recorded in this process, if any."""

    integration = _shared
    return integration.last_trace_id if integration is not None else None


def flush() -> None:
    """Send recorded events now instead of waiting for the next batch."""

    integration = _shared
    shelf = integration.shelf if integration is not None else None
    if shelf is None:
        return
    try:
        shelf.transport.flush()
    except Exception:  # noqa: BLE001 - fail open
        pass


def _reset_shared() -> None:
    """Close and forget the shared integration (tests)."""

    global _shared, _shared_settings, _explicit_replay, _wrapped_clients
    with _shared_lock:
        previous = _shared
        _shared, _shared_settings, _explicit_replay = None, None, None
        _wrapped_clients = _IdentitySet()
    if previous is not None:
        previous.close()
