# ShelfAI Node SDK

Instrument AI agents and stream context telemetry to ShelfAI with a small,
framework-agnostic TypeScript package.

## Install

```bash
npm install @shelfai/sdk@0.2.0
```

## Quick Start

Installing the package and setting environment variables does not automatically
intercept an existing provider client. The application must wrap its client and
use the returned object:

```ts
import { ShelfAI } from "@shelfai/sdk";

const integration = ShelfAI.integrate({
  client: existingProviderClient,
  replay: runWorkflow,
});
const client = integration.client;
app.post("/shelfai/replay", express.raw({ type: "application/json" }), integration.replayNodeHandler());
```

All downstream provider calls must use `client`, not `existingProviderClient`.
If ShelfAI is disabled or misconfigured, `client` is the exact original object
and the application keeps working. If the original client remains in use while
the integration is active, ShelfAI captures nothing.

Keep the observer wiring in one integration module and reuse the wrapped
client. The standard integration includes capture and replay. Set
`SHELFAI_REPLAY_SECRET` to the workspace-specific signing secret.
`replayNodeHandler()` works with Node HTTP and Express-compatible request/
response objects and requires an unmodified raw body. The lower-level
`replayHandler()` is available for other runtimes. Register the workspace
replay hook with `default_target_name` set to `default`; the callback may return
its normal application result or nothing. ShelfAI owns the replay session and
trace identity.

After a provider call, `integration.lastTraceId()` is the exact run to open or
verify. Do not substitute a process-wide "latest" run in concurrent systems.

### Framework-neutral tools

Use `integration.tool(fn, options)` for ordinary application tools that are not
owned by a model-provider SDK. The wrapper returns the original result, keeps
sync functions sync, preserves rejected promises and thrown errors, and emits
one provider-neutral `tool_start` event with `tool_definition` + `tool_call`
Context IR, then one linked `tool_end` event with only `tool_result` Context
IR. If the integration is disabled, misconfigured, or attached to an
unsupported provider client, `tool(...)` returns the exact original function.
For generic tools without a provider client, construct `new ShelfAI(...)` and
call `shelf.tool(...)` directly.

```ts
const searchInventory = integration.tool(async (query: string) => {
  return inventory.search(query);
}, {
  name: "search_inventory",
  description: "Find candidate inventory items.",
  parameters: { type: "object", properties: { query: { type: "string" } } },
});

await integration.runAsync(async () => {
  const draft = await integration.client.chat.completions.create({ model: "gpt-4o", messages });
  const inventory = await searchInventory("standing desk");
  return { draft, inventory };
});
```

`integration.tools(...)` wraps an array/tuple or record registry in one call:

```ts
const tools = integration.tools({
  searchInventory,
  reserveItem: async (sku: string) => inventory.reserve(sku),
});
```

`run(...)` / `runAsync(...)` group provider calls and ordinary tools in one
async-safe execution trace. A tool invoked outside a grouped execution creates
a standalone trace truthfully. Tool telemetry follows the configured capture
mode; it never captures callable objects, local variables, environment values,
absolute paths, or exception messages.

Normal telemetry remains fail-open. Authenticated replay-session activation and protected-bundle integrity are intentionally fail-closed. Replay rejects invalid signatures, stale
or duplicate deliveries, another tenant or target, missing provider capture,
and unpersisted session-bound traces are rejected. `AsyncLocalStorage` scopes the experiment to the replay
request, leaving concurrent normal traffic unchanged. Applications that cannot
accept an HTTPS hook can temporarily omit `replay`; Workbench identifies them
as capture-only and does not ask customers to copy experiment or trace IDs.

Anthropic Messages, OpenAI Chat Completions, and OpenAI Responses
wrappers automatically retain structured messages,
tool definitions, tool calls, tool results, and outputs as Context IR v1. The
schema is provider- and domain-neutral.

## Launch Capture Modes

ShelfAI launches with two live SDK capture modes:

- `metadata_only`
- `full`

`metadata_only` is the default and strips raw snapshot text before send while preserving structural telemetry.
`full` unlocks content-aware Workbench editing and should be enabled only with
customer approval; the SDK still scrubs obvious secrets before egress.

The observer SDK sends telemetry only to the configured ShelfAI endpoint; it
does not forward captured context to an additional model provider. Shelfy's
managed suggestion model is configured separately and can remain disabled for
private deployments.

You can set this in code with `captureMode` or through:

- `SHELFAI_CAPTURE_MODE`
- legacy compatibility alias: `SHELFAI_SENSITIVE_MODE`

The public trust boundary lives in `src/captureMode.ts`.

## Context IR v1

Wrapped calls emit a versioned `context_ir` envelope with stable item IDs,
typed raw payloads, causal parents, source hashes, run/stage fields, selection,
provenance, permissions, side effects, and redaction metadata. Metadata-only
capture keeps the graph while redacting content; full capture keeps structured
payloads after secret scrubbing.

### Automatic handoffs and downstream experiments

The wrapped SDK automatically connects a prior model output to a later wrapped
input when substantial output text is reused. This lights the observed run graph
with no annotation. Each provider call also captures a bounded,
repository-relative runtime callsite and customer-code stack. It never captures
source text, locals, arguments, environment values, or absolute paths. Short
common values are ignored, and deployments without `.git` still capture source
paths while leaving the revision unknown. Inference stays local to the process, and inferred
source candidates cannot unlock a production edit until an owner confirms one.
Set `SHELFAI_RUNTIME_SOURCE_EVIDENCE=off` to disable code-location metadata.

Use the optional annotation below only when Workbench needs an exact file and
symbol for promotion after a successful experiment:

```ts
const brief = await planner();
const assignment = shelf.handoff(buildAssignment(brief), {
  derivedFrom: brief,
  materializedBy: buildAssignment,
  sourcePath: "workflow/assignment.ts",
});
await writer(assignment);
```

`handoff(...)` returns the original value unchanged while Context IR records
the upstream parents and materializer. The standard replay handler selects the
experiment automatically, fetches its protected bundle, applies it in memory
for that one execution, and returns only the SDK/backend-verified replay trace.
Capture-only installs must connect the signed replay endpoint before running
Workbench experiments; there is no manual environment-variable replay path.

## Pricing Snapshot

The Node SDK carries a generated pricing mirror in `src/pricing_snapshot.ts`
so wrappers can attribute cost without importing `shelfai_pro`.

When the canonical catalog changes:

1. Update `shelfai_pro/pricing/model_rates.py`.
2. Regenerate both SDK mirrors with `uv run python -m shelfai_pro.main billing pricing-sync`.
3. Verify there is no drift with `uv run python -m shelfai_pro.main billing pricing-sync --check`.
4. Run `npm test` in `shelfai-sdk/node` and `uv run --with pytest pytest tests/test_model_rates_sanity.py tests/test_pricing_sync_cli.py`.

Historical event `rate_snapshot` values remain authoritative for past calls,
and recent unknown models can be inspected through `billing usage` or
`billing unknown-models`.
