from shelfai_sdk.context_ir import context_item, provider_input_ir, provider_output_ir


def test_context_item_id_is_canonical_across_sdks():
    item = context_item(
        "message",
        {"role": "developer", "content": [{"text": "café", "type": "text"}]},
        run_id="run-1",
    )

    assert item.id == "ctx_933894274f53fc093b14d2f4"


def test_provider_input_ir_preserves_structured_blocks_and_tool_definitions():
    envelope = provider_input_ir(
        provider="anthropic",
        run_id="run-1",
        stage="draft",
        system=[{"type": "text", "text": "Write in the house voice."}],
        messages=[
            {"role": "user", "content": [{"type": "text", "text": "Draft the post."}]},
            {
                "role": "assistant",
                "content": [{"type": "tool_use", "id": "toolu_1", "name": "search", "input": {"q": "launch"}}],
            },
            {
                "role": "user",
                "content": [{"type": "tool_result", "tool_use_id": "toolu_1", "content": [{"title": "Launch"}]}],
            },
        ],
        tools=[{"name": "search", "description": "Search the source set", "input_schema": {"type": "object"}}],
    )

    assert envelope.version == "1.0"
    assert [item.type for item in envelope.items] == [
        "instruction",
        "message",
        "message",
        "tool_call",
        "message",
        "tool_result",
        "tool_definition",
    ]
    tool_call = next(item for item in envelope.items if item.type == "tool_call")
    assert tool_call.raw_payload["input"] == {"q": "launch"}
    assert tool_call.parent_ids
    assert tool_call.stage == "draft"


def test_provider_output_ir_keeps_openai_tool_call_payload():
    envelope = provider_output_ir(
        provider="openai",
        run_id="run-2",
        response={
            "id": "resp-1",
            "choices": [
                {
                    "message": {
                        "role": "assistant",
                        "content": None,
                        "tool_calls": [
                            {"id": "call-1", "type": "function", "function": {"name": "publish", "arguments": "{}"}}
                        ],
                    }
                }
            ],
        },
    )

    assert [item.type for item in envelope.items] == ["message", "tool_call"]
    assert envelope.items[0].selection == "produced"
    assert envelope.items[1].raw_payload["function"]["name"] == "publish"
    assert envelope.items[1].parent_ids == [envelope.items[0].id]


def test_openai_request_emits_top_level_calls_and_tool_results():
    envelope = provider_input_ir(
        provider="openai",
        messages=[
            {"role": "assistant", "content": None, "tool_calls": [{"id": "call-1", "type": "function"}]},
            {"role": "tool", "tool_call_id": "call-1", "content": "published"},
        ],
    )

    assert [item.type for item in envelope.items] == ["message", "tool_call", "message", "tool_result"]
    assert envelope.items[1].parent_ids == [envelope.items[0].id]
    assert envelope.items[3].parent_ids == [envelope.items[2].id]


def test_openai_responses_top_level_items_keep_their_types():
    request = provider_input_ir(
        provider="openai.responses",
        messages=[
            {"role": "user", "content": "hello"},
            {"type": "function_call_output", "call_id": "call-1", "output": "world"},
        ],
    )
    response = provider_output_ir(
        provider="openai.responses",
        response={
            "id": "resp-1",
            "output": [
                {"type": "function_call", "name": "lookup", "arguments": "{}"},
                {"type": "message", "role": "assistant", "content": [{"type": "output_text", "text": "done"}]},
            ],
        },
    )

    assert [item.type for item in request.items] == ["message", "tool_result"]
    assert [item.type for item in response.items] == ["tool_call", "message"]
