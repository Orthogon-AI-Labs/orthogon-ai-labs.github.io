from __future__ import annotations

import asyncio
import inspect
from pathlib import Path
from types import SimpleNamespace

import pytest

from shelfai_sdk import ShelfAI, connect


class _HttpClient:
    def __init__(self):
        self.payloads = []

    def post(self, _url, headers=None, json=None):
        self.payloads.append(json)
        return SimpleNamespace(raise_for_status=lambda: None)

    def close(self):
        return None


class _OpenAICompletions:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(
            id="chatcmpl-generic-tool-lineage",
            usage=SimpleNamespace(prompt_tokens=3, completion_tokens=2, total_tokens=5),
            choices=[
                SimpleNamespace(
                    finish_reason="stop",
                    message={"role": "assistant", "content": "done"},
                )
            ],
        )


class _OpenAIClient:
    def __init__(self):
        self.chat = SimpleNamespace(completions=_OpenAICompletions())


def _integration(tmp_path: Path, *, capture_mode: str = "full"):
    http = _HttpClient()
    integration = ShelfAI.connect(
        enabled=True,
        api_key="sk-test",
        agent_id="agent_generic_tools",
        http_client=http,
        start_background_threads=False,
        capture_mode=capture_mode,
        offline_queue_path=str(tmp_path / "queue"),
    )
    return integration, http


def _events(http: _HttpClient):
    return [event for payload in http.payloads for event in payload.get("events", [])]


def _tool_events(http: _HttpClient):
    return [event for event in _events(http) if event["name"] in {"tool_start", "tool_end"}]


def _context_snapshots(http: _HttpClient):
    return [event["metadata"]["snapshot"] for event in _events(http) if event["name"] == "context_snapshot"]


def _items(http: _HttpClient):
    return [
        item
        for event in _tool_events(http)
        for item in event["metadata"]["context_ir"]["items"]
    ]


def test_inactive_tool_and_tools_are_identity_preserving():
    integration = connect(enabled=False)

    def add(a: int, b: int = 1) -> int:
        return a + b

    registry = {"add": add}
    tools_list = [add]
    tools_tuple = (add,)

    assert integration.tool(add) is add
    assert integration.tool()(add) is add
    assert integration.tools(registry) is registry
    assert integration.tools(tools_list) is tools_list
    assert integration.tools(tools_tuple) is tools_tuple


def test_sync_tool_preserves_metadata_signature_and_records_linked_ir(tmp_path):
    integration, http = _integration(tmp_path)

    def add(a: int, b: int = 1) -> int:
        """Add two numbers."""
        return a + b

    wrapped = integration.tool(add)

    assert wrapped(2, b=3) == 5
    assert wrapped.__name__ == "add"
    assert wrapped.__doc__ == "Add two numbers."
    assert inspect.signature(wrapped) == inspect.signature(add)

    integration.close()
    events = _tool_events(http)
    assert [event["name"] for event in events] == ["tool_start", "tool_end"]
    items = _items(http)
    assert [item["type"] for item in items] == ["tool_definition", "tool_call", "tool_result"]
    definition, call, result = items
    assert definition["selection"] == "available"
    assert call["selection"] == "selected"
    assert result["selection"] == "produced"
    assert call["parent_ids"] == [definition["id"]]
    assert result["parent_ids"] == [call["id"]]
    assert definition["raw_payload"]["function"]["name"] == "add"
    assert call["raw_payload"]["arguments"]["args"] == [2]
    assert call["raw_payload"]["arguments"]["kwargs"] == {"b": 3}
    assert result["raw_payload"]["result"] == 5
    assert "call_id" not in definition["raw_payload"]
    assert "call_id" not in definition["metadata"]
    assert call["raw_payload"]["call_id"] == result["raw_payload"]["call_id"]


def test_decorator_forms_and_async_semantics(tmp_path):
    integration, http = _integration(tmp_path)

    @integration.tool
    async def fetch(value: str) -> str:
        return f"done:{value}"

    @integration.tool(name="decorated")
    def sync_tool(value: str) -> str:
        return value.upper()

    assert inspect.iscoroutinefunction(fetch)
    assert asyncio.run(fetch("x")) == "done:x"
    assert sync_tool("ok") == "OK"

    integration.close()
    names = [item["raw_payload"].get("name") or item["raw_payload"].get("function", {}).get("name") for item in _items(http)]
    assert "fetch" in names
    assert "decorated" in names


def test_failure_propagates_and_records_metadata_only_error_without_message(tmp_path):
    integration, http = _integration(tmp_path)

    @integration.tool
    def fail(secret: str):
        raise RuntimeError(f"password={secret}")

    with pytest.raises(RuntimeError, match="password=abc"):
        fail("abc")

    integration.close()
    result = next(item for item in _items(http) if item["type"] == "tool_result")
    assert result["raw_payload"]["status"] == "error"
    assert result["raw_payload"]["error_type"] == "RuntimeError"
    result_payload = str(result["raw_payload"])
    assert "password" not in result_payload
    assert "abc" not in result_payload


def test_telemetry_failure_does_not_change_return_value_or_exception(monkeypatch, tmp_path):
    integration, _http = _integration(tmp_path)

    def ok():
        return "application-result"

    wrapped = integration.tool(ok)
    monkeypatch.setattr(integration.shelf, "emit_event", lambda *_args, **_kwargs: (_ for _ in ()).throw(ValueError("boom")))

    assert wrapped() == "application-result"

    def fail():
        raise LookupError("customer exception")

    wrapped_fail = integration.tool(fail)
    with pytest.raises(LookupError, match="customer exception"):
        wrapped_fail()

    integration.close()


def test_grouped_run_uses_one_trace_for_tool_activity(tmp_path):
    integration, http = _integration(tmp_path)

    @integration.tool
    def one():
        return 1

    @integration.tool
    def two(value):
        return value + 1

    assert integration.run(lambda: two(one())) == 2

    integration.close()
    events = _tool_events(http)
    assert [event["name"] for event in events] == ["tool_start", "tool_end", "tool_start", "tool_end"]
    trace_ids = {event["trace_id"] for event in events}
    assert len(trace_ids) == 1
    assert len(events) == 4


def test_standalone_tool_invocation_creates_scope_and_runtime_source(tmp_path):
    integration, http = _integration(tmp_path)

    @integration.tool
    def current_path(value):
        return value

    assert current_path("ok") == "ok"

    integration.close()
    events = _tool_events(http)
    assert events
    assert all(event["trace_id"] for event in events)
    items = _items(http)
    assert any(item.get("runtime_source") for item in items)
    assert str(Path.cwd()) not in str(items)
    assert integration.last_trace_id == events[-1]["trace_id"]


def test_metadata_only_redacts_content_and_avoids_callable_path_serialization(tmp_path):
    integration, http = _integration(tmp_path, capture_mode="metadata_only")

    def helper():
        return "helper"

    @integration.tool
    def echo(callback, path, path_text, value):
        return {"callback": callback, "path": path, "path_text": path_text, "value": value}

    absolute_path_string = str(Path.cwd() / "secret.txt")
    assert echo(helper, Path.cwd() / "secret.txt", absolute_path_string, "customer secret")["value"] == "customer secret"

    integration.close()
    text = str(_items(http))
    assert "customer secret" not in text
    assert "secret.txt" not in text
    assert absolute_path_string not in text
    assert str(Path.cwd()) not in text
    assert "function helper" not in text


def test_tools_wraps_list_tuple_and_registry_once(tmp_path):
    integration, http = _integration(tmp_path)

    def a():
        return "a"

    def b():
        return "b"

    listed = integration.tools([a, "skip"])
    tupled = integration.tools((a, b))
    registry = integration.tools({"first": a, "other": "skip"})
    double = integration.tools(listed)

    assert listed is not double
    assert listed[0] is double[0]
    assert listed[0]() == "a"
    assert listed[1] == "skip"
    assert tupled[0]() == "a"
    assert tupled[1]() == "b"
    assert registry["first"]() == "a"
    assert registry["other"] == "skip"

    integration.close()
    assert len([item for item in _items(http) if item["type"] == "tool_call"]) == 4


def test_cyclic_inputs_use_safe_conversion(tmp_path):
    integration, http = _integration(tmp_path)
    cyclic = []
    cyclic.append(cyclic)

    @integration.tool
    def size(value):
        return len(value)

    assert size(cyclic) == 1

    integration.close()
    call = next(item for item in _items(http) if item["type"] == "tool_call")
    assert call["raw_payload"]["arguments"]["args"] == [["<cycle>"]]


def test_repeated_calls_share_definition_id_and_have_distinct_call_ids(tmp_path):
    integration, http = _integration(tmp_path)

    @integration.tool
    def repeat(value):
        return value

    assert integration.run(lambda: (repeat("one"), repeat("two"))) == ("one", "two")

    integration.close()
    definitions = [item for item in _items(http) if item["type"] == "tool_definition"]
    calls = [item for item in _items(http) if item["type"] == "tool_call"]
    results = [item for item in _items(http) if item["type"] == "tool_result"]
    call_ids = [item["raw_payload"]["call_id"] for item in calls]
    result_ids = [item["raw_payload"]["call_id"] for item in results]

    assert len(definitions) == 2
    assert len({item["id"] for item in definitions}) == 1
    assert all("call_id" not in item["raw_payload"] for item in definitions)
    assert all("call_id" not in item["provenance"] for item in definitions)
    assert all("call_id" not in item["metadata"] for item in definitions)
    assert len(set(call_ids)) == 2
    assert sorted(call_ids) == sorted(result_ids)


def test_nested_tools_use_parent_context_item_ids_without_leaking_between_calls(tmp_path):
    integration, http = _integration(tmp_path)

    @integration.tool
    def inner():
        return "inner"

    @integration.tool
    def outer():
        return inner()

    assert outer() == "inner"
    assert inner() == "inner"

    integration.close()
    events = _tool_events(http)
    assert [event["name"] for event in events] == [
        "tool_start",
        "tool_start",
        "tool_end",
        "tool_end",
        "tool_start",
        "tool_end",
    ]
    starts = [event for event in events if event["name"] == "tool_start"]
    outer_definition, outer_call = starts[0]["metadata"]["context_ir"]["items"]
    inner_nested_definition, inner_nested_call = starts[1]["metadata"]["context_ir"]["items"]
    inner_standalone_definition, inner_standalone_call = starts[2]["metadata"]["context_ir"]["items"]

    assert outer_call["parent_ids"] == [outer_definition["id"]]
    assert inner_nested_call["parent_ids"] == [inner_nested_definition["id"], outer_call["id"]]
    assert inner_standalone_call["parent_ids"] == [inner_standalone_definition["id"]]
    assert all(parent_id.startswith("ctx_") for parent_id in inner_nested_call["parent_ids"])


def test_nested_tools_from_different_integrations_do_not_cross_link(tmp_path):
    integration_a, http_a = _integration(tmp_path / "a")
    integration_b, http_b = _integration(tmp_path / "b")

    @integration_b.tool
    def b_inner():
        return "b"

    @integration_a.tool
    def a_outer():
        return b_inner()

    assert a_outer() == "b"

    integration_a.close()
    integration_b.close()
    a_start = next(event for event in _tool_events(http_a) if event["name"] == "tool_start")
    b_start = next(event for event in _tool_events(http_b) if event["name"] == "tool_start")
    a_definition, a_call = a_start["metadata"]["context_ir"]["items"]
    b_definition, b_call = b_start["metadata"]["context_ir"]["items"]

    assert a_call["parent_ids"] == [a_definition["id"]]
    assert b_call["parent_ids"] == [b_definition["id"]]
    assert a_call["id"] not in b_call["parent_ids"]
    assert b_start["trace_id"] != a_start["trace_id"]


def test_tool_result_registers_output_lineage_for_later_provider_input(tmp_path):
    http = _HttpClient()
    integration = ShelfAI.integrate(
        client=_OpenAIClient(),
        enabled=True,
        api_key="sk-test",
        agent_id="agent_generic_tools",
        http_client=http,
        start_background_threads=False,
        capture_mode="full",
        offline_queue_path=str(tmp_path / "queue"),
    )

    @integration.tool
    def retrieve_evidence():
        return {"evidence": "generic tool lineage evidence packet"}

    def workflow():
        evidence = retrieve_evidence()
        return integration.client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": evidence}],
        )

    integration.run(workflow)

    integration.close()
    tool_result = next(item for item in _items(http) if item["type"] == "tool_result")
    provider_snapshot = _context_snapshots(http)[-1]
    message = next(item for item in provider_snapshot["context_ir"]["items"] if item["type"] == "message")

    assert message["parent_ids"] == [tool_result["id"]]
    assert message["origin"]["kind"] == "upstream_output"
    assert message["origin"]["producer"]["item_id"] == tool_result["id"]
