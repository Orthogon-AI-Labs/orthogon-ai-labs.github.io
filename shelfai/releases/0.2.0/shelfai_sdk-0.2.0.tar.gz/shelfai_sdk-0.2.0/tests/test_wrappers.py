from __future__ import annotations

from types import SimpleNamespace

import pytest

from shelfai_sdk import ShelfAI


class _Response:
    def __init__(self):
        self.id = "msg_test"
        self.usage = SimpleNamespace(
            input_tokens=42,
            output_tokens=12,
            cache_creation_input_tokens=100,
            cache_read_input_tokens=50,
        )
        self.stop_reason = "end_turn"


class _AnthropicMessages:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return _Response()


class _AnthropicClient:
    def __init__(self):
        self.messages = _AnthropicMessages()


class _OpenAICompletions:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return _OpenAIResponse()


class _OpenAIResponse:
    def __init__(self):
        self.id = "chatcmpl-test"
        self.usage = SimpleNamespace(
            prompt_tokens=10,
            completion_tokens=8,
            total_tokens=18,
        )
        self.choices = [SimpleNamespace(finish_reason="stop")]


class _OpenAIClient:
    def __init__(self):
        self.chat = SimpleNamespace(completions=_OpenAICompletions())


class _OpenAIResponses:
    def __init__(self):
        self.calls = []

    def create(self, **kwargs):
        self.calls.append(kwargs)
        return SimpleNamespace(
            id="resp-test",
            status="completed",
            usage=SimpleNamespace(input_tokens=12, output_tokens=7, total_tokens=19),
            output=[
                SimpleNamespace(type="function_call", name="lookup", arguments='{"q":"hello"}'),
                SimpleNamespace(type="message", role="assistant", content=[{"type": "output_text", "text": "done"}]),
            ],
        )


class _OpenAIResponsesClient:
    def __init__(self):
        self.responses = _OpenAIResponses()


class _ExplodingAnthropicMessages:
    def create(self, **kwargs):
        raise RuntimeError("anthropic boom")


class _ExplodingAnthropicClient:
    def __init__(self):
        self.messages = _ExplodingAnthropicMessages()


class _ExplodingOpenAICompletions:
    def create(self, **kwargs):
        raise RuntimeError("openai boom")


class _ExplodingOpenAIClient:
    def __init__(self):
        self.chat = SimpleNamespace(completions=_ExplodingOpenAICompletions())


class _HttpClient:
    def __init__(self):
        self.payloads = []

    def post(self, url, headers=None, json=None):
        self.payloads.append(json)
        return SimpleNamespace(raise_for_status=lambda: None)

    def close(self):
        return None


def _events(payloads):
    return [event for payload in payloads for event in payload.get("events", [])]


def _event(payloads, name):
    return next(event for event in _events(payloads) if event["name"] == name)


def test_anthropic_wrapper_emits_context_snapshot(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(api_key="sk-demo", agent_id="agent-1", offline_queue_path=str(tmp_path), http_client=http)
    client = shelf.wrap(_AnthropicClient())

    client.messages.create(model="claude", system="hello", messages=[{"role": "user", "content": "hi"}])
    shelf.transport.flush()
    shelf.close()

    names = [event["name"] for event in _events(http.payloads)]
    assert "context_snapshot" in names
    assert "trace_output" in names
    output = _event(http.payloads, "trace_output")["metadata"]["output"]
    assert output["provider"] == "anthropic"
    assert output["model"] == "claude"
    assert output["response_id"] == "msg_test"
    assert output["input_tokens"] == 42
    assert output["output_tokens"] == 12
    assert output["total_tokens"] == 54
    assert output["cache_creation_input_tokens"] == 100
    assert output["cache_read_input_tokens"] == 50
    assert output["stop_reason"] == "end_turn"
    assert isinstance(output["latency_ms"], int)
    assert output["latency_ms"] >= 0


def test_openai_wrapper_emits_context_snapshot(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(api_key="sk-demo", agent_id="agent-1", offline_queue_path=str(tmp_path), http_client=http)
    client = shelf.wrap(_OpenAIClient())

    client.chat.completions.create(model="gpt-4o", messages=[{"role": "system", "content": "be nice"}, {"role": "user", "content": "hi"}])
    shelf.transport.flush()
    shelf.close()

    names = [event["name"] for event in _events(http.payloads)]
    assert "context_snapshot" in names
    assert "trace_output" in names
    output = _event(http.payloads, "trace_output")["metadata"]["output"]
    assert output["provider"] == "openai"
    assert output["model"] == "gpt-4o"
    assert output["response_id"] == "chatcmpl-test"
    assert output["input_tokens"] == 10
    assert output["output_tokens"] == 8
    assert output["total_tokens"] == 18
    assert output["finish_reason"] == "stop"
    assert isinstance(output["latency_ms"], int)
    assert output["latency_ms"] >= 0


def test_openai_responses_wrapper_captures_typed_input_and_output(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(api_key="sk-demo", agent_id="agent-1", capture_mode="full", offline_queue_path=str(tmp_path), http_client=http)
    client = shelf.wrap(_OpenAIResponsesClient())

    client.responses.create(
        model="gpt-5.4-mini",
        instructions="Use the supplied evidence.",
        input=[
            {"role": "user", "content": "hello"},
            {"type": "function_call_output", "call_id": "call-1", "output": "world"},
        ],
        tools=[{"type": "function", "name": "lookup", "parameters": {"type": "object"}}],
    )
    shelf.transport.flush()
    shelf.close()

    output = _event(http.payloads, "trace_output")["metadata"]["output"]
    assert output["api"] == "responses"
    assert output["response_id"] == "resp-test"
    assert output["input_tokens"] == 12
    assert output["output_tokens"] == 7
    assert {item["type"] for item in output["context_ir"]["items"]} == {"message", "tool_call"}

    snapshot = _event(http.payloads, "context_snapshot")["metadata"]["snapshot"]
    assert {item["type"] for item in snapshot["context_ir"]["items"]} >= {
        "instruction",
        "message",
        "tool_definition",
        "tool_result",
    }


def test_openai_wrapper_records_error_on_exception(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(api_key="sk-demo", agent_id="agent-1", offline_queue_path=str(tmp_path), http_client=http)
    client = shelf.wrap(_ExplodingOpenAIClient())

    with pytest.raises(RuntimeError, match="openai boom"):
        client.chat.completions.create(model="gpt-4o", messages=[{"role": "user", "content": "hi"}])
    shelf.transport.flush()
    shelf.close()

    names = [event["name"] for event in _events(http.payloads)]
    assert "trace_error" in names
    assert "trace_finished" in names
    error = _event(http.payloads, "trace_error")["metadata"]
    assert error["provider"] == "openai"
    assert error["model"] == "gpt-4o"
    assert error["error_type"] == "RuntimeError"
    assert error["error_message"] == "[REDACTED_TEXT]"


def test_anthropic_wrapper_records_error_on_exception(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(api_key="sk-demo", agent_id="agent-1", offline_queue_path=str(tmp_path), http_client=http)
    client = shelf.wrap(_ExplodingAnthropicClient())

    with pytest.raises(RuntimeError, match="anthropic boom"):
        client.messages.create(model="claude", messages=[{"role": "user", "content": "hi"}])
    shelf.transport.flush()
    shelf.close()

    names = [event["name"] for event in _events(http.payloads)]
    assert "trace_error" in names
    assert "trace_finished" in names
    error = _event(http.payloads, "trace_error")["metadata"]
    assert error["provider"] == "anthropic"
    assert error["model"] == "claude"
    assert error["error_type"] == "RuntimeError"
    assert error["error_message"] == "[REDACTED_TEXT]"
