from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from types import SimpleNamespace

import shelfai_sdk.runtime_source as runtime_source
from shelfai_sdk import ShelfAI
from shelfai_sdk.capture_mode import sanitize_event_for_capture_mode
from shelfai_sdk.context_ir import provider_input_ir


class _Response:
    def __init__(self):
        self.id = "msg-runtime-source"
        self.usage = SimpleNamespace(input_tokens=1, output_tokens=1)
        self.stop_reason = "end_turn"
        self.content = [{"type": "text", "text": "done"}]


class _Messages:
    def create(self, **_kwargs):
        return _Response()


class _AnthropicClient:
    def __init__(self):
        self.messages = _Messages()


class _OpenAICompletions:
    def create(self, **_kwargs):
        return SimpleNamespace(
            id="chatcmpl-runtime-source",
            usage=SimpleNamespace(prompt_tokens=1, completion_tokens=1, total_tokens=2),
            choices=[
                {
                    "finish_reason": "stop",
                    "message": {"role": "assistant", "content": "done"},
                }
            ],
        )


class _OpenAIClient:
    def __init__(self):
        self.chat = SimpleNamespace(completions=_OpenAICompletions())


class _HttpClient:
    def __init__(self):
        self.payloads = []

    def post(self, _url, headers=None, json=None):
        self.payloads.append(json)
        return SimpleNamespace(raise_for_status=lambda: None)

    def close(self):
        return None


def _events(payloads):
    return [event for payload in payloads for event in payload.get("events", [])]


def _make_repo(tmp_path: Path, *, revision: str | None = "a" * 40) -> Path:
    root = tmp_path / "customer-repo"
    (root / ".git").mkdir(parents=True)
    if revision is not None:
        (root / ".git" / "HEAD").write_text(f"{revision}\n", encoding="ascii")
    return root


def _compiled_collector(path: Path):
    namespace = {"capture": runtime_source.capture_runtime_source_evidence}
    exec(
        compile(
            "def collect():\n    return capture()\n",
            str(path),
            "exec",
        ),
        namespace,
    )
    return namespace["collect"]


def test_collector_returns_only_repository_relative_observed_evidence(tmp_path):
    root = _make_repo(tmp_path)
    collect = _compiled_collector(root / "app" / "provider_boundary.py")

    evidence = collect()

    assert evidence is not None
    assert evidence["version"] == "1.0"
    assert evidence["truth"] == "observed"
    assert evidence["callsite"] == evidence["stack"][0]
    assert evidence["callsite"]["path"] == "app/provider_boundary.py"
    assert evidence["callsite"]["symbol"] == "collect"
    assert evidence["callsite"]["line"] == 2
    assert evidence["language"] == "python"
    assert evidence["runtime"].startswith(("CPython ", "PyPy ", "Python "))
    assert evidence["git_revision"] == "a" * 40
    assert len(evidence["fingerprint"]) == 64
    assert len(evidence["stack"]) <= 8
    assert str(tmp_path) not in str(evidence)


def test_collector_is_stable_and_thread_safe(tmp_path):
    root = _make_repo(tmp_path, revision="b" * 40)
    collect = _compiled_collector(root / "jobs" / "write.py")

    with ThreadPoolExecutor(max_workers=8) as pool:
        evidence = list(pool.map(lambda _index: collect(), range(32)))

    assert all(item is not None for item in evidence)
    assert {item["fingerprint"] for item in evidence if item} == {evidence[0]["fingerprint"]}
    assert {item.get("git_revision") for item in evidence if item} == {"b" * 40}


def test_collector_handles_missing_git_revision(tmp_path):
    root = _make_repo(tmp_path, revision=None)
    collect = _compiled_collector(root / "worker.py")

    evidence = collect()

    assert evidence is not None
    assert evidence["callsite"]["path"] == "worker.py"
    assert "git_revision" not in evidence


def test_collector_uses_project_marker_when_deployment_has_no_git(tmp_path):
    root = tmp_path / "deployed-app"
    (root / "app").mkdir(parents=True)
    (root / "pyproject.toml").write_text("[project]\nname = 'customer-app'\n", encoding="utf-8")
    collect = _compiled_collector(root / "app" / "workflow.py")

    evidence = collect()

    assert evidence is not None
    assert evidence["callsite"]["path"] == "app/workflow.py"
    assert "git_revision" not in evidence
    assert str(tmp_path) not in str(evidence)


def test_collector_rejects_paths_outside_repository(monkeypatch, tmp_path):
    root = _make_repo(tmp_path)
    outside = tmp_path / "escape.py"
    monkeypatch.setattr(
        runtime_source,
        "_frame_candidates",
        lambda: [(outside, "steal_secrets", 1, "customer")],
    )
    monkeypatch.setattr(runtime_source, "_repository_root", lambda _directory: str(root))

    assert runtime_source.capture_runtime_source_evidence() is None


def test_collector_drops_malicious_symbols_and_sensitive_paths(monkeypatch, tmp_path):
    root = _make_repo(tmp_path)
    path = root / "app" / "safe.py"
    monkeypatch.setattr(
        runtime_source,
        "_frame_candidates",
        lambda: [(path, "api_key=sk-secretvalue12345", 3, "customer")],
    )
    monkeypatch.setattr(runtime_source, "_repository_root", lambda _directory: str(root))

    evidence = runtime_source.capture_runtime_source_evidence()

    assert evidence is not None
    assert evidence["callsite"] == {"path": "app/safe.py", "line": 3}
    assert "sk-secret" not in str(evidence)
    assert runtime_source._safe_relative_path(
        root / "people" / "customer@example.com" / "app.py",
        root,
    ) is None


def test_attachment_rejects_forged_or_absolute_runtime_evidence():
    envelope = provider_input_ir(
        provider="openai",
        messages=[{"role": "user", "content": "hello"}],
        runtime_source={
            "version": "1.0",
            "truth": "observed",
            "callsite": {
                "path": "/Users/customer/private.py",
                "symbol": "send",
                "line": 1,
            },
            "stack": [],
            "language": "python",
            "runtime": "CPython 3.12.11",
            "fingerprint": "a" * 64,
            "source_text": "must not be accepted",
        },
    )

    assert envelope.items[0].runtime_source is None


def test_collector_filters_sdk_framework_stdlib_and_site_packages():
    assert runtime_source._is_excluded_module("shelfai_sdk.wrappers.openai")
    assert runtime_source._is_excluded_module("langchain_core.callbacks")
    assert runtime_source._is_excluded_module("openai.resources.responses")
    assert not runtime_source._is_excluded_module("customer.agents.writer")
    assert runtime_source._looks_like_library_path(Path("/tmp/.venv/lib/python/site-packages/app.py"))
    assert runtime_source._looks_like_library_path(Path("/tmp/node_modules/vendor/app.py"))


def test_collector_is_opt_out_and_fail_open(monkeypatch):
    assert runtime_source.capture_runtime_source_evidence(enabled=False) is None
    monkeypatch.setattr(
        runtime_source,
        "_frame_candidates",
        lambda: (_ for _ in ()).throw(RuntimeError("collector failed")),
    )
    assert runtime_source.capture_runtime_source_evidence() is None


def test_metadata_only_preserves_only_valid_runtime_source_structure():
    valid = {
        "version": "1.0",
        "truth": "observed",
        "callsite": {"path": "app/writer.py", "symbol": "Writer.run", "line": 42},
        "stack": [{"path": "app/writer.py", "symbol": "Writer.run", "line": 42}],
        "language": "python",
        "runtime": "CPython 3.12.11",
        "git_revision": "c" * 40,
        "fingerprint": "d" * 64,
    }
    malicious = {
        "version": "2.0",
        "truth": "definitely-trust-me",
        "callsite": {
            "path": "/Users/customer/secret.py",
            "symbol": "bad symbol with arbitrary text",
            "line": 1,
        },
        "language": "customer secret",
        "runtime": "API key sk-notreallysafe123456789",
        "git_revision": "not-a-revision",
        "fingerprint": "not-a-fingerprint",
        "source_text": "do not serialize me",
    }
    event = {
        "metadata": {
            "context_ir": {
                "items": [
                    {"runtime_source": valid},
                    {"runtime_source": malicious},
                ]
            }
        }
    }

    sanitized = sanitize_event_for_capture_mode(event, "metadata_only")
    kept, rejected = [
        item["runtime_source"]
        for item in sanitized["metadata"]["context_ir"]["items"]
    ]

    assert kept == valid
    assert rejected["truth"] == "[REDACTED_TEXT]"
    assert rejected["version"] == "[REDACTED_TEXT]"
    assert rejected["callsite"]["path"] == "[REDACTED_TEXT]"
    assert rejected["callsite"]["symbol"] == "[REDACTED_TEXT]"
    assert rejected["language"] == "[REDACTED_TEXT]"
    assert rejected["runtime"] == "[REDACTED_TEXT]"
    assert rejected["git_revision"] == "[REDACTED_TEXT]"
    assert rejected["fingerprint"] == "[REDACTED_TEXT]"
    assert rejected["source_text"] == "[REDACTED_TEXT]"


def test_anthropic_wrapper_attaches_runtime_source_to_input_and_output(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(
        api_key="sk-demo",
        agent_id="agent-1",
        capture_mode="full",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=http,
    )
    client = shelf.wrap(_AnthropicClient())

    client.messages.create(
        model="claude",
        system="Write clearly.",
        messages=[{"role": "user", "content": "Draft this."}],
    )
    shelf.transport.flush()
    shelf.close()

    events = _events(http.payloads)
    snapshot = next(event for event in events if event["name"] == "context_snapshot")
    output = next(event for event in events if event["name"] == "trace_output")
    input_items = snapshot["metadata"]["snapshot"]["context_ir"]["items"]
    output_items = output["metadata"]["output"]["context_ir"]["items"]

    assert input_items and output_items
    assert all(item["runtime_source"]["truth"] == "observed" for item in input_items + output_items)
    assert all(not item["materialization"] for item in input_items + output_items)
    assert input_items[0]["runtime_source"]["callsite"]["path"].endswith("tests/test_runtime_source.py")


def test_wrapper_runtime_source_can_be_disabled(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(
        api_key="sk-demo",
        agent_id="agent-1",
        capture_mode="full",
        runtime_source_evidence=False,
        offline_queue_path=str(tmp_path / "queue"),
        http_client=http,
    )
    client = shelf.wrap(_AnthropicClient())

    client.messages.create(model="claude", messages=[{"role": "user", "content": "hi"}])
    shelf.transport.flush()
    shelf.close()

    snapshot = next(event for event in _events(http.payloads) if event["name"] == "context_snapshot")
    items = snapshot["metadata"]["snapshot"]["context_ir"]["items"]
    assert items and all(item["runtime_source"] is None for item in items)


def test_openai_wrapper_attaches_the_same_observed_boundary_to_input_and_output(tmp_path):
    http = _HttpClient()
    shelf = ShelfAI(
        api_key="sk-demo",
        agent_id="agent-1",
        capture_mode="full",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=http,
    )
    client = shelf.wrap(_OpenAIClient())

    client.chat.completions.create(
        model="gpt-test",
        messages=[{"role": "user", "content": "Draft this."}],
    )
    shelf.transport.flush()
    shelf.close()

    events = _events(http.payloads)
    snapshot = next(event for event in events if event["name"] == "context_snapshot")
    output = next(event for event in events if event["name"] == "trace_output")
    input_source = snapshot["metadata"]["snapshot"]["context_ir"]["items"][0]["runtime_source"]
    output_source = output["metadata"]["output"]["context_ir"]["items"][0]["runtime_source"]

    assert input_source == output_source
    assert input_source["truth"] == "observed"
    assert input_source["callsite"]["path"].endswith("tests/test_runtime_source.py")
