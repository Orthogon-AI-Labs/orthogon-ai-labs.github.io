from __future__ import annotations

import logging
from types import SimpleNamespace
from uuid import uuid4

import pytest

from shelfai_sdk.wrappers import autogen, llamaindex


RUNTIME_SOURCE = {
    "version": "1.0",
    "truth": "observed",
    "callsite": {"path": "app/workflow.py", "symbol": "run_workflow", "line": 41},
    "stack": [{"path": "app/workflow.py", "symbol": "run_workflow", "line": 41}],
    "language": "python",
    "runtime": "CPython 3.12.4",
    "git_revision": "a" * 40,
    "fingerprint": "b" * 64,
}


class _ShelfRecorder:
    runtime_source_evidence = True

    def __init__(self) -> None:
        self.events: list[dict] = []
        self.counter = 0

    def generate_trace_id(self) -> str:
        self.counter += 1
        return f"run-{self.counter}"

    def emit_event(self, name, metadata=None, trace_id=None):
        self.events.append({"name": name, "metadata": metadata or {}, "trace_id": trace_id})


class _AutoGenMessageEvent:
    sender = "planner"
    receiver = "writer"
    content = "assignment"


def test_autogen_context_ir_cites_wrapper_boundary_source(monkeypatch):
    monkeypatch.setattr(autogen, "capture_runtime_source_evidence", lambda **_kwargs: RUNTIME_SOURCE)
    shelf = _ShelfRecorder()
    handler = autogen.ShelfAIAutoGenLogHandler(shelf)
    record = logging.LogRecord("autogen", logging.INFO, __file__, 1, "", (), None)
    record.msg = _AutoGenMessageEvent()

    handler.emit(record)

    item = shelf.events[0]["metadata"]["context_ir"]["items"][0]
    assert item["runtime_source"] == RUNTIME_SOURCE
    assert item["runtime_source"]["callsite"]["path"] == "app/workflow.py"


class _LlamaEvent:
    def class_name(self):
        return "RetrievalEndEvent"

    def model_dump(self, mode="json"):
        return {"span_id": "span-1", "nodes": [{"text": "evidence"}]}


def test_llamaindex_context_ir_cites_wrapper_boundary_source(monkeypatch):
    monkeypatch.setattr(llamaindex, "capture_runtime_source_evidence", lambda **_kwargs: RUNTIME_SOURCE)
    shelf = _ShelfRecorder()

    llamaindex.ShelfAILlamaIndexHandler(shelf=shelf).handle(_LlamaEvent())

    item = shelf.events[0]["metadata"]["context_ir"]["items"][0]
    assert item["runtime_source"] == RUNTIME_SOURCE


def test_framework_source_collection_fails_open(monkeypatch):
    def fail(**_kwargs):
        raise RuntimeError("source discovery unavailable")

    monkeypatch.setattr(llamaindex, "capture_runtime_source_evidence", fail)
    shelf = _ShelfRecorder()

    llamaindex.ShelfAILlamaIndexHandler(shelf=shelf).handle(_LlamaEvent())

    item = shelf.events[0]["metadata"]["context_ir"]["items"][0]
    assert item["runtime_source"] is None


def test_langchain_and_langgraph_context_ir_share_source_contract(monkeypatch):
    pytest.importorskip("langchain_core")
    from shelfai_sdk.wrappers.langchain import ShelfAICallbackHandler

    shelf = _ShelfRecorder()
    handler = ShelfAICallbackHandler(shelf)
    monkeypatch.setattr(handler, "_runtime_source", lambda: RUNTIME_SOURCE)

    chain_run_id = uuid4()
    handler.on_chain_start(
        {"name": "RunnableSequence"},
        {"topic": "restaurants"},
        run_id=chain_run_id,
        metadata={"langgraph_node": "writer"},
    )

    event = shelf.events[0]
    item = event["metadata"]["context_ir"]["items"][0]
    assert event["metadata"]["framework"] == "langgraph"
    assert item["runtime_source"] == RUNTIME_SOURCE
    assert "_shelfai_runtime_source" not in str(event["metadata"].get("framework_raw", {}))

    tool_run_id = uuid4()
    handler.on_tool_start({"name": "search"}, "query", run_id=tool_run_id)
    handler.on_tool_end({"result": "evidence"}, run_id=tool_run_id)
    tool_start = shelf.events[-2]["metadata"]["context_ir"]["items"][0]
    tool_end = shelf.events[-1]["metadata"]["context_ir"]["items"][0]
    assert tool_start["runtime_source"] == RUNTIME_SOURCE
    assert tool_end["runtime_source"] == RUNTIME_SOURCE


def test_crewai_listener_context_ir_cites_wrapper_boundary_source(monkeypatch):
    pytest.importorskip("crewai")
    from shelfai_sdk.wrappers import crewai_listener

    monkeypatch.setattr(
        crewai_listener,
        "capture_runtime_source_evidence",
        lambda **_kwargs: RUNTIME_SOURCE,
    )
    shelf = _ShelfRecorder()
    listener = object.__new__(crewai_listener.ShelfAICrewListener)
    listener.shelf = shelf
    ir = crewai_listener.ContextIR(
        items=[
            crewai_listener.context_item(
                "instruction", "Write naturally", source="crewai.task"
            )
        ]
    )

    metadata = listener._metadata("TaskStartedEvent", {}, ir)

    assert metadata["context_ir"]["items"][0]["runtime_source"] == RUNTIME_SOURCE
