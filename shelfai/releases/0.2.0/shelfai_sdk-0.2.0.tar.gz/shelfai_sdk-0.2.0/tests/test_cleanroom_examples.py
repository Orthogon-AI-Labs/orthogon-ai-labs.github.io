from __future__ import annotations

import importlib
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]


def test_cleanroom_examples_are_import_safe():
    sys.path.insert(0, str(ROOT))
    try:
        for name in ("raw_anthropic", "raw_openai", "langchain_langgraph", "crewai_app", "claude_agent", "cli_workflow", "fastapi_replay"):
            importlib.import_module(f"examples.cleanroom.{name}")
    finally:
        sys.path.remove(str(ROOT))


def test_cleanroom_contract_has_no_customer_side_replay_glue():
    files = list((ROOT / "examples" / "cleanroom").glob("*.py"))
    rendered = "\n".join(path.read_text() for path in files)
    forbidden = ("SHELFAI_EXPERIMENT_ID", "latest-context", "transport.flush", "trace_id", "ReplayHandler(", "optional_component", "_framework_optional")
    assert not any(token in rendered for token in forbidden)
