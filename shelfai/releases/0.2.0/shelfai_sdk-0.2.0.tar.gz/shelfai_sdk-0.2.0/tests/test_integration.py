from __future__ import annotations

import asyncio
from types import SimpleNamespace

from shelfai_sdk import ShelfAI, connect, integrate


class FakeShelf:
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.closed = False

    def wrap(self, client):
        client.messages.create = lambda **kwargs: ("wrapped", kwargs)
        return client

    def close(self):
        self.closed = True

    def execution(self):
        class Scope:
            def __enter__(self):
                return "trace_1"

            def __exit__(self, *_args):
                return None
        return Scope()

    def replay_app(self):
        return object()


def provider_client():
    return SimpleNamespace(messages=SimpleNamespace(create=lambda **kwargs: kwargs, stream=lambda **kwargs: kwargs))


def test_disabled_integration_is_exactly_fail_open():
    client = provider_client()
    original_create = client.messages.create
    handle = integrate(client=client, enabled=False)
    assert handle.client is client
    assert client.messages.create is original_create
    assert handle.status.reason == "disabled"
    assert not handle.status.active


def test_active_integration_wraps_and_owns_lifecycle():
    client = provider_client()
    handle = integrate(client=client, enabled=True, shelf_class=FakeShelf, api_key="x", agent_id="a")
    assert handle.client is client
    assert handle.status.active
    assert handle.client.messages.create(model="m")[0] == "wrapped"
    assert handle.run(lambda: 42) == 42
    assert asyncio.run(handle.run_async(lambda: asyncio.sleep(0, result=43))) == 43
    shelf = handle.shelf
    handle.close()
    assert shelf.closed


def test_hostile_client_and_partial_mutation_restore_fail_open():
    class Hostile:
        @property
        def messages(self):
            raise RuntimeError("password=should-not-escape")

    hostile = Hostile()
    handle = integrate(client=hostile, enabled=True, shelf_class=FakeShelf)
    assert handle.client is hostile
    assert handle.status.error_type == "RuntimeError"

    client = provider_client()
    original_create = client.messages.create
    original_stream = client.messages.stream

    class Partial(FakeShelf):
        def wrap(self, candidate):
            candidate.messages.create = lambda: "changed"
            candidate.messages.stream = lambda: "changed"
            raise ValueError("later provider failed")

    failed = integrate(client=client, enabled=True, shelf_class=Partial)
    assert failed.client is client
    assert client.messages.create is original_create
    assert client.messages.stream is original_stream


def test_mixed_provider_introspection_failure_restores_prior_bindings():
    messages = SimpleNamespace(create=lambda: "create", stream=lambda: "stream")
    original_create = messages.create
    original_stream = messages.stream

    class Mixed:
        def __init__(self, provider_messages):
            self.messages = provider_messages

        @property
        def responses(self):
            # Simulate a lazy provider surface failing after Anthropic was
            # successfully inspected and snapshotted.
            messages.create = lambda: "mutated"
            messages.stream = lambda: "mutated"
            raise RuntimeError("provider import failed")

    client = Mixed(messages)
    handle = integrate(client=client, enabled=True, shelf_class=FakeShelf)
    assert handle.client is client
    assert messages.create is original_create
    assert messages.stream is original_stream


def test_connect_is_optional_and_class_conveniences_exist(monkeypatch):
    inactive = connect(enabled=False)
    assert inactive.shelf is None
    assert ShelfAI.integrate and ShelfAI.connect

    active = connect(enabled=True, shelf_class=FakeShelf)
    assert active.shelf is not None
    assert active.status.active


def test_inactive_replay_app_is_mount_safe():
    handle = connect(enabled=False)
    sent = []

    async def receive():
        return {"type": "http.request", "body": b"", "more_body": False}

    async def send(message):
        sent.append(message)

    asyncio.run(handle.replay_app()({"type": "http", "method": "POST"}, receive, send))
    assert sent[0]["status"] == 503


def test_inactive_handoff_is_identity_preserving():
    handle = connect(enabled=False)
    value = {"assignment": "unchanged"}
    assert handle.handoff(value, name="writer_assignment") is value


def test_execution_instrumentation_failure_does_not_break_workflow():
    class BrokenShelf(FakeShelf):
        def execution(self):
            raise RuntimeError("telemetry unavailable")

    handle = connect(enabled=True, shelf_class=BrokenShelf)
    assert handle.run(lambda: "application-result") == "application-result"
