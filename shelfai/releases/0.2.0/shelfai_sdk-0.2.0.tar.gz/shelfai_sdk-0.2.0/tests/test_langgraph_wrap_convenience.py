from __future__ import annotations

import builtins
import importlib
import sys

from shelfai_sdk.wrappers.langgraph import wrap_graph


class _DummyShelf:
    pass


class _DummyGraph:
    def __init__(self) -> None:
        self.config = None

    def with_config(self, config):
        self.config = config
        return self


def test_wrap_graph_can_build_a_handler_when_none_is_provided(monkeypatch):
    dummy_shelf = _DummyShelf()

    monkeypatch.setattr("shelfai_sdk.client.ShelfAI", lambda: dummy_shelf)

    graph = _DummyGraph()
    wrapped = wrap_graph(graph)

    assert wrapped is graph
    assert len(graph.config["callbacks"]) == 1
    assert graph.config["callbacks"][0].shelf is dummy_shelf


def test_wrap_graph_rejects_invalid_graph_before_touching_default_client(monkeypatch):
    def boom():
        raise AssertionError("default client should not be constructed for invalid graphs")

    monkeypatch.setattr("shelfai_sdk.client.ShelfAI", boom)

    try:
        wrap_graph(object())
    except TypeError as exc:
        assert "LangGraph StateGraph or compiled graph" in str(exc)
    else:
        raise AssertionError("wrap_graph() should reject non-graph inputs")


def test_wrappers_preserves_langchain_exports_when_langgraph_is_missing(monkeypatch):
    original_import = builtins.__import__

    def guarded_import(name, globals=None, locals=None, fromlist=(), level=0):
        if level == 1 and name == "langgraph" and globals and globals.get("__package__") == "shelfai_sdk.wrappers":
            raise ImportError("simulated missing langgraph")
        return original_import(name, globals, locals, fromlist, level)

    monkeypatch.setattr(builtins, "__import__", guarded_import)
    sys.modules.pop("shelfai_sdk.wrappers", None)
    sys.modules.pop("shelfai_sdk.wrappers.langgraph", None)

    wrappers = importlib.import_module("shelfai_sdk.wrappers")

    assert wrappers.ShelfAICallbackHandler is not None
    assert wrappers.wrap_graph is None
