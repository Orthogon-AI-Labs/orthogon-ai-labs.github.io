from __future__ import annotations

from types import SimpleNamespace

import pytest

from shelfai_sdk.integration import IntegrationStatus, ShelfAIIntegration as Handle
from shelfai_sdk.wrappers.claude_agent import ShelfAIAdapterCollisionError, ShelfAIIntegration


class Shelf:
    def __init__(self):
        self.closed = False

    def close(self):
        self.closed = True


def adapter(monkeypatch, shelf):
    value = ShelfAIIntegration(shelf=shelf)
    monkeypatch.setattr(value, "hooks", lambda: {"Stop": ["shelf-stop"], "PreToolUse": ["shelf-pre"]})
    monkeypatch.setattr(value, "mcp_servers", lambda: {"shelfai": "shelf-server"})
    return value


def test_install_preserves_customer_hooks_and_servers(monkeypatch):
    shelf = Shelf()
    value = adapter(monkeypatch, shelf)
    options = SimpleNamespace(hooks={"Stop": ["customer-stop"]}, mcp_servers={"other": "server"})
    assert value.install(options) is options
    assert options.hooks["Stop"] == ["customer-stop", "shelf-stop"]
    assert options.hooks["PreToolUse"] == ["shelf-pre"]
    assert options.mcp_servers == {"other": "server", "shelfai": "shelf-server"}
    value.close()
    assert not shelf.closed  # injected shelf remains owned by the public handle


def test_install_collision_is_atomic(monkeypatch):
    shelf = Shelf()
    value = adapter(monkeypatch, shelf)
    hooks = {"Stop": ["customer"]}
    servers = {"shelfai": "customer-server"}
    options = SimpleNamespace(hooks=hooks, mcp_servers=servers)
    with pytest.raises(ShelfAIAdapterCollisionError):
        value.install(options)
    assert options.hooks is hooks and options.mcp_servers is servers
    assert not shelf.closed


def test_handle_deactivation_clears_and_closes_shelf():
    shelf = Shelf()
    handle = Handle(client=None, shelf=shelf, status=IntegrationStatus(True, True, False, "active"))
    handle.deactivate("adapter_collision", ValueError("secret should not appear"))
    assert handle.shelf is None and shelf.closed
    assert handle.status.reason == "adapter_collision"
    assert handle.status.error_type == "ValueError"
