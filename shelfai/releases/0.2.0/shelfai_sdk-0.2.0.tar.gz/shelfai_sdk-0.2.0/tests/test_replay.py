from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shelfai_sdk import ReplayRequestError, ShelfAI, verify_replay_request


SECRET = "customer-replay-secret-123"


class FakeResponse:
    status_code = 200

    def __init__(self, payload):
        self.payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self.payload


class FakeHTTPClient:
    def __init__(self):
        self.calls = []

    def request(self, method, url, headers=None, **kwargs):
        self.calls.append((method, url, headers, kwargs))
        return FakeResponse(
            {
                "experiment_id": "exp-123",
                "agent_id": "writer",
                "baseline_trace_id": "trace-baseline",
                "patches": [
                    {
                        "patch_id": "patch-1",
                        "source": "anthropic.messages",
                        "original_content": "Write a forced contrast.",
                        "replacement_content": "Describe both places naturally.",
                    }
                ],
            }
        )

    def post(self, url, **kwargs):
        self.calls.append(("POST", url, kwargs.get("headers"), kwargs))
        return FakeResponse({})

    def close(self):
        return None


def replay_body(**overrides):
    payload = {
        "version": "1.0",
        "event": "context.experiment.replay_requested",
        "delivery_id": "replay-delivery-1",
        "requested_at": datetime.now(timezone.utc).isoformat(),
        "experiment_id": "exp-123",
        "baseline_trace_id": "trace-baseline",
        "agent_id": "writer",
        "bundle_path": "/api/context/experiments/exp-123/bundle",
        "verify_path": "/api/context/experiments/exp-123/replay",
        **overrides,
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def signed_headers(body, secret=SECRET):
    digest = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return {"X-ShelfAI-Signature": f"sha256={digest}"}


def session_dispatch_body(**overrides):
    payload = {
        "version": "1.0",
        "event": "replay.session.dispatch",
        "tenant_id": "tenant-a",
        "target_name": "default",
        "replay_session": "srp_opaque_session",
        "requested_at": datetime.now(timezone.utc).isoformat(),
        **overrides,
    }
    return json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()


def test_verify_replay_request_is_signed_and_agent_scoped():
    body = replay_body()
    request = verify_replay_request(
        body,
        signed_headers(body),
        signing_secret=SECRET,
        agent_id="writer",
    )

    assert request.experiment_id == "exp-123"
    assert request.delivery_id == "replay-delivery-1"

    with pytest.raises(ReplayRequestError, match="signature"):
        verify_replay_request(
            body,
            signed_headers(body, "wrong-secret-value"),
            signing_secret=SECRET,
            agent_id="writer",
        )

    other_agent = replay_body(agent_id="another-agent")
    with pytest.raises(ReplayRequestError, match="different agent"):
        verify_replay_request(other_agent, signed_headers(other_agent), signing_secret=SECRET, agent_id="writer")


def test_standard_replay_handler_scopes_override_to_one_workflow(tmp_path):
    http = FakeHTTPClient()
    observed = {}
    shelf = None

    async def run_workflow(request):
        observed["request"] = request
        observed["active"] = shelf.experiment_id
        _system, messages, _tools, metadata = shelf.apply_experiment_overrides(
            system=None,
            messages=[{"role": "user", "content": "Write a forced contrast."}],
        )
        observed["message"] = messages[0]["content"]
        observed["metadata"] = metadata
        shelf.snapshot(shelf.extract_context_from_call(None, messages))
        return "trace_stale_callback_value"

    shelf = ShelfAI(
        api_key="sk-test",
        agent_id="writer",
        api_url="http://example.test",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=http,
        start_background_threads=False,
        replay=run_workflow,
        replay_signing_secret=SECRET,
    )
    body = replay_body()

    result = asyncio.run(shelf.replay_handler()(body, signed_headers(body)))

    assert result["replay_trace_id"].startswith("trace_")
    assert result["replay_trace_id"] != "trace_stale_callback_value"
    assert observed["active"] == "exp-123"
    assert observed["message"] == "Describe both places naturally."
    assert observed["metadata"]["applied_patch_ids"] == ["patch-1"]
    assert shelf.experiment_id is None
    assert http.calls[0][1].endswith("/api/context/experiments/exp-123/bundle")

    with pytest.raises(ReplayRequestError, match="already been handled"):
        asyncio.run(shelf.replay_handler()(body, signed_headers(body)))


def test_integrate_replay_app_accepts_opaque_session_dispatch_default_target(tmp_path):
    class FakeOpenAICompletions:
        def __init__(self):
            self.calls = []

        def create(self, **kwargs):
            self.calls.append(kwargs)
            return SimpleNamespace(
                id="chatcmpl-replay",
                usage=SimpleNamespace(prompt_tokens=3, completion_tokens=2, total_tokens=5),
                choices=[SimpleNamespace(finish_reason="stop")],
            )

    class FakeOpenAIClient:
        def __init__(self):
            self.chat = SimpleNamespace(completions=FakeOpenAICompletions())

    class SessionHTTPClient:
        def __init__(self):
            self.trace_id = ""
            self.requests = []
            self.posts = []

        def request(self, method, url, headers=None, **kwargs):
            self.requests.append((method, url, kwargs.get("json")))
            if url.endswith("/api/replay-sessions/activate"):
                assert kwargs["json"] == {"replay_session": "srp_opaque_session", "target_name": "default"}
                return FakeResponse(
                    {
                        "session_id": "rps_bound_session",
                        "tenant_id": "tenant-a",
                        "target_name": "default",
                        "expires_at": (datetime.now(timezone.utc) + timedelta(minutes=5)).isoformat(),
                    }
                )
            if url.endswith("/api/replay-sessions/bundle"):
                assert kwargs["json"] == {"replay_session": "srp_opaque_session", "target_name": "default"}
                return FakeResponse(
                    {
                        "replay_session_id": "rps_bound_session",
                        "replay_target": "default",
                        "bundle": {
                            "experiment_id": "exp_internal",
                            "baseline_trace_id": "trace_baseline",
                            "agent_id": "writer",
                            "patches": [
                                {
                                    "patch_id": "patch-1",
                                    "source": "openai.messages",
                                    "original_content": "old context",
                                    "replacement_content": "better context",
                                }
                            ],
                        },
                    }
                )
            if url.endswith("/api/replay-sessions/rps_bound_session/trace"):
                return FakeResponse(
                    {
                        "trace_id": self.trace_id,
                        "replay_session_id": "rps_bound_session",
                        "tenant_id": "tenant-a",
                        "target_name": "default",
                        "sdk_captured": True,
                        "persisted": True,
                        "offline": False,
                    }
                )
            if url.endswith("/api/replay-sessions/rps_bound_session/complete"):
                return FakeResponse({"status": "completed"})
            raise AssertionError(f"unexpected request: {method} {url}")

        def post(self, url, headers=None, json=None):
            self.posts.append((url, json))
            if url.endswith("/api/events/batch"):
                self.trace_id = json["events"][0]["trace_id"]
            return FakeResponse({})

        def close(self):
            return None

    http = SessionHTTPClient()
    provider = FakeOpenAIClient()
    handle = None

    def workflow(_invocation):
        handle.client.chat.completions.create(
            model="gpt-test",
            messages=[{"role": "user", "content": "old context"}],
        )
        return {"application": "result"}

    handle = ShelfAI.integrate(
        client=provider,
        enabled=True,
        api_key="sk-test",
        agent_id="writer",
        api_url="https://shelf.example",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=http,
        start_background_threads=False,
        replay=workflow,
        replay_signing_secret=SECRET,
    )
    body = session_dispatch_body()
    sent = []
    received = False

    async def receive():
        nonlocal received
        if received:
            return {"type": "http.disconnect"}
        received = True
        return {"type": "http.request", "body": body, "more_body": False}

    async def send(message):
        sent.append(message)

    try:
        asyncio.run(
            handle.replay_app()(
                {
                    "type": "http",
                    "method": "POST",
                    "headers": [(b"x-shelfai-signature", signed_headers(body)["X-ShelfAI-Signature"].encode())],
                },
                receive,
                send,
            )
        )
    finally:
        handle.close()

    assert handle.status.active
    assert sent[0]["status"] == 200
    result = json.loads(sent[1]["body"])
    assert result == {"replay_trace_id": http.trace_id}
    assert result["replay_trace_id"].startswith("trace_")
    assert provider.chat.completions.calls[0]["messages"][0]["content"] == "better context"
    assert [call[0] for call in http.requests] == ["POST", "POST", "GET", "POST"]
    assert http.requests[-1][2] == {"succeeded": True}


def test_replay_configuration_fails_closed(tmp_path):
    shelf = ShelfAI(
        api_key="sk-test",
        agent_id="writer",
        offline_queue_path=str(tmp_path / "queue"),
        start_background_threads=False,
    )
    with pytest.raises(ValueError, match="workflow callback"):
        shelf.replay_handler()


def test_process_environment_cannot_activate_an_experiment(tmp_path, monkeypatch):
    monkeypatch.setenv("SHELFAI_EXPERIMENT_ID", "exp-process-wide")
    shelf = ShelfAI(api_key="sk-test", agent_id="writer", offline_queue_path=str(tmp_path / "q"), start_background_threads=False)
    assert shelf.experiment_id is None


def test_native_async_replay_does_not_use_thread_offload(tmp_path, monkeypatch):
    shelf = None

    async def workflow():
        shelf.snapshot(shelf.extract_context_from_call(None, [{"role": "user", "content": "hi"}]))

    async def forbidden_to_thread(*_args, **_kwargs):
        raise AssertionError("native async replay should stay on the event loop")

    monkeypatch.setattr("shelfai_sdk.client.asyncio.to_thread", forbidden_to_thread)
    shelf = ShelfAI(api_key="sk-test", agent_id="writer", offline_queue_path=str(tmp_path / "q"), start_background_threads=False, http_client=FakeHTTPClient(), replay=workflow, replay_signing_secret=SECRET)
    body = replay_body(delivery_id="native-async")
    result = asyncio.run(shelf.replay_handler()(body, signed_headers(body)))
    assert result["replay_trace_id"].startswith("trace_")


def test_offline_queue_check_reads_complete_queue_and_exact_matches(tmp_path):
    shelf = ShelfAI(api_key="sk-test", agent_id="writer", offline_queue_path=str(tmp_path / "q"), start_background_threads=False, http_client=FakeHTTPClient())

    class Queue:
        def size(self):
            return 10001

        def load_batch(self, limit):
            assert limit == 10001
            return [SimpleNamespace(event_json=json.dumps({"trace_id": "trace_exact"}))]

    from types import SimpleNamespace
    shelf.offline_queue = Queue()
    assert shelf._trace_is_offline("trace_exact")
    assert not shelf._trace_is_offline("trace")


def test_standard_asgi_replay_app_preserves_signed_body(tmp_path):
    shelf = None

    def workflow():
        shelf.snapshot(shelf.extract_context_from_call(None, [{"role": "user", "content": "hi"}]))

    shelf = ShelfAI(
        api_key="sk-test",
        agent_id="writer",
        offline_queue_path=str(tmp_path / "queue"),
        start_background_threads=False,
        http_client=FakeHTTPClient(),
        replay=workflow,
        replay_signing_secret=SECRET,
    )
    body = replay_body(delivery_id="replay-asgi-1")
    sent = []
    received = False

    async def receive():
        nonlocal received
        if received:
            return {"type": "http.disconnect"}
        received = True
        return {"type": "http.request", "body": body, "more_body": False}

    async def send(message):
        sent.append(message)

    asyncio.run(
        shelf.replay_app()(
            {
                "type": "http",
                "method": "POST",
                "headers": [(b"x-shelfai-signature", signed_headers(body)["X-ShelfAI-Signature"].encode())],
            },
            receive,
            send,
        )
    )

    assert sent[0]["status"] == 200
    assert json.loads(sent[1]["body"])["replay_trace_id"].startswith("trace_")


def test_replay_asgi_rejects_oversized_body_before_callback(tmp_path):
    called = False

    def workflow():
        nonlocal called
        called = True

    shelf = ShelfAI(api_key="sk-test", agent_id="writer", offline_queue_path=str(tmp_path / "q"), start_background_threads=False, replay=workflow, replay_signing_secret=SECRET)
    sent = []

    async def receive():
        raise AssertionError("body must not be read")

    async def send(message):
        sent.append(message)

    asyncio.run(shelf.replay_app()({"type": "http", "method": "POST", "headers": [(b"content-length", b"70000")]}, receive, send))
    assert sent[0]["status"] == 413
    assert not called
