"""Regression tests for the findings of the 438d06e adversarial release review."""

from __future__ import annotations

import asyncio
import inspect
import json
import os
import tempfile
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest

from shelfai_sdk import ShelfAI
from shelfai_sdk.capture_mode import sanitize_event_for_capture_mode
from shelfai_sdk.context_ir import _jsonable
from shelfai_sdk.integration import integrate
from shelfai_sdk.lineage import materializer_payload, repository_relative_path
from shelfai_sdk.queue import OfflineQueue


def _ok(_request: httpx.Request) -> httpx.Response:
    return httpx.Response(200, json={"events_ingested": 1, "capture_policy": {}})


def _shelf(tmp_path, **overrides) -> ShelfAI:
    options = dict(
        api_key="test-key",
        agent_id="agent-a",
        api_url="http://127.0.0.1:9",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=httpx.Client(transport=httpx.MockTransport(_ok)),
        start_background_threads=False,
    )
    options.update(overrides)
    return ShelfAI(**options)


def _events(shelf: ShelfAI) -> list[dict]:
    return list(shelf.transport._buffer)


class _Usage:
    prompt_tokens = 4
    completion_tokens = 2
    total_tokens = 6


class _Message:
    def __init__(self, content):
        self.role = "assistant"
        self.content = content
        self.tool_calls = None


class _Choice:
    def __init__(self, content):
        self.message = _Message(content)
        self.finish_reason = "stop"


class _Response:
    def __init__(self, content="a complete model answer with several words in it"):
        self.id = "chatcmpl-1"
        self.usage = _Usage()
        self.model = "gpt-4o-mini"
        self.choices = [_Choice(content)]


class FakeOpenAI:
    def __init__(self, response_factory=_Response):
        self.calls = []
        client = self

        class Completions:
            def create(self_inner, **kwargs):
                client.calls.append(kwargs)
                return response_factory()

        self.chat = SimpleNamespace(completions=Completions())


# --------------------------------------------------------------------------- P1-1 streaming
class _FinalMessage:
    id = "msg_1"
    stop_reason = "end_turn"
    usage = SimpleNamespace(input_tokens=3, output_tokens=2, cache_read_input_tokens=0, cache_creation_input_tokens=0)
    content = [SimpleNamespace(type="text", text="hello world from the streamed reply")]


class FakeMessageStream:
    """Mimics anthropic.lib.streaming.MessageStream: iteration, text_stream, get_final_message."""

    def __init__(self):
        self.events = [SimpleNamespace(type="message_start"), SimpleNamespace(type="message_stop")]

    @property
    def text_stream(self):
        yield "hel"
        yield "lo"

    def __iter__(self):
        return iter(self.events)

    def get_final_message(self):
        return _FinalMessage()


class FakeMessageStreamManager:
    """Mimics anthropic.lib.streaming.MessageStreamManager: only a context manager."""

    def __init__(self):
        self.entered = False
        self.exited = False

    def __enter__(self):
        self.entered = True
        return FakeMessageStream()

    def __exit__(self, exc_type, exc, tb):
        self.exited = True
        return False


class FakeAsyncMessageStream(FakeMessageStream):
    def __aiter__(self):
        async def generate():
            for event in self.events:
                yield event

        return generate()

    async def get_final_message(self):
        return _FinalMessage()


class FakeAsyncMessageStreamManager:
    def __init__(self):
        self.entered = False
        self.exited = False

    async def __aenter__(self):
        self.entered = True
        return FakeAsyncMessageStream()

    async def __aexit__(self, exc_type, exc, tb):
        self.exited = True
        return False


def _anthropic_client(manager_factory):
    managers = []

    class Messages:
        def create(self, **kwargs):
            return _FinalMessage()

        def stream(self, **kwargs):
            manager = manager_factory()
            managers.append(manager)
            return manager

    return SimpleNamespace(messages=Messages()), managers


def test_anthropic_stream_context_manager_yields_the_real_message_stream(tmp_path):
    shelf = _shelf(tmp_path)
    client, managers = _anthropic_client(FakeMessageStreamManager)
    wrapped = shelf.wrap(client)

    with wrapped.messages.stream(model="claude", max_tokens=8, messages=[{"role": "user", "content": "hi"}]) as stream:
        text = "".join(stream.text_stream)
        final = stream.get_final_message()
        seen = [event.type for event in stream]

    assert text == "hello"
    assert final.stop_reason == "end_turn"
    assert seen == ["message_start", "message_stop"]
    assert managers[0].entered and managers[0].exited
    names = [event["name"] for event in _events(shelf)]
    assert names[:2] == ["trace_started", "context_snapshot"]
    assert "llm_call" in names and "trace_output" in names and names[-1] == "trace_finished"


def test_anthropic_async_stream_context_manager_is_supported(tmp_path):
    shelf = _shelf(tmp_path)
    client, managers = _anthropic_client(FakeAsyncMessageStreamManager)
    wrapped = shelf.wrap(client)

    async def run():
        async with wrapped.messages.stream(model="claude", max_tokens=8, messages=[]) as stream:
            events = [event.type async for event in stream]
            final = await stream.get_final_message()
        return events, final

    events, final = asyncio.run(run())
    assert events == ["message_start", "message_stop"]
    assert final.id == "msg_1"
    assert managers[0].entered and managers[0].exited
    assert "llm_call" in [event["name"] for event in _events(shelf)]


def test_real_anthropic_client_streaming_round_trip(tmp_path):
    anthropic = pytest.importorskip("anthropic")
    # Anthropic 1.x moved its transport contract to httpx2 while earlier
    # releases used httpx. Build the mock with the exact module the installed
    # client validates, so this remains a real client round-trip on both lines.
    anthropic_http = getattr(pytest.importorskip("anthropic._base_client"), "httpx2", httpx)

    def handler(request):
        events = [
            ("message_start", {"type": "message_start", "message": {"id": "m1", "type": "message", "role": "assistant", "model": "c", "content": [], "stop_reason": None, "stop_sequence": None, "usage": {"input_tokens": 5, "output_tokens": 0}}}),
            ("content_block_start", {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}}),
            ("content_block_delta", {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "streamed"}}),
            ("content_block_stop", {"type": "content_block_stop", "index": 0}),
            ("message_delta", {"type": "message_delta", "delta": {"stop_reason": "end_turn", "stop_sequence": None}, "usage": {"output_tokens": 3}}),
            ("message_stop", {"type": "message_stop"}),
        ]
        body = "".join(f"event: {name}\ndata: {json.dumps(payload)}\n\n" for name, payload in events)
        return anthropic_http.Response(200, headers={"content-type": "text/event-stream"}, content=body.encode())

    raw = anthropic.Anthropic(
        api_key="x",
        base_url="http://provider.mock",
        http_client=anthropic_http.Client(transport=anthropic_http.MockTransport(handler)),
    )
    shelf = _shelf(tmp_path)
    wrapped = shelf.wrap(raw)
    with wrapped.messages.stream(model="c", max_tokens=5, messages=[{"role": "user", "content": "hi"}]) as stream:
        text = "".join(stream.text_stream)
        final = stream.get_final_message()
    assert text == "streamed"
    assert final.content[0].text == "streamed"
    names = [event["name"] for event in _events(shelf)]
    assert "llm_call" in names and "trace_output" in names


# --------------------------------------------------------------------------- P2 fail-open
def test_cyclic_customer_objects_never_break_the_provider_call(tmp_path):
    shelf = _shelf(tmp_path)
    client = shelf.wrap(FakeOpenAI())

    class Node:
        def __init__(self):
            self.text = "cyclic"
            self.parent = self

    response = client.chat.completions.create(model="m", messages=[{"role": "user", "content": Node()}])
    assert response.choices[0].message.content
    assert "<cycle>" in json.dumps(_jsonable(Node()))
    assert "context_snapshot" in [event["name"] for event in _events(shelf)]


def test_response_introspection_errors_never_break_the_provider_call(tmp_path):
    class ExplodingResponse:
        id = "r"

        @property
        def usage(self):
            raise RuntimeError("usage exploded")

    shelf = _shelf(tmp_path)
    client = shelf.wrap(FakeOpenAI(response_factory=ExplodingResponse))
    response = client.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}])
    assert isinstance(response, ExplodingResponse)
    names = [event["name"] for event in _events(shelf)]
    assert names[0] == "trace_started" and names[-1] == "trace_finished"


def test_telemetry_failure_before_the_call_is_swallowed(tmp_path, monkeypatch):
    shelf = _shelf(tmp_path)
    client = shelf.wrap(FakeOpenAI())

    def broken(*args, **kwargs):
        raise ValueError("observer bug")

    monkeypatch.setattr(shelf, "extract_context_from_call", broken)
    response = client.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}])
    assert response.choices[0].message.content
    assert client.calls, "provider was still called"


def test_telemetry_warning_contains_only_operation_and_exception_class(tmp_path, monkeypatch, caplog):
    shelf = _shelf(tmp_path)
    client = shelf.wrap(FakeOpenAI())

    def broken(*args, **kwargs):
        raise RuntimeError("password=hunter2 and token=secret-value")

    monkeypatch.setattr(shelf, "extract_context_from_call", broken)
    with caplog.at_level("WARNING", logger="shelfai_sdk"):
        assert client.chat.completions.create(model="m", messages=[]) is not None
    messages = "\n".join(record.getMessage() for record in caplog.records)
    assert "capture_input" in messages and "RuntimeError" in messages
    assert "hunter2" not in messages and "secret-value" not in messages


# --------------------------------------------------------------------------- P2 queue fallback
@pytest.mark.skipif(os.name == "nt" or os.geteuid() == 0, reason="permission bits are not enforced")
def test_offline_queue_falls_back_when_the_working_directory_is_read_only(tmp_path):
    read_only = tmp_path / "ro"
    read_only.mkdir()
    read_only.chmod(0o500)
    try:
        queue = OfflineQueue(str(read_only / "queue"))
        assert queue.available is True
        assert queue.root is not None and not str(queue.root).startswith(str(read_only))
        queue.enqueue("agent-a", {"name": "x"})
        assert queue.size() == 1
        integration = integrate(
            client=FakeOpenAI(),
            api_key="k",
            agent_id="a",
            api_url="http://127.0.0.1:9",
            offline_queue_path=str(read_only / "queue"),
            http_client=httpx.Client(transport=httpx.MockTransport(_ok)),
            start_background_threads=False,
        )
        assert integration.status.active, integration.status
        integration.close()
    finally:
        read_only.chmod(0o700)


# --------------------------------------------------------------------------- P1-2 metadata_only
def _ir_event(raw_payload, item_type="tool_call"):
    return {
        "name": "context_snapshot",
        "metadata": {
            "snapshot": {
                "context_ir": {
                    "version": "1.0",
                    "items": [{"id": "ctx-1", "type": item_type, "raw_payload": raw_payload, "rendered_preview": "preview text"}],
                }
            }
        },
    }


def _first_item(event):
    return event["metadata"]["snapshot"]["context_ir"]["items"][0]


def test_metadata_only_redacts_tool_input_values_but_keeps_block_labels():
    payload = {
        "type": "tool_use",
        "id": "toolu_1",
        "name": "lookup_customer",
        "input": {"name": "Johnathan Q. Customer", "reason": "medical dispute", "status": "DECLINED", "id": "cust-777"},
    }
    item = _first_item(sanitize_event_for_capture_mode(_ir_event(payload), "metadata_only"))
    assert item["raw_payload"]["type"] == "tool_use"
    assert item["raw_payload"]["id"] == "toolu_1"
    assert item["raw_payload"]["name"] == "lookup_customer"
    assert item["raw_payload"]["input"] == {
        "name": "[REDACTED_TEXT]",
        "reason": "[REDACTED_TEXT]",
        "status": "[REDACTED_TEXT]",
        "id": "[REDACTED_TEXT]",
    }
    assert item["rendered_preview"] == "[REDACTED_TEXT]"


def test_metadata_only_keeps_tool_definition_names_but_not_descriptions():
    payload = {"type": "function", "function": {"name": "lookup", "description": "Look up a customer record", "parameters": {"type": "object", "properties": {"name": {"type": "string", "description": "customer name"}}}}}
    item = _first_item(sanitize_event_for_capture_mode(_ir_event(payload, "tool_definition"), "metadata_only"))
    function = item["raw_payload"]["function"]
    assert function["name"] == "lookup"
    assert function["description"] == "[REDACTED_TEXT]"
    assert function["parameters"]["properties"]["name"]["description"] == "[REDACTED_TEXT]"


def test_metadata_only_redacts_participant_names_and_dict_tool_results():
    participant = {"role": "user", "name": "Jane Doe", "content": "hello"}
    item = _first_item(sanitize_event_for_capture_mode(_ir_event(participant, "message"), "metadata_only"))
    assert item["raw_payload"] == {"role": "user", "name": "[REDACTED_TEXT]", "content": "[REDACTED_TEXT]"}

    tool_result = {"role": "tool", "tool_call_id": "call_1", "content": {"name": "Jane Doe", "status": "DECLINED", "reason": "balance"}}
    item = _first_item(sanitize_event_for_capture_mode(_ir_event(tool_result, "tool_result"), "metadata_only"))
    assert item["raw_payload"]["tool_call_id"] == "call_1"
    assert item["raw_payload"]["content"] == {"name": "[REDACTED_TEXT]", "status": "[REDACTED_TEXT]", "reason": "[REDACTED_TEXT]"}


def test_metadata_only_validates_structural_fields_before_preserving_them():
    payload = {
        "type": "medical diagnosis requested",
        "role": "human with a medical condition",
        "id": "please call Jane about her diagnosis",
        "name": "Jane Doe needs oncology follow-up",
        "content": "private details",
    }
    item = _first_item(sanitize_event_for_capture_mode(_ir_event(payload, "message"), "metadata_only"))
    assert item["raw_payload"] == {
        "type": "[REDACTED_TEXT]",
        "role": "[REDACTED_TEXT]",
        "id": "[REDACTED_TEXT]",
        "name": "[REDACTED_TEXT]",
        "content": "[REDACTED_TEXT]",
    }


def test_metadata_only_still_preserves_framework_and_experiment_structure():
    event = {
        "name": "trace_finished",
        "metadata": {
            "framework": "crewai",
            "status": "completed",
            "sender": "planner",
            "experiment_id": "exp_" + "a" * 32,
            "baseline_trace_id": "trace_1234abcd",
            "applied_patch_ids": ["patch_" + "b" * 32],
            "replay_session_id": "rps_" + "c" * 24,
            "replay_target": "default",
        },
    }
    sanitized = sanitize_event_for_capture_mode(event, "metadata_only")["metadata"]
    assert sanitized["status"] == "completed"
    assert sanitized["sender"] == "[REDACTED_TEXT]"
    assert sanitized["experiment_id"] == "exp_" + "a" * 32
    assert sanitized["applied_patch_ids"] == ["patch_" + "b" * 32]
    assert sanitized["baseline_trace_id"] == "trace_1234abcd"
    forged = sanitize_event_for_capture_mode({"name": "x", "metadata": {"experiment_id": "customer secret text"}}, "metadata_only")
    assert forged["metadata"]["experiment_id"] == "[REDACTED_TEXT]"


def test_metadata_only_redacts_outer_customer_labels_even_when_single_token():
    event = {
        "name": "context_snapshot",
        "metadata": {
            "sender": "Alice",
            "receiver": "oncology",
            "status": "diagnosis",
            "reason": "medical",
            "name": "Alice",
            "source": "oncology",
            "model": "customer_name",
            "tool_name": "medical",
            "framework": "langgraph",
            "provider": "anthropic",
            "role": "assistant",
            "stop_reason": "end_turn",
            "trace_id": "trace_0123abcd",
        },
    }
    metadata = sanitize_event_for_capture_mode(event, "metadata_only")["metadata"]
    for key in ("sender", "receiver", "status", "reason", "name", "source", "model", "tool_name"):
        assert metadata[key] == "[REDACTED_TEXT]"
    assert metadata["framework"] == "langgraph"
    assert metadata["provider"] == "anthropic"
    assert metadata["role"] == "assistant"
    assert metadata["stop_reason"] == "end_turn"
    assert metadata["trace_id"] == "trace_0123abcd"


# --------------------------------------------------------------------------- P2 scrubber
@pytest.mark.parametrize(
    "text, must_not_contain",
    [
        ("-----BEGIN PRIVATE KEY-----\nMIIEvQIBADANBg\n-----END PRIVATE KEY-----", "MIIEvQIBADANBg"),
        ("password: hunter2!", "hunter2"),
        ("AKIAIOSFODNN7EXAMPLE", "AKIAIOSFODNN7EXAMPLE"),
        ("Authorization: Bearer abc123def456", "abc123def456"),
        ("token=deadbeefcafe1234", "deadbeefcafe1234"),
        ("xoxb-123456789012-1234567890123-AbCdEfGhIjKlMnOpQrStUv", "AbCdEfGhIjKlMnOpQrStUv"),
        ("ghp_ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef123456", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdef123456"),
    ],
)
def test_full_mode_scrubs_obvious_secrets(text, must_not_contain):
    event = {"name": "x", "metadata": {"snapshot": {"messages": [{"role": "user", "content": text}]}}}
    scrubbed = sanitize_event_for_capture_mode(event, "full")["metadata"]["snapshot"]["messages"][0]["content"]
    assert must_not_contain not in scrubbed
    assert "[REDACTED_SECRET]" in scrubbed


def test_full_mode_keeps_ordinary_sentences():
    event = {"name": "x", "metadata": {"snapshot": {"messages": [{"role": "user", "content": "The status is DECLINED because the balance is negative."}]}}}
    scrubbed = sanitize_event_for_capture_mode(event, "full")["metadata"]["snapshot"]["messages"][0]["content"]
    assert scrubbed == "The status is DECLINED because the balance is negative."


# --------------------------------------------------------------------------- P2 handoff paths
def _materializer(brief):
    return f"Write about: {brief}"


def test_materializer_paths_are_repository_relative_or_dropped(tmp_path):
    payload = materializer_payload(_materializer)
    assert payload["symbol"] == "_materializer"
    if "path" in payload:
        assert not payload["path"].startswith("/")
        assert str(Path.home()) not in payload["path"]

    outside = Path(tempfile.mkdtemp()) / "m.py"
    outside.write_text("def build(): ...\n", encoding="utf-8")
    assert repository_relative_path(str(outside)) is None
    explicit = materializer_payload("build", source_path=str(outside))
    assert "path" not in explicit
    assert materializer_payload("build", source_path="workflow/assignment.py")["path"] == "workflow/assignment.py"


def test_handoff_marks_declared_locators_as_declared_not_confirmed(tmp_path):
    shelf = _shelf(tmp_path)
    client = shelf.wrap(FakeOpenAI())
    brief = client.chat.completions.create(model="m", messages=[{"role": "user", "content": "plan"}]).choices[0].message.content
    assignment = shelf.handoff(_materializer(brief), derived_from=brief, materialized_by=_materializer, source_path="workflow/assignment.py")
    client.chat.completions.create(model="m", messages=[{"role": "user", "content": assignment}])
    snapshot = [event for event in _events(shelf) if event["name"] == "context_snapshot"][-1]
    item = snapshot["metadata"]["snapshot"]["context_ir"]["items"][0]
    assert item["materialization"]["truth"] == "declared"
    assert item["materialization"]["path"] == "workflow/assignment.py"
    assert item["origin"]["kind"] == "upstream_output"


# --------------------------------------------------------------------------- P2 stale replay env
def test_stale_replay_session_environment_is_ignored_in_production(tmp_path, monkeypatch):
    monkeypatch.setenv("SHELFAI_REPLAY_SESSION", "srp_stale_token")
    monkeypatch.setenv("SHELFAI_REPLAY_TARGET", "default")
    calls = []

    def handler(request: httpx.Request) -> httpx.Response:
        calls.append(request.url.path)
        if request.url.path == "/api/replay-sessions/bundle":
            return httpx.Response(401, json={"detail": {"code": "invalid_replay_session"}})
        return httpx.Response(200, json={})

    shelf = _shelf(tmp_path, http_client=httpx.Client(transport=httpx.MockTransport(handler)))
    client = shelf.wrap(FakeOpenAI())
    with pytest.warns(RuntimeWarning, match="SHELFAI_REPLAY_SESSION"):
        response = client.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}])
    assert response.choices[0].message.content
    bundle_calls = calls.count("/api/replay-sessions/bundle")
    client.chat.completions.create(model="m", messages=[{"role": "user", "content": "again"}])
    assert calls.count("/api/replay-sessions/bundle") == bundle_calls, "stale session is not retried on every call"


# --------------------------------------------------------------------------- P1-3 install() / ASGI
async def _call_asgi(app, method="POST", body=b"{}", headers=None):
    scope = {"type": "http", "method": method, "path": "/", "headers": [(k.lower().encode(), v.encode()) for k, v in (headers or {}).items()]}
    sent = {"done": False}

    async def receive():
        sent["done"] = True
        return {"type": "http.request", "body": body, "more_body": False}

    result = {}

    async def send(message):
        if message["type"] == "http.response.start":
            result["status"] = message["status"]

    await app(scope, receive, send)
    return result["status"]


def _replay_integration(tmp_path):
    return integrate(
        client=FakeOpenAI(),
        replay=lambda: None,
        api_key="k",
        agent_id="a",
        api_url="http://127.0.0.1:9",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=httpx.Client(transport=httpx.MockTransport(_ok)),
        start_background_threads=False,
        replay_signing_secret="workspace-replay-secret-0123456789",
    )


def test_replay_app_is_an_asgi_callable_object_and_rejects_non_ascii_signatures(tmp_path):
    integration = _replay_integration(tmp_path)
    app = integration.replay_app()
    assert callable(app) and not inspect.isfunction(app)
    assert asyncio.run(_call_asgi(app, headers={"x-shelfai-signature": "sha256=éé"})) == 401
    assert asyncio.run(_call_asgi(app)) == 401
    assert asyncio.run(_call_asgi(app, method="GET")) == 405


def test_install_registers_an_exact_post_route_and_flushes_on_shutdown(tmp_path):
    fastapi = pytest.importorskip("fastapi")
    from fastapi.testclient import TestClient

    integration = _replay_integration(tmp_path)
    app = fastapi.FastAPI()
    assert integration.install(app) is integration
    with TestClient(app) as test_client:
        unsigned = test_client.post("/shelfai/replay", content=b"{}")
        assert unsigned.status_code == 401, "exact path, no trailing-slash redirect"
        assert test_client.get("/shelfai/replay").status_code == 405
        assert integration._closed is False
    assert integration._closed is True


def test_last_trace_id_is_exposed_after_a_captured_call(tmp_path):
    integration = integrate(
        client=FakeOpenAI(),
        api_key="k",
        agent_id="a",
        api_url="http://127.0.0.1:9",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=httpx.Client(transport=httpx.MockTransport(_ok)),
        start_background_threads=False,
    )
    assert integration.last_trace_id is None
    integration.client.chat.completions.create(model="m", messages=[{"role": "user", "content": "hi"}])
    assert integration.last_trace_id and integration.last_trace_id.startswith("trace_")
