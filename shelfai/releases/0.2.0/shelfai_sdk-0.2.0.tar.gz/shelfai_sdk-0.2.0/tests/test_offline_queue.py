from shelfai_sdk.queue import OfflineQueue


def test_offline_queue_persists_rows(tmp_path):
    queue = OfflineQueue(str(tmp_path))
    queue.enqueue_many("agent-1", ['{"name":"a"}', '{"name":"b"}'], "2026-04-01T00:00:00Z")

    rows = queue.oldest(limit=10)
    assert len(rows) == 2


def test_offline_queue_marks_delivered(tmp_path):
    queue = OfflineQueue(str(tmp_path))
    queue.enqueue_many("agent-1", ['{"name":"a"}'], "2026-04-01T00:00:00Z")
    ids = [int(row["id"]) for row in queue.oldest(limit=10)]
    queue.mark_delivered(ids)

    assert queue.count() == 0
