from __future__ import annotations

import os
from pathlib import Path
import subprocess
import sys


SDK_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = Path(__file__).resolve().parents[3]


def test_sdk_standalone_imports(tmp_path):
    env = dict(os.environ)
    env["PYTHONPATH"] = str(SDK_ROOT)
    script = f"""
import sys

repo_root = {str(REPO_ROOT)!r}
sdk_root = {str(SDK_ROOT)!r}
sys.path = [
    entry
    for entry in sys.path
    if entry not in ("", ".")
    and not (repo_root in entry and "site-packages" not in entry and "dist-packages" not in entry)
]
sys.path.insert(0, sdk_root)

import shelfai_sdk
from shelfai_sdk._pricing import get_rate
from shelfai_sdk.wrappers import ShelfAIIntegration, wrap_anthropic_client, wrap_openai_client

assert get_rate("gpt-4o").provider == "openai"
print("ok", shelfai_sdk.__file__, ShelfAIIntegration.__name__, wrap_anthropic_client.__name__, wrap_openai_client.__name__)
"""
    result = subprocess.run(
        [sys.executable, "-c", script],
        capture_output=True,
        check=False,
        cwd=tmp_path,
        env=env,
        text=True,
    )

    assert result.returncode == 0, result.stderr
    assert result.stdout.startswith("ok ")
