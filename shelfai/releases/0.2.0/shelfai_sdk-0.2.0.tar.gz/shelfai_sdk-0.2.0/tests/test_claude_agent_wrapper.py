from __future__ import annotations

import asyncio
import builtins
from dataclasses import dataclass, field
import sys
from types import ModuleType

import pytest

from shelfai_sdk.wrappers import claude_agent as claude_agent_module
from shelfai_sdk.wrappers.claude_agent import ShelfAIIntegration


class _JsonResponse:
    def __init__(self, payload):
        self._payload = payload

    def raise_for_status(self):
        return None

    def json(self):
        return self._payload


class _HttpClient:
    def __init__(self):
        self.event_batches = []
        self.requests = []

    def post(self, url, headers=None, json=None):
        self.event_batches.append({"url": url, "headers": headers, "json": json})
        return _JsonResponse({"ok": True})

    def request(self, method, url, headers=None, params=None, json=None):
        self.requests.append(
            {
                "method": method,
                "url": url,
                "headers": headers,
                "params": params,
                "json": json,
            }
        )
        if url.endswith("/api/v1/agents/agent-1/recommendations"):
            return _JsonResponse({"recommendations": [{"id": "rec-1", "title": "Load auth bundle"}]})
        if url.endswith("/api/v1/agents/agent-1/health"):
            return _JsonResponse({"agent_id": "agent-1", "score": 0.92})
        if url.endswith("/api/v1/seeker/ask"):
            return _JsonResponse({"answer": "Auth latency is increasing.", "citations": ["wiki:auth"]})
        raise AssertionError(f"Unexpected request: {method} {url}")

    def close(self):
        return None


class _Clock:
    def __init__(self):
        self.wall = 1000.0
        self.monotonic = 500.0

    def time(self):
        return self.wall

    def perf_counter(self):
        return self.monotonic

    def advance(self, seconds):
        self.wall += seconds
        self.monotonic += seconds


def _install_fake_claude_agent_sdk(monkeypatch):
    module = ModuleType("claude_agent_sdk")

    @dataclass
    class HookMatcher:
        matcher: str | None = None
        hooks: list = field(default_factory=list)
        timeout: float | None = None

    def tool(name, description, input_schema, annotations=None):
        def decorator(func):
            func.tool_name = name
            func.description = description
            func.input_schema = input_schema
            func.annotations = annotations
            return func

        return decorator

    def create_sdk_mcp_server(name, version="1.0.0", tools=None):
        return {"name": name, "version": version, "tools": tools or []}

    module.HookMatcher = HookMatcher
    module.tool = tool
    module.create_sdk_mcp_server = create_sdk_mcp_server
    monkeypatch.setitem(sys.modules, "claude_agent_sdk", module)


def _event_payloads(http_client: _HttpClient):
    return [event for batch in http_client.event_batches for event in batch["json"]["events"]]


def _hook_input(hook_event_name: str, session_id="claude-session-1", transcript_path="/tmp/transcript.md", cwd="/tmp/project", **extra):
    payload = {
        "hook_event_name": hook_event_name,
        "cwd": cwd,
    }
    if session_id is not None:
        payload["session_id"] = session_id
    if transcript_path is not None:
        payload["transcript_path"] = transcript_path
    payload.update(extra)
    return payload


def _make_integration(tmp_path, monkeypatch, http_client=None, sensitive_mode=None):
    _install_fake_claude_agent_sdk(monkeypatch)
    http = http_client or _HttpClient()
    integration = ShelfAIIntegration(
        api_key="sk-demo",
        agent_id="agent-1",
        api_url="https://api.example",
        offline_queue_path=str(tmp_path),
        sensitive_mode=sensitive_mode,
        http_client=http,
        start_background_threads=False,
    )
    return integration, http


def test_claude_integration_requires_optional_dependency_only_when_used(tmp_path, monkeypatch):
    real_import = builtins.__import__

    def fake_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "claude_agent_sdk":
            raise ImportError("missing claude_agent_sdk")
        return real_import(name, globals, locals, fromlist, level)

    monkeypatch.delitem(sys.modules, "claude_agent_sdk", raising=False)
    monkeypatch.setattr(builtins, "__import__", fake_import)
    integration = ShelfAIIntegration(
        api_key="sk-demo",
        agent_id="agent-1",
        offline_queue_path=str(tmp_path),
        start_background_threads=False,
        http_client=_HttpClient(),
    )

    try:
        hooks = integration.hooks()
    except ImportError:
        hooks = None

    if hooks is not None:
        assert "UserPromptSubmit" in hooks

    integration.close()


def test_claude_hooks_emit_session_snapshot_and_route_events(tmp_path, monkeypatch):
    monkeypatch.setattr(claude_agent_module, "tiktoken", None)
    integration, http = _make_integration(tmp_path, monkeypatch, sensitive_mode="full")
    hooks = integration.hooks()

    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Review auth.py"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PostToolUse"][0].hooks[0](
            _hook_input(
                "PostToolUse",
                tool_name="Read",
                tool_input={"file_path": "src/auth.py"},
                tool_response={"content": "def login():\n    return True\n"},
                tool_use_id="tool-read-1",
            ),
            "tool-read-1",
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PostToolUse"][0].hooks[0](
            _hook_input(
                "PostToolUse",
                tool_name="Grep",
                tool_input={"pattern": "login", "path": "src"},
                tool_response={"matches": [{"file": "src/auth.py"}, {"file": "src/api.py"}]},
                tool_use_id="tool-grep-1",
            ),
            "tool-grep-1",
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["Stop"][0].hooks[0](
            _hook_input("Stop", stop_hook_active=True),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Review billing.py"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["Stop"][0].hooks[0](
            _hook_input("Stop", stop_hook_active=True),
            None,
            {"signal": None},
        )
    )

    integration.shelf.transport.flush()
    integration.close()

    events = _event_payloads(http)
    names = [event["name"] for event in events]
    assert "session_start" in names
    assert "context_snapshot" in names
    assert "route_decision" in names
    assert "session_end" in names

    session_starts = [event for event in events if event["name"] == "session_start"]
    assert len(session_starts) == 2
    assert session_starts[0]["trace_id"] != session_starts[1]["trace_id"]

    snapshot_event = next(event for event in events if event["name"] == "context_snapshot")
    assert snapshot_event["trace_id"] == session_starts[0]["trace_id"]
    assert snapshot_event["metadata"]["snapshot"]["metadata"]["session_id"] == session_starts[0]["trace_id"]
    assert snapshot_event["metadata"]["snapshot"]["retrieved_chunks"][0]["metadata"]["file_path"] == "src/auth.py"
    assert snapshot_event["metadata"]["snapshot"]["metadata"]["token_count_estimated"] is True

    route_event = next(event for event in events if event["name"] == "route_decision")
    assert route_event["metadata"]["pattern"] == "login"
    assert route_event["metadata"]["result_count"] == 2


def test_claude_stop_emits_llm_call_from_transcript_usage(tmp_path, monkeypatch):
    _install_fake_claude_agent_sdk(monkeypatch)
    http = _HttpClient()
    integration = ShelfAIIntegration(
        api_key="sk-demo",
        agent_id="agent-1",
        api_url="https://api.example",
        offline_queue_path=str(tmp_path),
        http_client=http,
        start_background_threads=False,
    )
    hooks = integration.hooks()

    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Summarize auth status"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["Stop"][0].hooks[0](
            _hook_input(
                "Stop",
                stop_hook_active=True,
                transcript_snapshot={
                    "model": "claude-sonnet-4-6",
                    "usage": {
                        "input_tokens": 900,
                        "output_tokens": 200,
                        "cache_read_input_tokens": 100,
                        "cache_creation_input_tokens": 50,
                    },
                },
            ),
            None,
            {"signal": None},
        )
    )

    integration.shelf.transport.flush()
    integration.close()

    events = _event_payloads(http)
    llm_call = next(event for event in events if event["name"] == "llm_call")
    assert llm_call["model"] == "claude-sonnet-4-6"
    assert llm_call["tokens_input"] == 900
    assert llm_call["tokens_output"] == 200
    assert llm_call["tokens_cache_read"] == 100
    assert llm_call["tokens_cache_write"] == 50


def test_claude_edit_hooks_emit_review_lifecycle_and_tool_latency(tmp_path, monkeypatch):
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()

    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Update auth flows"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PreToolUse"][0].hooks[0](
            _hook_input(
                "PreToolUse",
                tool_name="Edit",
                tool_input={"file_path": "src/auth.py", "old_string": "foo", "new_string": "bar"},
                tool_use_id="tool-edit-1",
            ),
            "tool-edit-1",
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PostToolUse"][0].hooks[0](
            _hook_input(
                "PostToolUse",
                tool_name="Edit",
                tool_input={"file_path": "src/auth.py"},
                tool_response={"ok": True},
                tool_use_id="tool-edit-1",
            ),
            "tool-edit-1",
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PreToolUse"][0].hooks[0](
            _hook_input(
                "PreToolUse",
                tool_name="Write",
                tool_input={"file_path": "src/new_file.py", "content": "print('hi')"},
                tool_use_id="tool-write-1",
            ),
            "tool-write-1",
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PostToolUseFailure"][0].hooks[0](
            _hook_input(
                "PostToolUseFailure",
                tool_name="Write",
                tool_input={"file_path": "src/new_file.py"},
                tool_use_id="tool-write-1",
                error="disk full",
                is_interrupt=False,
            ),
            "tool-write-1",
            {"signal": None},
        )
    )

    integration.shelf.transport.flush()
    integration.close()

    events = _event_payloads(http)
    proposed = [event for event in events if event["name"] == "review_proposed"]
    approved = [event for event in events if event["name"] == "review_approved"]
    rejected = [event for event in events if event["name"] == "review_rejected"]
    tool_starts = [event for event in events if event["name"] == "tool_start"]
    tool_ends = [event for event in events if event["name"] == "tool_end"]

    assert len(proposed) == 2
    assert len(approved) == 1
    assert len(rejected) == 1
    assert len(tool_starts) == 2
    assert len(tool_ends) == 1
    assert proposed[0]["trace_id"] == approved[0]["trace_id"] == rejected[0]["trace_id"]
    assert approved[0]["metadata"]["tool_use_id"] == "tool-edit-1"
    assert rejected[0]["metadata"]["error"] == "[REDACTED_TEXT]"
    assert tool_ends[0]["metadata"]["latency_ms"] >= 0


def test_claude_mcp_tools_call_live_api_helpers(tmp_path, monkeypatch):
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()
    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Need recommendations"),
            None,
            {"signal": None},
        )
    )

    server = integration.mcp_servers()["shelfai"]
    tools = {tool.tool_name: tool for tool in server["tools"]}

    recommend_payload = asyncio.run(tools["recommend"]({}))
    health_payload = asyncio.run(tools["health"]({}))
    ask_payload = asyncio.run(tools["ask"]({"question": "What is happening in auth?"}))

    integration.shelf.transport.flush()
    integration.close()

    assert recommend_payload["structuredContent"]["recommendations"][0]["id"] == "rec-1"
    assert health_payload["structuredContent"]["score"] == 0.92
    assert ask_payload["structuredContent"]["answer"] == "Auth latency is increasing."

    paths = [(request["method"], request["url"], request["json"]) for request in http.requests]
    assert ("GET", "https://api.example/api/v1/agents/agent-1/recommendations", None) in paths
    assert ("GET", "https://api.example/api/v1/agents/agent-1/health", None) in paths
    assert (
        "POST",
        "https://api.example/api/v1/seeker/ask",
        {"question": "What is happening in auth?", "stream": False, "history": [], "scope": {"type": "all"}},
    ) in paths

    events = _event_payloads(http)
    trace_outputs = [event for event in events if event["name"] == "trace_output"]
    assert len(trace_outputs) == 3
    assert all(event["metadata"]["session_id"] == trace_outputs[0]["trace_id"] for event in trace_outputs)
    assert all("response" not in event["metadata"] for event in trace_outputs)


def test_claude_hooks_swallow_telemetry_errors(tmp_path, monkeypatch):
    integration, _http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()
    calls = []

    def raising_emit_event(name, metadata=None, trace_id=None):
        calls.append({"name": name, "metadata": metadata, "trace_id": trace_id})
        raise RuntimeError("boom")

    monkeypatch.setattr(integration.shelf, "emit_event", raising_emit_event)

    result = asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Read auth"),
            None,
            {"signal": None},
        )
    )

    assert result == {}
    assert any(call["name"] == "shelfai_integration_error" for call in calls)
    integration.close()


def test_claude_snapshot_failure_emits_error_telemetry(tmp_path, monkeypatch):
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()
    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Read auth"),
            None,
            {"signal": None},
        )
    )
    monkeypatch.setattr(integration.shelf, "snapshot", lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("boom")))

    result = asyncio.run(
        hooks["PostToolUse"][0].hooks[0](
            _hook_input(
                "PostToolUse",
                tool_name="Read",
                tool_input={"file_path": "src/auth.py"},
                tool_response={"content": "hello"},
                tool_use_id="tool-read-2",
            ),
            "tool-read-2",
            {"signal": None},
        )
    )

    integration.shelf.transport.flush()
    integration.close()

    assert result == {}
    events = _event_payloads(http)
    assert any(event["name"] == "shelfai_integration_error" for event in events)


def test_claude_mcp_tool_error_emits_error_telemetry_and_error_payload(tmp_path, monkeypatch):
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()
    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Need recommendations"),
            None,
            {"signal": None},
        )
    )

    original_emit_event = integration.shelf.emit_event

    def emit_event_with_trace_output_failure(name, metadata=None, trace_id=None):
        if name == "trace_output":
            raise RuntimeError("trace output boom")
        return original_emit_event(name, metadata=metadata, trace_id=trace_id)

    monkeypatch.setattr(integration.shelf, "emit_event", emit_event_with_trace_output_failure)
    original_request = http.request

    def failing_request(method, url, headers=None, params=None, json=None):
        if url.endswith("/api/v1/agents/agent-1/recommendations"):
            raise RuntimeError("network down")
        return original_request(method, url, headers=headers, params=params, json=json)

    monkeypatch.setattr(http, "request", failing_request)

    server = integration.mcp_servers()["shelfai"]
    tools = {tool.tool_name: tool for tool in server["tools"]}
    recommend_payload = asyncio.run(tools["recommend"]({}))

    integration.shelf.transport.flush()
    integration.close()

    assert recommend_payload["isError"] is True
    assert "request failed" in recommend_payload["content"][0]["text"]

    events = _event_payloads(http)
    assert any(event["name"] == "shelfai_integration_error" for event in events)


def test_claude_missing_session_ids_use_distinct_synthetic_runs(tmp_path, monkeypatch):
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()

    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", session_id=None, transcript_path=None, prompt="First unkeyed session"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", session_id=None, transcript_path=None, prompt="Second unkeyed session"),
            None,
            {"signal": None},
        )
    )

    assert len(integration._active_runs) == 2
    assert all("global" not in key for key in integration._active_runs)

    integration.shelf.transport.flush()
    integration.close()

    events = _event_payloads(http)
    session_starts = [event for event in events if event["name"] == "session_start"]
    assert len(session_starts) == 2
    assert session_starts[0]["trace_id"] != session_starts[1]["trace_id"]


@pytest.mark.parametrize(
    "tool_input, present",
    [
        ("not-json", True),
        (None, True),
        (None, False),
    ],
)
def test_claude_malformed_tool_input_emits_warning(tmp_path, monkeypatch, tool_input, present):
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()
    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Bad tool input"),
            None,
            {"signal": None},
        )
    )

    payload = _hook_input(
        "PostToolUse",
        tool_name="Glob",
        tool_use_id="tool-glob-1",
    )
    if present:
        payload["tool_input"] = tool_input

    result = asyncio.run(
        hooks["PostToolUse"][0].hooks[0](
            payload,
            "tool-glob-1",
            {"signal": None},
        )
    )

    integration.shelf.transport.flush()
    integration.close()

    assert result == {}
    events = _event_payloads(http)
    assert any(event["name"] == "shelfai_integration_warning" for event in events)


def test_claude_extract_text_content_handles_deep_nesting():
    value = "leaf"
    for _ in range(100):
        value = {"content": value}

    text = claude_agent_module._extract_text_content(value)
    assert isinstance(text, str)
    assert "leaf" in text


def test_claude_post_tool_use_failure_clears_non_review_tool_start(tmp_path, monkeypatch):
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()

    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", prompt="Track a read failure"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PreToolUse"][0].hooks[0](
            _hook_input(
                "PreToolUse",
                tool_name="Read",
                tool_input={"file_path": "src/auth.py"},
                tool_use_id="tool-read-failure",
            ),
            "tool-read-failure",
            {"signal": None},
        )
    )

    assert "tool-read-failure" in integration._tool_call_starts

    result = asyncio.run(
        hooks["PostToolUseFailure"][0].hooks[0](
            _hook_input(
                "PostToolUseFailure",
                tool_name="Read",
                tool_input={"file_path": "src/auth.py"},
                tool_use_id="tool-read-failure",
                error="boom",
                is_interrupt=False,
            ),
            "tool-read-failure",
            {"signal": None},
        )
    )

    integration.shelf.transport.flush()
    integration.close()

    assert result == {}
    assert "tool-read-failure" not in integration._tool_call_starts
    events = _event_payloads(http)
    assert not any(event["name"] == "review_rejected" for event in events)


def test_claude_reaps_stale_runs_after_ttl(tmp_path, monkeypatch):
    clock = _Clock()
    monkeypatch.setattr(claude_agent_module.time, "time", clock.time)
    monkeypatch.setattr(claude_agent_module.time, "perf_counter", clock.perf_counter)
    integration, _http = _make_integration(tmp_path, monkeypatch)

    first_run = integration._ensure_run(_hook_input("UserPromptSubmit", session_id="claude-session-1"))
    assert len(integration._active_runs) == 1

    clock.advance(3700)
    integration._ensure_run(_hook_input("UserPromptSubmit", session_id="claude-session-2"))

    assert len(integration._active_runs) == 1
    assert all(run["session_id"] != first_run["session_id"] for run in integration._active_runs.values())
    integration.close()


def test_claude_reaps_stale_tool_starts_after_ttl(tmp_path, monkeypatch):
    clock = _Clock()
    monkeypatch.setattr(claude_agent_module.time, "time", clock.time)
    monkeypatch.setattr(claude_agent_module.time, "perf_counter", clock.perf_counter)
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()

    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", session_id="claude-session-1"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PreToolUse"][0].hooks[0](
            _hook_input(
                "PreToolUse",
                tool_name="Glob",
                tool_input={"pattern": "auth"},
                tool_use_id="tool-glob-stale",
            ),
            "tool-glob-stale",
            {"signal": None},
        )
    )

    assert "tool-glob-stale" in integration._tool_call_starts

    clock.advance(3700)
    integration._ensure_run(_hook_input("UserPromptSubmit", session_id="claude-session-2"))

    assert "tool-glob-stale" not in integration._tool_call_starts
    integration.close()


def test_claude_tool_latency_tracks_start_and_end(tmp_path, monkeypatch):
    clock = _Clock()
    monkeypatch.setattr(claude_agent_module.time, "time", clock.time)
    monkeypatch.setattr(claude_agent_module.time, "perf_counter", clock.perf_counter)
    integration, http = _make_integration(tmp_path, monkeypatch)
    hooks = integration.hooks()

    asyncio.run(
        hooks["UserPromptSubmit"][0].hooks[0](
            _hook_input("UserPromptSubmit", session_id="claude-session-1"),
            None,
            {"signal": None},
        )
    )
    asyncio.run(
        hooks["PreToolUse"][0].hooks[0](
            _hook_input(
                "PreToolUse",
                tool_name="Edit",
                tool_input={"file_path": "src/auth.py"},
                tool_use_id="tool-edit-latency",
            ),
            "tool-edit-latency",
            {"signal": None},
        )
    )

    clock.advance(1.234)

    asyncio.run(
        hooks["PostToolUse"][0].hooks[0](
            _hook_input(
                "PostToolUse",
                tool_name="Edit",
                tool_input={"file_path": "src/auth.py"},
                tool_response={"ok": True},
                tool_use_id="tool-edit-latency",
            ),
            "tool-edit-latency",
            {"signal": None},
        )
    )

    integration.shelf.transport.flush()
    integration.close()

    events = _event_payloads(http)
    tool_start = next(event for event in events if event["name"] == "tool_start")
    tool_end = next(event for event in events if event["name"] == "tool_end")
    assert tool_start["metadata"]["started_at"] == pytest.approx(1000.0)
    assert tool_end["metadata"]["latency_ms"] == 1234
