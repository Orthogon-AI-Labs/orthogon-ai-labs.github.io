from __future__ import annotations

import logging
from types import SimpleNamespace

from shelfai_sdk.wrappers.autogen import ShelfAIAutoGenLogHandler
from shelfai_sdk.wrappers.llamaindex import ShelfAILlamaIndexHandler, register_llamaindex_handler


class _ShelfRecorder:
    def __init__(self) -> None:
        self.events: list[dict] = []
        self.counter = 0

    def generate_trace_id(self) -> str:
        self.counter += 1
        return f"run-{self.counter}"

    def emit_event(self, name, metadata=None, trace_id=None):
        self.events.append({"name": name, "metadata": metadata or {}, "trace_id": trace_id})


class LLMCallEvent:
    def __init__(self, response=None):
        self.model = "test-model"
        self.messages = [{"role": "user", "content": "hello"}]
        self.response = response


class MessageEvent:
    def __init__(self):
        self.sender = "planner"
        self.receiver = "writer"
        self.content = "assignment"


def test_autogen_structured_logger_emits_context_ir_and_handoff():
    shelf = _ShelfRecorder()
    handler = ShelfAIAutoGenLogHandler(shelf)
    logger = logging.getLogger("shelfai-test-autogen")
    logger.handlers = [handler]
    logger.setLevel(logging.INFO)
    logger.propagate = False

    logger.info(LLMCallEvent())
    logger.info(MessageEvent())

    assert [event["name"] for event in shelf.events] == ["trace_started", "handoff"]
    assert shelf.events[0]["metadata"]["context_ir"]["items"][0]["type"] == "message"
    assert shelf.events[1]["metadata"]["context_ir"]["items"][0]["type"] == "handoff"


class _LlamaEvent:
    def __init__(self, name: str, **payload):
        self._name = name
        self._payload = payload

    def class_name(self):
        return self._name

    def model_dump(self, mode="json"):
        return self._payload


class _Dispatcher:
    def __init__(self):
        self.handlers = []

    def add_event_handler(self, handler):
        self.handlers.append(handler)


def test_llamaindex_instrumentation_maps_retrieval_and_registration():
    shelf = _ShelfRecorder()
    dispatcher = _Dispatcher()
    handler = register_llamaindex_handler(shelf, dispatcher)

    assert dispatcher.handlers == [handler]
    handler.handle(_LlamaEvent("RetrievalEndEvent", span_id="span-1", nodes=[{"text": "evidence"}]))

    event = shelf.events[0]
    assert event["trace_id"] == "span-1"
    assert event["metadata"]["context_ir"]["items"][0]["type"] == "retrieved_evidence"
