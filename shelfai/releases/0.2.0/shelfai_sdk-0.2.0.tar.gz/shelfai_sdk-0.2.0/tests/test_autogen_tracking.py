from __future__ import annotations

import pytest

pytest.importorskip("autogen")

from autogen import ConversableAgent

from shelfai_sdk.wrappers.autogen import register_shelfai_tracking


class _ShelfRecorder:
    def __init__(self) -> None:
        self.events: list[dict] = []
        self._trace_counter = 0

    def generate_trace_id(self) -> str:
        self._trace_counter += 1
        return f"autogen-trace-{self._trace_counter}"

    def emit_event(self, name, metadata=None, trace_id=None):
        self.events.append(
            {
                "name": name,
                "metadata": metadata or {},
                "trace_id": trace_id,
            }
        )


def test_register_shelfai_tracking_emits_for_normal_sender_replies():
    shelf = _ShelfRecorder()
    sender = ConversableAgent(name="sender", llm_config=False, default_auto_reply="")
    recipient = ConversableAgent(name="recipient", llm_config=False, default_auto_reply="")

    register_shelfai_tracking(recipient, shelf)

    reply = recipient.generate_reply(
        messages=[{"role": "user", "content": "hello there"}],
        sender=sender,
    )

    assert reply == ""
    assert len(shelf.events) == 1
    assert shelf.events[0]["name"] == "tool_end"
    assert shelf.events[0]["trace_id"] == "autogen-trace-1"
    assert shelf.events[0]["metadata"]["framework"] == "autogen"
    assert shelf.events[0]["metadata"]["sender"] == "sender"
    assert shelf.events[0]["metadata"]["receiver"] == "recipient"
    assert shelf.events[0]["metadata"]["message"]["content"] == "hello there"


def test_register_shelfai_tracking_uses_distinct_trace_ids_per_reply():
    shelf = _ShelfRecorder()
    sender = ConversableAgent(name="sender", llm_config=False, default_auto_reply="")
    recipient = ConversableAgent(name="recipient", llm_config=False, default_auto_reply="")

    register_shelfai_tracking(recipient, shelf)

    recipient.generate_reply(messages=[{"role": "user", "content": "hello one"}], sender=sender)
    recipient.generate_reply(messages=[{"role": "user", "content": "hello two"}], sender=sender)

    assert [event["trace_id"] for event in shelf.events] == ["autogen-trace-1", "autogen-trace-2"]


def test_register_shelfai_tracking_can_bootstrap_a_default_client(monkeypatch):
    shelf = _ShelfRecorder()
    sender = ConversableAgent(name="sender", llm_config=False, default_auto_reply="")
    recipient = ConversableAgent(name="recipient", llm_config=False, default_auto_reply="")

    monkeypatch.setattr("shelfai_sdk.client.ShelfAI", lambda: shelf)

    register_shelfai_tracking(recipient)

    recipient.generate_reply(messages=[{"role": "user", "content": "hello"}], sender=sender)

    assert shelf.events[0]["trace_id"] == "autogen-trace-1"
