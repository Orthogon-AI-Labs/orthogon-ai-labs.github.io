from __future__ import annotations

from types import SimpleNamespace

from shelfai_sdk.diagnostics import DiagnosticStatus, doctor, main, read_only_backend_probes, verify_integration


class Response:
    status_code = 200


class ReadOnlyClient:
    def __init__(self):
        self.calls = []

    def get(self, url, **kwargs):
        self.calls.append(("GET", url, kwargs))
        return Response()


def test_verify_is_exact_trace_get_only(monkeypatch):
    http = ReadOnlyClient()
    probes = read_only_backend_probes("trace_exact", api_url="https://shelf.test", api_key="secret", http_client=http)
    report = verify_integration("trace_exact", probes=probes)
    assert report.ok
    assert len(http.calls) == 4
    assert all(method == "GET" for method, _url, _kwargs in http.calls)
    assert all("trace_exact" in url or "replay-hook" in url for _method, url, _kwargs in http.calls)
    assert not any("latest" in url for _method, url, _kwargs in http.calls)


def test_verify_without_trace_is_incomplete():
    report = verify_integration()
    assert report.ok and not report.complete
    assert main(["verify-integration"]) == 2


def test_successful_cli_style_backend_verification_is_complete():
    report = verify_integration("trace_exact", probes=read_only_backend_probes("trace_exact", api_url="https://shelf.test", http_client=ReadOnlyClient()))
    assert report.complete


def test_doctor_hostile_client_is_secret_safe():
    class Hostile:
        @property
        def messages(self):
            raise RuntimeError("password=hunter2 Bearer abc123")

    report = doctor(client=Hostile())
    rendered = str(report.safe_dict())
    assert "hunter2" not in rendered and "abc123" not in rendered
    assert any(check.status is DiagnosticStatus.WARN and check.details == {"error_type": "RuntimeError"} for check in report.checks)


def test_report_scrubs_nested_credentials():
    from shelfai_sdk.diagnostics import DiagnosticCheck, DiagnosticReport

    report = DiagnosticReport([DiagnosticCheck("x", DiagnosticStatus.WARN, "Bearer token-value password=dbpass", {"clientSecret": "value", "url": "postgres://me:pass@db/x?access_token=abc"})])
    rendered = str(report.safe_dict())
    for secret in ("token-value", "dbpass", "value", "me:pass", "abc"):
        assert secret not in rendered
