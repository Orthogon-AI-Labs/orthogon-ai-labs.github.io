from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shelfai_sdk.instrumentation import approve_handoff_suggestion, discover_handoff_suggestions


def _write_workflow(tmp_path: Path) -> Path:
    path = tmp_path / "workflow.py"
    path.write_text(
        '''"""Customer workflow."""

from __future__ import annotations


def build_writer_assignment(brief):
    return f"Write from: {brief}"


def run(brief, writer):
    assignment = build_writer_assignment(brief)
    return writer(assignment)
''',
        encoding="utf-8",
    )
    return path


def test_scan_is_local_review_only_and_proposes_neutral_observer(tmp_path):
    path = _write_workflow(tmp_path)

    suggestions = discover_handoff_suggestions(tmp_path, observer_import="_shared.shelfai_observer")

    assert len(suggestions) == 1
    proposal = suggestions[0]
    assert proposal.path == "workflow.py"
    assert proposal.direct_mutation is False
    assert proposal.approval_required is True
    assert "observe_handoff(" in proposal.after
    assert "materialized_by=build_writer_assignment" in proposal.after
    assert 'source_path="workflow.py"' in proposal.after
    assert path.read_text(encoding="utf-8").count("observe_handoff") == 0


def test_approval_applies_only_the_exact_proposal_and_import(tmp_path):
    path = _write_workflow(tmp_path)
    proposal = discover_handoff_suggestions(
        tmp_path,
        observer_import="_shared.shelfai_observer",
    )[0]

    result = approve_handoff_suggestion(
        tmp_path,
        proposal.proposal_id,
        observer_import="_shared.shelfai_observer",
    )

    text = path.read_text(encoding="utf-8")
    assert result["status"] == "applied"
    assert result["approved"] is True
    assert 'from _shared.shelfai_observer import observe_handoff' in text
    assert text.index("from __future__ import annotations") < text.index("from _shared.shelfai_observer")
    assert "assignment = observe_handoff(" in text
    assert "derived_from=brief" in text
    compile(text, str(path), "exec")


def test_stale_or_unknown_proposal_cannot_write(tmp_path):
    path = _write_workflow(tmp_path)
    before = path.read_text(encoding="utf-8")

    try:
        approve_handoff_suggestion(tmp_path, "handoff_not_real")
    except ValueError as exc:
        assert "proposal not found" in str(exc)
    else:
        raise AssertionError("unknown proposal should not be approved")

    assert path.read_text(encoding="utf-8") == before


def test_scan_ignores_unconsumed_and_already_observed_values(tmp_path):
    (tmp_path / "workflow.py").write_text(
        """
def run(brief):
    unused_context = build_context(brief)
    assignment = observe_handoff(build_assignment(brief), derived_from=brief)
    return assignment
""",
        encoding="utf-8",
    )

    assert discover_handoff_suggestions(tmp_path) == []
