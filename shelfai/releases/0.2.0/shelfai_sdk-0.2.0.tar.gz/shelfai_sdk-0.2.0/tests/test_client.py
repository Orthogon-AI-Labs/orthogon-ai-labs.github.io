from __future__ import annotations

import logging
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shelfai_sdk import Chunk, Context, Message, ShelfAI
from shelfai_sdk.capture_mode import sanitize_event_for_capture_mode
from shelfai_sdk.context_ir import provider_output_ir


class FakeResponse:
    def __init__(self, payload=None, status_code=200):
        self._payload = payload or {}
        self.status_code = status_code

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError("boom")

    def json(self):
        return self._payload


class FakeHTTPClient:
    def __init__(self, response_payload=None):
        self.calls = []
        self.response_payload = response_payload or {"ok": True}

    def post(self, url, headers=None, json=None):
        self.calls.append(("POST", url, headers, json))
        return FakeResponse(self.response_payload)

    def request(self, method, url, headers=None, **kwargs):
        self.calls.append((method, url, headers, kwargs))
        if url.endswith("/api/proposals"):
            return FakeResponse({"proposals": [{"id": "prop-1"}]})
        return FakeResponse({"status": "approved"})

    def close(self):
        return None


def _client(tmp_path):
    http = FakeHTTPClient()
    shelf = ShelfAI(
        api_key="sk-test",
        agent_id="agent-1",
        api_url="http://example.test",
        offline_queue_path=str(tmp_path / "queue"),
        batch_size=1,
        batch_interval_seconds=60,
        http_client=http,
        start_background_threads=False,
    )
    return shelf, http


def _client_with_mode(tmp_path, mode: str):
    http = FakeHTTPClient()
    shelf = ShelfAI(
        api_key="sk-test-secret-12345678",
        agent_id="agent-1",
        api_url="http://example.test",
        offline_queue_path=str(tmp_path / "queue"),
        batch_size=1,
        batch_interval_seconds=60,
        http_client=http,
        start_background_threads=False,
        capture_mode=mode,
    )
    return shelf, http


def test_snapshot_enqueues_context_event(tmp_path):
    shelf, http = _client(tmp_path)
    context = Context(
        agent_id="agent-1",
        system_prompt="You are helpful.",
        retrieved_chunks=[Chunk(id="chunk-a", source="vector", text="A chunk")],
        messages=[Message(role="user", content="hello")],
        token_count=123,
    )

    shelf.snapshot(context)
    shelf.transport.flush()

    assert http.calls[0][1].endswith("/api/events/batch")
    payload = http.calls[0][3]
    assert payload["capture_mode"] == "metadata_only"
    assert payload["events"][0]["name"] == "context_snapshot"
    assert payload["events"][0]["metadata"]["chunk_ids"] == ["chunk-a"]


def test_transport_warns_when_workspace_capture_policy_differs(tmp_path, caplog):
    http = FakeHTTPClient(
        {
            "capture_policy": {
                "sdk_requested_mode": "full",
                "workspace_effective_mode": "metadata_only",
                "aligned": False,
                "warning": {
                    "code": "capture_mode_mismatch",
                    "message": (
                        "SDK requested full, but workspace policy applied metadata_only. "
                        "A workspace owner must change Capture Mode in ShelfAI settings."
                    ),
                },
            }
        }
    )
    shelf = ShelfAI(
        api_key="sk-test-secret-12345678",
        agent_id="agent-1",
        api_url="http://example.test",
        offline_queue_path=str(tmp_path / "queue"),
        batch_size=1,
        batch_interval_seconds=60,
        http_client=http,
        start_background_threads=False,
        capture_mode="full",
    )
    with caplog.at_level(logging.WARNING, logger="shelfai_sdk.transport"):
        shelf.transport.enqueue_event({"name": "health_reported", "metadata": {}})
        shelf.transport.flush()

    assert "capture_policy_mismatch (CapturePolicyMismatch)" in caplog.text


def test_client_defaults_to_metadata_only_capture_mode(tmp_path):
    shelf, _http = _client(tmp_path)
    assert shelf.sensitive_mode == "metadata_only"


def test_metadata_only_snapshot_redacts_raw_content_before_send(tmp_path):
    shelf, http = _client_with_mode(tmp_path, "metadata_only")
    context = Context(
        agent_id="agent-1",
        system_prompt="Call me at 555-123-4567",
        retrieved_chunks=[Chunk(id="chunk-a", source="vector", text="api key sk-secret-123456789", metadata={"path": "src/auth.py"})],
        messages=[Message(role="user", content="email alice@example.com")],
        token_count=123,
        metadata={"task_type": "support", "note": "contains password"},
    )

    shelf.snapshot(context)
    shelf.transport.flush()

    event = http.calls[0][3]["events"][0]
    snapshot = event["metadata"]["snapshot"]
    assert event["metadata"]["chunk_ids"] == ["chunk-a"]
    assert snapshot["system_prompt"] == "[REDACTED_TEXT]"
    assert snapshot["messages"][0]["content"] == "[REDACTED_TEXT]"
    assert snapshot["retrieved_chunks"][0]["text"] == "[REDACTED_TEXT]"
    assert snapshot["metadata"]["task_type"] == "support"
    assert snapshot["metadata"]["note"] == "[REDACTED_TEXT]"


def test_metadata_only_preserves_only_safe_materialization_locators():
    event = sanitize_event_for_capture_mode(
        {
            "metadata": {
                "path": "private/customer-notes.txt",
                "snapshot": {
                    "context_ir": {
                        "version": "1.0",
                        "items": [
                            {
                                "id": "ctx-safe",
                                "type": "message",
                                "parent_ids": ["ctx-upstream-output"],
                                "raw_payload": {"content": "Write about the supplied places."},
                                "origin": {
                                    "producer": {"item_id": "ctx-upstream-output", "trace_id": "trace-planner"},
                                },
                                "metadata": {
                                    "lineage_detection": "automatic_contained_text",
                                    "source_annotation_required": True,
                                },
                                "materialization": {
                                    "kind": "repo_file",
                                    "path": "block_tier/intel/creative_writer.py",
                                    "symbol": "render_minimal_writer_assignment",
                                },
                            },
                            {
                                "id": "ctx-unsafe",
                                "type": "message",
                                "materialization": {
                                    "kind": "repo_file",
                                    "path": "/Users/customer/private/assignment.py",
                                    "symbol": "sk-secret-123456789",
                                },
                            },
                        ],
                    }
                },
            }
        },
        "metadata_only",
    )

    safe, unsafe = event["metadata"]["snapshot"]["context_ir"]["items"]
    assert event["metadata"]["path"] == "[REDACTED_TEXT]"
    assert event["metadata"]["snapshot"]["context_ir"]["version"] == "1.0"
    assert safe["type"] == "message"
    assert safe["parent_ids"] == ["ctx-upstream-output"]
    assert safe["origin"]["producer"] == {
        "item_id": "ctx-upstream-output",
        "trace_id": "trace-planner",
    }
    assert safe["metadata"] == {
        "lineage_detection": "automatic_contained_text",
        "source_annotation_required": True,
    }
    assert safe["raw_payload"]["content"] == "[REDACTED_TEXT]"
    assert safe["materialization"] == {
        "kind": "repo_file",
        "path": "block_tier/intel/creative_writer.py",
        "symbol": "render_minimal_writer_assignment",
    }
    assert unsafe["materialization"]["path"] == "[REDACTED_TEXT]"
    assert unsafe["materialization"]["symbol"] == "[REDACTED_TEXT]"


def test_full_mode_scrubs_obvious_secrets_but_keeps_content_shape(tmp_path):
    shelf, http = _client_with_mode(tmp_path, "full")
    context = Context(
        agent_id="agent-1",
        system_prompt="token eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.payload.signature",
        retrieved_chunks=[Chunk(id="chunk-a", source="vector", text="email alice@example.com", metadata={})],
        messages=[Message(role="user", content="call +1 (555) 123-4567")],
        token_count=123,
    )

    shelf.snapshot(context)
    shelf.transport.flush()

    snapshot = http.calls[0][3]["events"][0]["metadata"]["snapshot"]
    assert snapshot["system_prompt"] == "token [REDACTED_JWT]"
    assert snapshot["retrieved_chunks"][0]["text"] == "email [REDACTED_EMAIL]"
    assert snapshot["messages"][0]["content"] == "call [REDACTED_PHONE]"


def test_full_mode_preserves_human_content_ids_but_scrubs_opaque_tokens():
    event = sanitize_event_for_capture_mode(
        {
            "metadata": {
                "assignment": (
                    "id: block-review-one-domino-square-2026-06-12\n"
                    "token: A0b1C2d3E4f5G6h7I8j9K0l1M2n3O4p5Q6r7"
                )
            }
        },
        "full",
    )

    assignment = event["metadata"]["assignment"]
    assert "block-review-one-domino-square-2026-06-12" in assignment
    assert "A0b1C2d3" not in assignment
    assert "[REDACTED_SECRET]" in assignment


def test_metadata_only_preserves_framework_shape_but_redacts_raw_outputs(tmp_path):
    shelf, http = _client_with_mode(tmp_path, "metadata_only")

    shelf.emit_event(
        "trace_finished",
        {
            "framework": "langchain",
            "kind": "llm",
            "chain_type": "RunnableSequence",
            "state_delta_keys": ["input", "output"],
            "outputs": {"raw": "The answer is 42."},
            "generations": [{"text": "hello from langchain"}],
        },
        trace_id="trace-1",
    )
    shelf.transport.flush()

    event = http.calls[0][3]["events"][0]
    assert event["metadata"]["framework"] == "langchain"
    assert event["metadata"]["kind"] == "llm"
    assert event["metadata"]["chain_type"] == "[REDACTED_TEXT]"
    assert event["metadata"]["state_delta_keys"] == ["[REDACTED_TEXT]", "[REDACTED_TEXT]"]
    assert event["metadata"]["outputs"]["raw"] == "[REDACTED_TEXT]"
    assert event["metadata"]["generations"][0]["text"] == "[REDACTED_TEXT]"


def test_invariants_and_critical_chunks_emit_followup_events(tmp_path):
    shelf, http = _client(tmp_path)
    shelf.register_critical("account_balance", chunk_id="chunk-balance", ttl_seconds=3600)
    shelf.invariant("token_count <= 100", severity="critical")
    shelf.invariant("chunk:account_balance must be present", severity="warning")
    context = Context(agent_id="agent-1", token_count=101, retrieved_chunks=[])

    shelf.snapshot(context)
    shelf.transport.flush()

    emitted = http.calls[0][3]["events"]
    names = [event["name"] for event in emitted]
    assert "invariant_violated" in names
    assert "critical_missing" in names


def test_proposal_helpers_use_aligned_api_routes(tmp_path):
    shelf, http = _client(tmp_path)

    proposals = shelf.get_pending_proposals()
    approved = shelf.approve_proposal("prop-1", reason="ship it")
    rejected = shelf.reject_proposal("prop-1", reason="not needed")

    assert proposals == [{"id": "prop-1"}]
    assert approved["status"] == "approved"
    assert rejected["status"] == "approved"
    methods = [(method, url) for method, url, *_rest in http.calls if method != "POST" or not url.endswith("/api/events/batch")]
    assert ("GET", "http://example.test/api/proposals") in methods
    assert ("POST", "http://example.test/api/proposals/prop-1/approve") in methods
    assert ("POST", "http://example.test/api/proposals/prop-1/reject") in methods


def test_report_health_hits_heartbeat_endpoint(tmp_path):
    shelf, http = _client(tmp_path)

    shelf.report_health(success_rate=0.99, avg_latency_ms=120)
    shelf.transport.flush()

    methods = [(method, url) for method, url, *_rest in http.calls]
    assert ("POST", "http://example.test/api/agents/agent-1/heartbeat") in methods
    assert ("POST", "http://example.test/api/events/batch") in methods


def test_handoff_attaches_upstream_lineage_without_changing_the_value(tmp_path):
    shelf, _http = _client(tmp_path)
    output = provider_output_ir(
        provider="anthropic",
        run_id="trace-planner",
        response={"id": "msg-1", "content": [{"type": "text", "text": "Research brief"}]},
    )
    shelf.register_output_context(output)

    def build_assignment(value):
        return f"Write from: {value}"

    assignment = shelf.handoff(
        build_assignment("Research brief"),
        derived_from="Research brief",
        materialized_by=build_assignment,
        source_path="workflow/assignment.py",
        name="writer assignment",
    )
    assert assignment == "Write from: Research brief"

    context = shelf.extract_context_from_call(
        system=None,
        messages=[{"role": "user", "content": assignment}],
        trace_id="trace-writer",
        metadata={"provider": "anthropic"},
    )
    message = context.context_ir.items[0]
    assert message.parent_ids == [output.items[0].id]
    assert message.origin["kind"] == "upstream_output"
    assert message.origin["producer"]["trace_id"] == "trace-planner"
    assert message.materialization["path"] == "workflow/assignment.py"
    assert message.materialization["symbol"].endswith("build_assignment")
    assert message.metadata["context_role"] == "handoff"


def test_wrapped_outputs_automatically_light_a_later_handoff(tmp_path):
    shelf, _http = _client(tmp_path)
    output = provider_output_ir(
        provider="anthropic",
        run_id="trace-planner",
        response={
            "id": "msg-1",
            "content": [{"type": "text", "text": "Visit Misi and Jane Motorcycles on this favorite block."}],
        },
    )
    shelf.register_output_context(output)

    context = shelf.extract_context_from_call(
        system=None,
        messages=[{
            "role": "user",
            "content": "Write the story from this assignment: Visit Misi and Jane Motorcycles on this favorite block.",
        }],
        trace_id="trace-writer",
        metadata={"provider": "anthropic"},
    )

    message = context.context_ir.items[0]
    assert message.parent_ids == [output.items[0].id]
    assert message.origin["producer"]["trace_id"] == "trace-planner"
    assert message.materialization == {"kind": "ephemeral"}
    assert message.metadata["context_role"] == "handoff"
    assert message.metadata["lineage_detection"] == "automatic_contained_text"
    assert message.metadata["source_annotation_required"] is True


def test_automatic_lineage_ignores_short_common_provider_values(tmp_path):
    shelf, _http = _client(tmp_path)
    output = provider_output_ir(
        provider="anthropic",
        run_id="trace-planner",
        response={"id": "msg-1", "content": [{"type": "text", "text": "OK"}]},
    )
    shelf.register_output_context(output)

    context = shelf.extract_context_from_call(
        system=None,
        messages=[{"role": "user", "content": "OK"}],
        trace_id="trace-writer",
        metadata={"provider": "anthropic"},
    )

    assert context.context_ir.items[0].parent_ids == []
    assert "lineage_detection" not in context.context_ir.items[0].metadata


def test_explicit_experiment_replaces_context_only_in_memory(tmp_path):
    shelf, _http = _client(tmp_path)
    shelf.experiment_id = "exp-test"
    shelf._experiment_bundle_cache["exp-test"] = {
        "experiment_id": "exp-test",
        "baseline_trace_id": "trace-baseline",
        "agent_id": "agent-1",
        "patches": [
            {
                "patch_id": "patch-1",
                "original_content": "Write a generic story.",
                "replacement_content": "Write a source-grounded story.",
            }
        ],
    }
    original_messages = [{"role": "user", "content": "Write a generic story."}]

    system, messages, tools, metadata = shelf.apply_experiment_overrides(
        system="You are a writer.",
        messages=original_messages,
    )

    assert system == "You are a writer."
    assert tools is None
    assert messages[0]["content"] == "Write a source-grounded story."
    assert original_messages[0]["content"] == "Write a generic story."
    assert metadata == {
        "experiment_id": "exp-test",
        "baseline_trace_id": "trace-baseline",
        "applied_patch_ids": ["patch-1"],
        "experiment_patch_count": 1,
    }


def test_explicit_experiment_matches_trimmed_capture_and_preserves_handoff_lineage(tmp_path):
    shelf, _http = _client(tmp_path)
    shelf.experiment_id = "exp-test"
    shelf._experiment_bundle_cache["exp-test"] = {
        "experiment_id": "exp-test",
        "baseline_trace_id": "trace-baseline",
        "agent_id": "agent-1",
        "patches": [{
            "patch_id": "patch-1",
            "source": "anthropic.messages",
            "original_content": "Write a natural story.",
            "replacement_content": "Write a natural, observational story.",
        }],
    }
    original = "Write a natural story.\n"
    shelf.handoff(original, stage="writer_assignment", name="writer_assignment")

    system, messages, _tools, metadata = shelf.apply_experiment_overrides(
        system="You are a writer.",
        messages=[{"role": "user", "content": original}],
    )
    context = shelf.extract_context_from_call(
        system=system,
        messages=messages,
        trace_id="trace-replay",
        metadata={"provider": "anthropic", **metadata},
    )

    assert messages[0]["content"] == "Write a natural, observational story."
    assignment = next(item for item in context.context_ir.items if item.type == "message")
    assert assignment.stage == "writer_assignment"
    assert assignment.metadata["context_role"] == "handoff"
    assert assignment.metadata["handoff_name"] == "writer_assignment"


def test_experiment_matches_targeted_redaction_and_restores_live_value(tmp_path):
    shelf, _http = _client(tmp_path)
    shelf.experiment_id = "exp-test"
    shelf._experiment_bundle_cache["exp-test"] = {
        "experiment_id": "exp-test",
        "baseline_trace_id": "trace-baseline",
        "agent_id": "agent-1",
        "patches": [{
            "patch_id": "patch-1",
            "source": "anthropic.messages",
            "original_content": "id: [REDACTED_SECRET]\nWrite a contrast.",
            "replacement_content": "id: [REDACTED_SECRET]\nWrite two independently compelling places.",
        }],
    }
    live = "id: block-review-one-domino-square-2026-06-12\nWrite a contrast.\n"
    shelf.handoff(live, stage="writer_assignment", name="writer_assignment")

    _system, messages, _tools, _metadata = shelf.apply_experiment_overrides(
        system="You are a writer.",
        messages=[{"role": "user", "content": live}],
    )

    resolved = messages[0]["content"]
    assert "id: block-review-one-domino-square-2026-06-12" in resolved
    assert "[REDACTED_SECRET]" not in resolved
    assert resolved.endswith("Write two independently compelling places.")


def test_explicit_experiment_refuses_provider_call_when_patch_does_not_match(tmp_path):
    from shelfai_sdk.client import ExperimentReplayError

    shelf, _http = _client(tmp_path)
    shelf.experiment_id = "exp-test"
    shelf._experiment_bundle_cache["exp-test"] = {
        "experiment_id": "exp-test",
        "baseline_trace_id": "trace-baseline",
        "agent_id": "agent-1",
        "patches": [{
            "patch_id": "patch-1",
            "source": "anthropic.messages",
            "original_content": "Old assignment",
            "replacement_content": "New assignment",
        }],
    }

    with pytest.raises(ExperimentReplayError, match="unmatched patches: patch-1"):
        shelf.apply_experiment_overrides(
            system="You are a writer.",
            messages=[{"role": "user", "content": "Different assignment"}],
        )
