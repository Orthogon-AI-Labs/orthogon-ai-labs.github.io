from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shelfai_sdk.queue import OfflineQueue
from shelfai_sdk.transport import Transport


class FailingClient:
    def __init__(self):
        self.calls = 0

    def post(self, url, headers=None, json=None):
        self.calls += 1
        raise RuntimeError("offline")

    def close(self):
        return None


class RecoveringClient:
    def __init__(self):
        self.calls = []

    def post(self, url, headers=None, json=None):
        self.calls.append((url, json))

        class Response:
            def raise_for_status(self):
                return None

        return Response()

    def close(self):
        return None


def test_transport_moves_failed_batch_to_offline_queue(tmp_path):
    queue = OfflineQueue(str(tmp_path / "queue"))
    transport = Transport(
        api_key="sk-test",
        agent_id="agent-1",
        api_url="http://example.test",
        offline_queue=queue,
        batch_size=1,
        client=FailingClient(),
        start_background_thread=False,
    )

    transport.enqueue_event({"name": "context_snapshot", "metadata": {}})
    transport.flush()

    assert queue.size() == 1


def test_transport_flushes_offline_queue_after_recovery(tmp_path):
    queue = OfflineQueue(str(tmp_path / "queue"))
    queue.enqueue("agent-1", {"name": "context_snapshot", "metadata": {"chunk_ids": ["a"]}})
    client = RecoveringClient()
    transport = Transport(
        api_key="sk-test",
        agent_id="agent-1",
        api_url="http://example.test",
        offline_queue=queue,
        batch_size=1,
        client=client,
        start_background_thread=False,
    )

    transport.flush_offline_queue()

    assert queue.size() == 0
    assert client.calls[0][1]["events"][0]["metadata"]["chunk_ids"] == ["a"]


def test_offline_queue_writes_dead_letter_after_retries(tmp_path):
    queue = OfflineQueue(str(tmp_path / "queue"))
    queue.enqueue("agent-1", {"name": "context_snapshot"})
    batch = queue.load_batch(limit=10)

    for _ in range(5):
        queue.mark_failure([item.row_id for item in batch], "still offline")
        batch = queue.load_batch(limit=10)

    assert queue.dead_letter_path.exists()
    entry = json.loads(queue.dead_letter_path.read_text(encoding="utf-8").strip())
    assert entry["agent_id"] == "agent-1"
