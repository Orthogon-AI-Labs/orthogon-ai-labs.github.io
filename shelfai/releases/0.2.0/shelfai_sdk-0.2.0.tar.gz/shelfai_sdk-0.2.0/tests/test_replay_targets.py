from __future__ import annotations

import asyncio
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import json
import os
from pathlib import Path
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from shelfai_sdk.replay_targets import (
    ReplaySessionStore,
    ReplayTargetError,
    ReplayTargetRegistry,
    ReplayTrace,
    ReplayWorker,
)


SECRET = "replay-target-test-secret-123"
TENANT = "tenant-a"


def _store(**kwargs):
    return ReplaySessionStore(signing_secret=SECRET, **kwargs)


class _RemoteSessionAPI:
    """JSON round-trip models an issuer/backend separate from the worker."""

    def __init__(self, backend_store):
        self.backend_store = backend_store
        self.completions = []

    async def resolve(self, token, tenant_id, target_name):
        session = self.backend_store.activate(
            token,
            tenant_id=tenant_id,
            target_name=target_name,
        )
        wire = json.loads(
            json.dumps(
                {
                    "session_id": session.session_id,
                    "tenant_id": session.tenant_id,
                    "target_name": session.target_name,
                    "experiment_scope": session.experiment_scope,
                    "expires_at": session.expires_at.isoformat(),
                }
            )
        )
        from shelfai_sdk.replay_targets import ReplaySession

        return ReplaySession(
            session_id=wire["session_id"],
            tenant_id=wire["tenant_id"],
            target_name=wire["target_name"],
            experiment_scope=wire["experiment_scope"],
            expires_at=datetime.fromisoformat(wire["expires_at"]),
        )

    async def complete(self, session_id, succeeded):
        self.completions.append((session_id, succeeded))
        self.backend_store.complete_session(session_id)


def _worker(tmp_path, *, registry=None, sessions=None, resolver=None, activate=None, session_api=None):
    registry = registry or ReplayTargetRegistry(repo_root=tmp_path)
    sessions = sessions or _store()
    session_api = session_api or _RemoteSessionAPI(sessions)

    async def default_activate(_scope, callback):
        return await callback()

    def default_resolver(session):
        return ReplayTrace(
            trace_id="trace_verified",
            replay_session_id=session.session_id,
            tenant_id=session.tenant_id,
            target_name=session.target_name,
            sdk_captured=True,
            persisted=True,
        )

    return ReplayWorker(
        tenant_id=TENANT,
        signing_secret=SECRET,
        registry=registry,
        resolve_session=session_api.resolve,
        complete_session=session_api.complete,
        activate_scope=activate or default_activate,
        resolve_trace=resolver or default_resolver,
    )


def _issue(sessions, target="job", tenant=TENANT, scope="internal-exp-1"):
    return sessions.issue(tenant_id=tenant, target_name=target, experiment_scope=scope)


def test_replay_sessions_are_opaque_signed_short_lived_and_single_use():
    current = datetime(2026, 8, 28, tzinfo=timezone.utc)
    sessions = _store(now=lambda: current, max_ttl_seconds=30)
    token = _issue(sessions, scope="secret-experiment-123")

    assert "secret-experiment-123" not in token
    assert "tenant-a" not in token
    with pytest.raises(ReplayTargetError, match="tenant_mismatch"):
        sessions.consume(token, tenant_id="tenant-b", target_name="job")
    with pytest.raises(ReplayTargetError, match="target_mismatch"):
        sessions.consume(token, tenant_id=TENANT, target_name="other")

    session = sessions.activate(token, tenant_id=TENANT, target_name="job")
    assert sessions.resolve_active(token, tenant_id=TENANT, target_name="job") == session
    sessions.complete_session(session.session_id)
    with pytest.raises(ReplayTargetError, match="invalid_replay_session"):
        sessions.activate(token, tenant_id=TENANT, target_name="job")

    tampered = token[:-1] + ("0" if token[-1] != "0" else "1")
    with pytest.raises(ReplayTargetError, match="invalid_replay_session"):
        sessions.activate(tampered, tenant_id=TENANT, target_name="job")

    expired = _issue(sessions, target="expired")
    current += timedelta(seconds=31)
    with pytest.raises(ReplayTargetError, match="invalid_replay_session"):
        sessions.activate(expired, tenant_id=TENANT, target_name="expired")


def test_command_target_uses_exact_argv_restricted_cwd_and_allowlisted_env(tmp_path, monkeypatch):
    registry = ReplayTargetRegistry(repo_root=tmp_path)
    sessions = _store()
    output = tmp_path / "observed.json"
    forbidden = tmp_path / "injected"
    literal = f"value; touch {forbidden}"
    script = (
        "import json,os,sys,pathlib; "
        "pathlib.Path(sys.argv[1]).write_text(json.dumps({"
        "'arg':sys.argv[2],'cwd':os.getcwd(),'allowed':os.getenv('ALLOWED_VALUE'),"
        "'secret_present':'SECRET_VALUE' in os.environ,"
        "'experiment_present':'SHELFAI_EXPERIMENT_ID' in os.environ,"
        "'session':os.getenv('SHELFAI_REPLAY_SESSION'),"
        "'target':os.getenv('SHELFAI_REPLAY_TARGET')}))"
    )
    registry.register_command(
        "job",
        [sys.executable, "-c", script, str(output), literal],
        cwd=".",
        env_allowlist=["ALLOWED_VALUE"],
    )
    monkeypatch.setenv("ALLOWED_VALUE", "safe")
    monkeypatch.setenv("SECRET_VALUE", "must-not-leak")
    worker = _worker(tmp_path, registry=registry, sessions=sessions)

    result = asyncio.run(worker.dispatch(replay_session=_issue(sessions), target_name="job"))

    observed = json.loads(output.read_text())
    assert result == {"replay_trace_id": "trace_verified"}
    assert observed["arg"] == literal
    assert observed["cwd"] == str(tmp_path.resolve())
    assert observed["allowed"] == "safe"
    assert observed["secret_present"] is False
    assert observed["experiment_present"] is False
    assert observed["session"].startswith("srp_")
    assert observed["target"] == "job"
    assert not forbidden.exists()
    assert "must-not-leak" not in repr(result)

    outside = tmp_path.parent
    with pytest.raises(ValueError, match="inside"):
        registry.register_command("escape", [sys.executable, "-V"], cwd=outside)


def test_unknown_target_and_cross_target_or_tenant_sessions_fail_closed(tmp_path):
    registry = ReplayTargetRegistry(repo_root=tmp_path)
    registry.register_callback("one", lambda: None)
    registry.register_callback("two", lambda: None)
    sessions = _store()
    worker = _worker(tmp_path, registry=registry, sessions=sessions)

    token = _issue(sessions, target="one")
    with pytest.raises(ReplayTargetError, match="unknown_replay_target"):
        asyncio.run(worker.dispatch(replay_session=token, target_name="missing"))
    with pytest.raises(ReplayTargetError, match="target_mismatch"):
        asyncio.run(worker.dispatch(replay_session=token, target_name="two"))
    with pytest.raises(ReplayTargetError, match="tenant_mismatch"):
        sessions.activate(token, tenant_id="tenant-b", target_name="one")

    result = asyncio.run(worker.dispatch(replay_session=token, target_name="one"))
    assert result["replay_trace_id"] == "trace_verified"


def test_service_callback_receives_no_experiment_id_and_scope_is_internal(tmp_path):
    observed = {}
    registry = ReplayTargetRegistry(repo_root=tmp_path)

    async def callback(invocation):
        observed["invocation"] = invocation

    async def activate(scope, run):
        observed["scope"] = scope
        return await run()

    registry.register_callback("service", callback)
    sessions = _store()
    session_api = _RemoteSessionAPI(sessions)
    worker = _worker(
        tmp_path,
        registry=registry,
        sessions=sessions,
        activate=activate,
        session_api=session_api,
    )
    result = asyncio.run(
        worker.dispatch(
            replay_session=_issue(sessions, target="service", scope="private-experiment"),
            target_name="service",
        )
    )

    assert result == {"replay_trace_id": "trace_verified"}
    assert observed["scope"] == "private-experiment"
    assert observed["invocation"].target_name == "service"
    assert not hasattr(observed["invocation"], "experiment_id")
    assert not hasattr(worker, "sessions")
    assert session_api.completions and session_api.completions[0][1] is True


def test_dynamic_worker_tenant_must_match_signed_payload_and_activation_response(tmp_path):
    registry = ReplayTargetRegistry(repo_root=tmp_path)
    registry.register_callback("job", lambda: None)
    sessions = _store()
    worker = ReplayWorker(
        signing_secret=SECRET,
        registry=registry,
        resolve_session=_RemoteSessionAPI(sessions).resolve,
        complete_session=lambda _session_id, _succeeded: None,
        activate_scope=lambda _scope, callback: callback(),
        resolve_trace=lambda session: ReplayTrace(
            trace_id="trace_verified",
            replay_session_id=session.session_id,
            tenant_id=session.tenant_id,
            target_name=session.target_name,
            sdk_captured=True,
            persisted=True,
        ),
    )

    with pytest.raises(ReplayTargetError, match="tenant_mismatch"):
        asyncio.run(
            worker.dispatch(
                replay_session=_issue(sessions, tenant=TENANT),
                target_name="job",
                tenant_id="tenant-b",
            )
        )

    result = asyncio.run(
        worker.dispatch(
            replay_session=_issue(sessions, tenant=TENANT),
            target_name="job",
            tenant_id=TENANT,
        )
    )
    assert result == {"replay_trace_id": "trace_verified"}


def test_concurrency_limit_fails_closed_instead_of_queueing(tmp_path):
    registry = ReplayTargetRegistry(repo_root=tmp_path)
    sessions = _store()
    started = None
    release = None

    async def callback():
        assert started is not None and release is not None
        started.set()
        await release.wait()

    registry.register_callback("job", callback, concurrency_limit=1)
    worker = _worker(tmp_path, registry=registry, sessions=sessions)

    async def scenario():
        nonlocal started, release
        started = asyncio.Event()
        release = asyncio.Event()
        first = asyncio.create_task(worker.dispatch(replay_session=_issue(sessions), target_name="job"))
        await started.wait()
        with pytest.raises(ReplayTargetError, match="concurrency_exceeded"):
            await worker.dispatch(replay_session=_issue(sessions), target_name="job")
        release.set()
        return await first

    assert asyncio.run(scenario()) == {"replay_trace_id": "trace_verified"}


def test_timeout_callback_exception_nonzero_and_output_limit_are_secret_safe(tmp_path):
    async def slow():
        await asyncio.sleep(0.1)

    callback_registry = ReplayTargetRegistry(repo_root=tmp_path)
    callback_registry.register_callback("slow", slow, timeout_seconds=0.01)
    callback_worker = _worker(tmp_path, registry=callback_registry, sessions=(sessions := _store()))
    with pytest.raises(ReplayTargetError) as timeout:
        asyncio.run(callback_worker.dispatch(replay_session=_issue(sessions, target="slow"), target_name="slow"))
    assert timeout.value.code == "replay_timeout"

    def secret_failure():
        raise RuntimeError("customer-secret-value")

    callback_registry.register_callback("failure", secret_failure)
    with pytest.raises(ReplayTargetError) as failed:
        asyncio.run(callback_worker.dispatch(replay_session=_issue(sessions, target="failure"), target_name="failure"))
    assert failed.value.code == "replay_execution_failed"
    assert "customer-secret-value" not in str(failed.value)

    command_registry = ReplayTargetRegistry(repo_root=tmp_path)
    command_registry.register_command("nonzero", [sys.executable, "-c", "raise SystemExit(7)"])
    command_registry.register_command(
        "noisy",
        [sys.executable, "-c", "print('secret-output-' * 1000)"],
        output_limit_bytes=32,
    )
    command_worker = _worker(tmp_path, registry=command_registry, sessions=(command_sessions := _store()))
    with pytest.raises(ReplayTargetError) as nonzero:
        asyncio.run(
            command_worker.dispatch(
                replay_session=_issue(command_sessions, target="nonzero"),
                target_name="nonzero",
            )
        )
    assert nonzero.value.code == "replay_nonzero_exit"
    with pytest.raises(ReplayTargetError) as noisy:
        asyncio.run(
            command_worker.dispatch(
                replay_session=_issue(command_sessions, target="noisy"),
                target_name="noisy",
            )
        )
    assert noisy.value.code == "replay_output_limit_exceeded"
    assert "secret-output" not in str(noisy.value)


@pytest.mark.parametrize(
    ("trace_factory", "code"),
    [
        (lambda s: None, "replay_trace_missing"),
        (
            lambda s: ReplayTrace("trace", "wrong", s.tenant_id, s.target_name, True, True),
            "replay_trace_session_mismatch",
        ),
        (
            lambda s: ReplayTrace("trace", s.session_id, "other", s.target_name, True, True),
            "replay_trace_tenant_mismatch",
        ),
        (
            lambda s: ReplayTrace("trace", s.session_id, s.tenant_id, "other", True, True),
            "replay_trace_target_mismatch",
        ),
        (
            lambda s: ReplayTrace("trace", s.session_id, s.tenant_id, s.target_name, True, True, offline=True),
            "replay_trace_offline",
        ),
        (
            lambda s: ReplayTrace("trace", s.session_id, s.tenant_id, s.target_name, False, True),
            "replay_trace_unverified",
        ),
    ],
)
def test_result_requires_matching_online_sdk_trace(tmp_path, trace_factory, code):
    registry = ReplayTargetRegistry(repo_root=tmp_path)
    registry.register_callback("job", lambda: None)
    sessions = _store()
    worker = _worker(tmp_path, registry=registry, sessions=sessions, resolver=trace_factory)
    with pytest.raises(ReplayTargetError) as failure:
        asyncio.run(worker.dispatch(replay_session=_issue(sessions), target_name="job"))
    assert failure.value.code == code


def test_asgi_requires_signed_fresh_exact_path_request_and_returns_only_trace(tmp_path):
    registry = ReplayTargetRegistry(repo_root=tmp_path)
    registry.register_callback("job", lambda: None)
    sessions = _store()
    worker = _worker(tmp_path, registry=registry, sessions=sessions)
    token = _issue(sessions)
    payload = {
        "version": "1.0",
        "event": "replay.session.dispatch",
        "tenant_id": TENANT,
        "target_name": "job",
        "replay_session": token,
        "requested_at": datetime.now(timezone.utc).isoformat(),
    }
    body = json.dumps(payload, separators=(",", ":")).encode()
    signature = hmac.new(SECRET.encode(), body, hashlib.sha256).hexdigest()

    async def request(path, signed=True):
        sent = []
        delivered = False

        async def receive():
            nonlocal delivered
            if delivered:
                return {"type": "http.disconnect"}
            delivered = True
            return {"type": "http.request", "body": body, "more_body": False}

        async def send(message):
            sent.append(message)

        headers = [(b"x-shelfai-signature", f"sha256={signature if signed else 'bad'}".encode())]
        await worker.asgi(path="/replay")(
            {"type": "http", "method": "POST", "path": path, "headers": headers},
            receive,
            send,
        )
        return sent

    wrong_path = asyncio.run(request("/replay/"))
    assert wrong_path[0]["status"] == 404
    invalid_signature = asyncio.run(request("/replay", signed=False))
    assert invalid_signature[0]["status"] == 401
    success = asyncio.run(request("/replay"))
    assert success[0]["status"] == 200
    assert json.loads(success[1]["body"]) == {"replay_trace_id": "trace_verified"}
    assert token.encode() not in success[1]["body"]
