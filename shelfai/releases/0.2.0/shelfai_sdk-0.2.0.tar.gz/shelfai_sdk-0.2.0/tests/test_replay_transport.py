from __future__ import annotations

from datetime import datetime, timedelta, timezone
import json

import httpx

from shelfai_sdk.client import ShelfAI
from shelfai_sdk.replay_transport import ReplayBackendTransport


def _response(request: httpx.Request, payload: dict, status_code: int = 200) -> httpx.Response:
    return httpx.Response(status_code, json=payload, request=request)


def test_replay_backend_transport_uses_authenticated_https_api_and_typed_results():
    calls: list[tuple[str, str, dict | None]] = []
    expires = (datetime.now(timezone.utc) + timedelta(minutes=3)).isoformat()

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content) if request.content else None
        calls.append((request.method, request.url.path, body))
        assert request.headers["Authorization"] == "Bearer sdk-key"
        if request.url.path.endswith("/activate"):
            return _response(
                request,
                {
                    "session_id": "rps_0123456789abcdef01234567",
                    "tenant_id": "tenant-a",
                    "target_name": "job",
                    "expires_at": expires,
                },
            )
        if request.url.path.endswith("/bundle"):
            return _response(
                request,
                {
                    "replay_session_id": "rps_0123456789abcdef01234567",
                    "replay_target": "job",
                    "bundle": {"version": "1.0", "patches": []},
                },
            )
        if request.url.path.endswith("/trace"):
            return _response(
                request,
                {
                    "trace_id": "trace_worker",
                    "replay_session_id": "rps_0123456789abcdef01234567",
                    "tenant_id": "tenant-a",
                    "target_name": "job",
                    "sdk_captured": True,
                    "persisted": True,
                    "offline": False,
                },
            )
        return _response(request, {"status": "completed"})

    client = httpx.Client(transport=httpx.MockTransport(handler))
    transport = ReplayBackendTransport(
        api_key="sdk-key",
        api_url="https://shelf.example",
        target_name="job",
        client=client,
    )
    session = transport.activate("srp_opaque", "tenant-a", "job")
    assert session.experiment_scope == "srp_opaque"
    assert transport.resolve_bundle("srp_opaque")["replay_target"] == "job"
    assert transport.resolve_trace(session).trace_id == "trace_worker"
    transport.complete(session.session_id, True)
    assert calls == [
        ("POST", "/api/replay-sessions/activate", {"replay_session": "srp_opaque", "target_name": "job"}),
        ("POST", "/api/replay-sessions/bundle", {"replay_session": "srp_opaque", "target_name": "job"}),
        ("GET", "/api/replay-sessions/rps_0123456789abcdef01234567/trace", None),
        ("POST", "/api/replay-sessions/rps_0123456789abcdef01234567/complete", {"succeeded": True}),
    ]


def test_sdk_resolves_opaque_environment_session_and_binds_telemetry(monkeypatch, tmp_path):
    requests: list[dict] = []

    def handler(request: httpx.Request) -> httpx.Response:
        assert request.url.path == "/api/replay-sessions/bundle"
        payload = json.loads(request.content)
        requests.append(payload)
        return _response(
            request,
            {
                "replay_session_id": "rps_0123456789abcdef01234567",
                "replay_target": "batch.writer",
                "bundle": {
                    "version": "1.0",
                    "experiment_id": "exp_internal_only",
                    "baseline_trace_id": "trace_baseline",
                    "agent_id": "agent-a",
                    "patches": [
                        {
                            "patch_id": "patch-1",
                            "item_id": "ctx-1",
                            "item_type": "message",
                            "source": "openai.messages",
                            "original_content": "old context",
                            "original_hash": "hash",
                            "replacement_content": "better context",
                        }
                    ],
                },
            },
        )

    monkeypatch.setenv("SHELFAI_REPLAY_SESSION", "srp_opaque_only")
    monkeypatch.setenv("SHELFAI_REPLAY_TARGET", "batch.writer")
    http_client = httpx.Client(transport=httpx.MockTransport(handler))
    shelf = ShelfAI(
        api_key="sdk-key",
        agent_id="agent-a",
        api_url="https://shelf.example",
        capture_mode="full",
        offline_queue_path=str(tmp_path / "queue"),
        http_client=http_client,
        start_background_threads=False,
    )
    try:
        system, messages, tools, metadata = shelf.apply_experiment_overrides(
            system=None,
            messages=[{"role": "user", "content": "old context"}],
        )
        assert system is None and tools is None
        assert messages[0]["content"] == "better context"
        assert metadata["replay_session_id"] == "rps_0123456789abcdef01234567"
        assert metadata["replay_target"] == "batch.writer"
        assert requests == [{"replay_session": "srp_opaque_only", "target_name": "batch.writer"}]
        # The opaque token, not an experiment identifier, is the only scope supplied by the child process.
        assert shelf._configured_experiment_id is None
    finally:
        monkeypatch.delenv("SHELFAI_REPLAY_SESSION", raising=False)
        monkeypatch.delenv("SHELFAI_REPLAY_TARGET", raising=False)
        shelf.close()
