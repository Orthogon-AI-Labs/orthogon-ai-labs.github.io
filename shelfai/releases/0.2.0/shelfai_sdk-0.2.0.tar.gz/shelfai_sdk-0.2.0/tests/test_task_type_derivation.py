"""SPEC-294 — task_type derives from each framework's natural step identity.

Funnel-level tests (no framework install needed): every wrapper builds its event
payload through ``framework_adapter._event_metadata(framework, hook, **identity)``,
so the derivation is asserted there. Deterministic, and explicit caller-supplied
``task_type`` always wins.
"""
from __future__ import annotations

from shelfai_sdk.telemetry import framework_adapter as fa


def _meta(framework, **fields):
    return fa._event_metadata(framework, "step_start", **fields)


def test_langgraph_task_type_derives_from_node_name():
    assert _meta("langgraph", node_name="draft_listing")["task_type"] == "draft_listing"


def test_langchain_prefers_tool_name_then_agent():
    assert _meta("langchain", tool_name="web_search")["task_type"] == "web_search"
    # agent is the fallback when there's no tool_name
    assert _meta("langchain", agent="researcher")["task_type"] == "researcher"


def test_crewai_task_type_derives_from_agent_role():
    assert _meta("crewai", agent_role="reviewer")["task_type"] == "reviewer"


def test_autogen_task_type_derives_from_sender():
    assert _meta("autogen", sender="planner")["task_type"] == "planner"


def test_explicit_task_type_overrides_framework_derivation():
    meta = _meta("langgraph", node_name="draft_listing", task_type="custom_label")
    assert meta["task_type"] == "custom_label"


def test_no_identity_leaves_task_type_unset():
    assert "task_type" not in _meta("langgraph")


def test_unknown_framework_does_not_derive():
    assert "task_type" not in _meta("mystery_framework", node_name="x")


def test_blank_or_nonstring_identity_is_ignored():
    assert "task_type" not in _meta("langgraph", node_name="   ")
    assert "task_type" not in _meta("crewai", agent_role=None)


def test_derivation_is_deterministic():
    # same identity -> same task_type, every time
    first = _meta("langgraph", node_name="summarize")["task_type"]
    second = _meta("langgraph", node_name="summarize")["task_type"]
    assert first == second == "summarize"


def test_set_task_type_sources_reorders_candidates():
    original = dict(fa._TASK_TYPE_SOURCES)
    try:
        fa.set_task_type_sources("langchain", ["agent", "tool_name"])
        # agent now wins over tool_name
        meta = _meta("langchain", tool_name="web_search", agent="researcher")
        assert meta["task_type"] == "researcher"
    finally:
        fa._TASK_TYPE_SOURCES.clear()
        fa._TASK_TYPE_SOURCES.update(original)
