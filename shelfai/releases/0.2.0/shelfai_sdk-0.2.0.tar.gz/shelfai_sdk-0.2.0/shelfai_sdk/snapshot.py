"""Pydantic snapshot types for the ShelfAI SDK."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .context_ir import ContextIR


class Message(BaseModel):
    model_config = ConfigDict(extra="allow")

    role: Literal["system", "developer", "user", "assistant", "tool"]
    content: str


class Chunk(BaseModel):
    model_config = ConfigDict(extra="allow")

    id: str
    source: str
    text: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    context_ir: Optional[ContextIR] = None
    rank: Optional[int] = None
    score: Optional[float] = None


class Context(BaseModel):
    model_config = ConfigDict(extra="allow")

    agent_id: str
    trace_id: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    system_prompt: Optional[str] = None
    retrieved_chunks: list[Chunk] = Field(default_factory=list)
    messages: list[Message] = Field(default_factory=list)
    tool_outputs: list[dict[str, Any]] = Field(default_factory=list)
    token_count: int = 0
    chunk_count: Optional[int] = None
    message_count: Optional[int] = None
    metadata: dict[str, Any] = Field(default_factory=dict)
    context_ir: Optional[ContextIR] = None

    @model_validator(mode="after")
    def _populate_counts(self) -> "Context":
        if self.chunk_count is None:
            self.chunk_count = len(self.retrieved_chunks)
        if self.message_count is None:
            self.message_count = len(self.messages)
        if self.timestamp.tzinfo is None:
            self.timestamp = self.timestamp.replace(tzinfo=timezone.utc)
        return self

    def chunk_ids(self) -> list[str]:
        return [chunk.id for chunk in self.retrieved_chunks]

    def snapshot_payload(self) -> dict[str, Any]:
        return self.model_dump(mode="json")
