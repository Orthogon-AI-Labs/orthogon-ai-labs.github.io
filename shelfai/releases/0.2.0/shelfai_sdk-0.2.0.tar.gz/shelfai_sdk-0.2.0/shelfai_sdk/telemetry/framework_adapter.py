"""Canonical framework-to-event adapter for ShelfAI SDK integrations.

| Framework hook | Canonical event | Required metadata |
| --- | --- | --- |
| LangChain `on_chain_start` | `trace_started` | `framework="langchain"`, `chain_type`, `run_id`, `parent_run_id`, `tags`, `inputs` |
| LangChain `on_chain_end` | `trace_finished` | `run_id`, `outputs` |
| LangChain `on_chain_error` | `trace_finished` | `run_id`, `error`, `error_type` |
| LangChain `on_llm_start` | `trace_started` | `framework="langchain"`, `kind="llm"`, `model`, `run_id`, `parent_run_id`, `prompts`, `invocation_params` |
| LangChain `on_llm_new_token` | `trace_output` | `run_id`, `token` |
| LangChain `on_llm_end` | `trace_finished` | `run_id`, `generations`, `token_usage`, `model` |
| LangChain `on_tool_start` | `tool_start` | `framework="langchain"`, `tool_name`, `run_id`, `parent_run_id`, `inputs` |
| LangChain `on_tool_end` | `tool_end` | `run_id`, `output` |
| LangChain `on_tool_error` | `tool_end` | `run_id`, `error`, `error_type` |
| LangChain `on_retriever_start` | `trace_started` | `framework="langchain"`, `kind="retriever"`, `run_id`, `parent_run_id`, `query` |
| LangChain `on_retriever_end` | `trace_finished` | `run_id`, `documents`, `document_count` |
| LangChain `on_agent_action` | `route_decision` | `framework="langchain"`, `agent`, `action`, `action_input`, `run_id` |
| LangChain `on_agent_finish` | `trace_finished` | `run_id`, `output`, `return_values` |
| LangGraph node start | `trace_started` | `framework="langgraph"`, `kind="node"`, `node_name`, `run_id`, `parent_run_id`, `state_snapshot_keys` |
| LangGraph node end | `trace_finished` | `run_id`, `state_delta_keys` |
| LangGraph edge taken | `route_decision` | `framework="langgraph"`, `from_node`, `to_node`, `run_id` |
| CrewAI `kickoff` start | `session_start` | `framework="crewai"`, `crew_id`, `agent_roles`, `task_count` |
| CrewAI `kickoff` end | `session_end` | `session_id`, `outputs`, `execution_time_ms` |
| CrewAI per-task start | `task_assigned` | `framework="crewai"`, `agent_role`, `task_description`, `crew_id`, `task_id` |
| CrewAI per-task end | `task_updated` | `task_id`, `status="completed"`, `output` |
| CrewAI `step_callback` | `trace_output` | `framework="crewai"`, `agent_role`, `step_type`, `step_data` |
| AutoGen `register_reply` | `tool_end` | `framework="autogen"`, `sender`, `receiver`, `message_kind` |

The canonical schema is flat: there is no first-class parent trace or parent
event field. Framework hierarchy is preserved in metadata via `run_id` and
`parent_run_id`.
"""

from __future__ import annotations

from datetime import datetime, timezone
from functools import wraps
import json
from pathlib import Path
from types import MethodType
from typing import Any, Callable, Dict, Iterable, List, Optional, Sequence
from uuid import UUID

from ..context_ir import ContextIR, context_item
from ..runtime_source import attach_runtime_source_evidence
from ..utils import to_jsonable

FRAMEWORK_ADAPTER_VERSION = "1.0"


def _utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _run_id_str(run_id: Optional[UUID]) -> Optional[str]:
    return str(run_id) if run_id is not None else None


def _safe_jsonable(value: Any) -> Any:
    if isinstance(value, UUID):
        return str(value)
    if isinstance(value, BaseException):
        return {
            "error": str(value),
            "error_type": type(value).__name__,
        }
    if isinstance(value, dict):
        return {str(key): _safe_jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_safe_jsonable(item) for item in value]
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, datetime):
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).isoformat()
    if hasattr(value, "model_dump"):
        try:
            return _safe_jsonable(value.model_dump(mode="json"))
        except Exception:
            return repr(value)
    if hasattr(value, "dict"):
        try:
            return _safe_jsonable(value.dict())
        except Exception:
            return repr(value)
    if hasattr(value, "__dict__") and not isinstance(value, type):
        try:
            return {
                str(key): _safe_jsonable(item)
                for key, item in vars(value).items()
                if not key.startswith("_")
            }
        except Exception:
            return repr(value)
    converted = to_jsonable(value)
    try:
        json.dumps(converted)
        return converted
    except TypeError:
        return repr(value)


# --- SPEC-294: derive task_type from each framework's natural step identity -----
# Per-type control (goals/rubrics, SPEC-293) hinges on task_type being meaningful.
# Rather than ask callers to hand-tag every step, default task_type to the identity
# the framework already gives the step. Ordered candidate fields per framework; the
# first non-empty one wins. Deterministic: same step -> same identity -> same
# task_type. Explicit caller-supplied task_type always overrides (the funnel only
# derives when task_type is absent).
_TASK_TYPE_SOURCES: Dict[str, tuple] = {
    "langgraph": ("node_name",),
    "langchain": ("tool_name", "agent", "chain_type"),
    "crewai": ("agent_role", "task_name"),
    "autogen": ("sender", "receiver"),
}


def set_task_type_sources(framework: str, fields) -> None:
    """Configure which captured identity field(s) derive ``task_type`` for a
    framework (ordered; the first non-empty value wins). For per-integration
    tuning, e.g. ``set_task_type_sources("langchain", ["agent", "tool_name"])``."""
    _TASK_TYPE_SOURCES[framework] = tuple(fields)


def _derive_task_type(framework: str, fields: Dict[str, Any]) -> Optional[str]:
    """Default ``task_type`` to the framework's natural step identity (SPEC-294).
    Returns ``None`` when no identity is available — the funnel then leaves
    ``task_type`` unset rather than inventing one."""
    for key in _TASK_TYPE_SOURCES.get(framework, ()):
        value = fields.get(key)
        if isinstance(value, str) and value.strip():
            return value
    return None


def _event_metadata(
    framework: str,
    hook: str,
    framework_metadata: Optional[Dict[str, Any]] = None,
    framework_raw: Optional[Dict[str, Any]] = None,
    **fields: Any,
) -> Dict[str, Any]:
    # SPEC-294: default task_type to the framework's step identity when the caller
    # didn't supply one explicitly (explicit always wins).
    if not fields.get("task_type"):
        derived = _derive_task_type(framework, fields)
        if derived:
            fields["task_type"] = derived
    metadata = {
        "framework": framework,
        "hook": hook,
        "adapter_version": FRAMEWORK_ADAPTER_VERSION,
        **fields,
    }
    if framework_metadata is not None:
        metadata["framework_metadata"] = _safe_jsonable(framework_metadata)
    if framework_raw:
        metadata["framework_raw"] = _safe_jsonable(framework_raw)
    return _safe_jsonable(metadata)


def _emit_event(shelf: Any, name: str, metadata: Dict[str, Any], trace_id: Optional[str] = None) -> None:
    shelf.emit_event(name, metadata=metadata, trace_id=trace_id)


def _state_store(target: Any) -> Dict[str, Dict[str, Any]]:
    store = getattr(target, "_framework_runs", None)
    if store is None:
        store = {}
        setattr(target, "_framework_runs", store)
    return store


def _remember_run(target: Any, run_id: UUID, payload: Dict[str, Any]) -> None:
    _state_store(target)[str(run_id)] = payload


def _get_run(target: Any, run_id: UUID) -> Dict[str, Any]:
    return dict(_state_store(target).get(str(run_id), {}))


def _pop_run(target: Any, run_id: UUID) -> Dict[str, Any]:
    return dict(_state_store(target).pop(str(run_id), {}))


def _normalized_role(role: Optional[str]) -> str:
    normalized = (role or "user").lower()
    if normalized in {"human", "humanmessage", "user"}:
        return "user"
    if normalized in {"ai", "aimessage", "assistant"}:
        return "assistant"
    if normalized in {"system", "systemmessage"}:
        return "system"
    if normalized in {"tool", "toolmessage", "function"}:
        return "tool"
    return "user"


def _messages_to_payload(messages: Sequence[Sequence[Any]]) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    for group in messages:
        for message in group:
            payload.append(
                {
                    "role": _normalized_role(getattr(message, "type", None)),
                    "content": str(getattr(message, "content", "")),
                    "additional_kwargs": _safe_jsonable(getattr(message, "additional_kwargs", {})),
                    "response_metadata": _safe_jsonable(getattr(message, "response_metadata", {})),
                }
            )
    return payload


def _snapshot_messages(
    shelf: Any,
    trace_id: str,
    system: Optional[str],
    messages: List[Dict[str, Any]],
    metadata: Dict[str, Any],
    runtime_source: Optional[Dict[str, Any]] = None,
) -> None:
    context = shelf.extract_context_from_call(
        system=system,
        messages=messages,
        trace_id=trace_id,
        metadata=metadata,
        runtime_source=runtime_source,
    )
    shelf.snapshot(context, trace_id=trace_id)


def _runtime_source_from_kwargs(kwargs: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Consume wrapper-captured source evidence without copying it into raw metadata."""

    value = kwargs.pop("_shelfai_runtime_source", None)
    return value if isinstance(value, dict) else None


def _serialized_name(serialized: Any, fallback: Optional[str] = None) -> str:
    if isinstance(serialized, dict):
        name = serialized.get("name")
        if isinstance(name, str) and name:
            return name
        identifier = serialized.get("id")
        if isinstance(identifier, list) and identifier:
            return str(identifier[-1])
        representation = serialized.get("repr")
        if isinstance(representation, str) and representation:
            return representation
    if fallback:
        return fallback
    return str(serialized or "unknown")


def _langchain_framework(metadata: Optional[Dict[str, Any]], kwargs: Dict[str, Any]) -> str:
    data = metadata or {}
    if data.get("langgraph_node") or kwargs.get("name") == "LangGraph":
        return "langgraph"
    return "langchain"


def _langchain_chain_kind(metadata: Optional[Dict[str, Any]], kwargs: Dict[str, Any]) -> str:
    data = metadata or {}
    if data.get("langgraph_node"):
        return "node"
    if kwargs.get("name") == "LangGraph":
        return "graph"
    if kwargs.get("run_type"):
        return str(kwargs["run_type"])
    return "chain"


def _parse_langgraph_from_node(metadata: Optional[Dict[str, Any]], parent_run_id: Optional[UUID]) -> Optional[str]:
    triggers = list((metadata or {}).get("langgraph_triggers") or [])
    if not triggers:
        return "START" if parent_run_id is None else None
    trigger = str(triggers[0])
    if trigger.startswith("branch:to:"):
        return "START" if parent_run_id is None else None
    return trigger


def _llm_generations(response: Any) -> List[Dict[str, Any]]:
    generations: List[Dict[str, Any]] = []
    for group in getattr(response, "generations", []) or []:
        for item in group or []:
            text = getattr(item, "text", None)
            if text is None and hasattr(item, "message"):
                text = getattr(getattr(item, "message"), "content", None)
            generations.append(
                {
                    "text": text,
                    "generation_info": _safe_jsonable(getattr(item, "generation_info", None)),
                    "message": _safe_jsonable(getattr(item, "message", None)),
                }
            )
    return generations


def _documents_payload(documents: Sequence[Any]) -> List[Dict[str, Any]]:
    payload: List[Dict[str, Any]] = []
    for document in documents:
        payload.append(
            {
                "page_content": str(getattr(document, "page_content", "")),
                "metadata": _safe_jsonable(getattr(document, "metadata", {})),
                "id": _safe_jsonable(getattr(document, "id", None)),
            }
        )
    return payload


def _response_output(value: Any) -> Any:
    return _safe_jsonable(value)


def emit_langchain_chain_start(
    handler: Any,
    serialized: Dict[str, Any],
    inputs: Dict[str, Any],
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    tags: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> None:
    runtime_source = _runtime_source_from_kwargs(kwargs)
    framework = _langchain_framework(metadata, kwargs)
    kind = _langchain_chain_kind(metadata, kwargs)
    chain_type = _serialized_name(serialized, kwargs.get("name"))
    trace_id = _run_id_str(run_id)
    state_ir = attach_runtime_source_evidence(
        ContextIR(items=[context_item("state_snapshot", inputs, run_id=trace_id, source=f"{framework}.chain.inputs")]),
        runtime_source,
    )
    event_metadata = _event_metadata(
        framework,
        "on_chain_start",
        metadata,
        {
            "serialized": serialized,
            "inputs": inputs,
            "kwargs": kwargs,
        },
        kind=kind,
        chain_type=chain_type,
        node_name=(metadata or {}).get("langgraph_node"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        tags=tags or [],
        inputs=_safe_jsonable(inputs),
        state_snapshot_keys=sorted(list((inputs or {}).keys())),
        context_ir=state_ir.model_dump(mode="json"),
    )
    _remember_run(
        handler,
        run_id,
        {
            "framework": framework,
            "kind": kind,
            "trace_id": trace_id,
            "chain_type": chain_type,
            "node_name": (metadata or {}).get("langgraph_node"),
            "metadata": _safe_jsonable(metadata or {}),
            "inputs": _safe_jsonable(inputs),
        },
    )
    _emit_event(handler.shelf, "trace_started", event_metadata, trace_id=trace_id)
    if framework == "langgraph" and kind == "node":
        route_metadata = _event_metadata(
            "langgraph",
            "on_chain_start",
            metadata,
            {
                "serialized": serialized,
                "inputs": inputs,
                "kwargs": kwargs,
            },
            run_id=trace_id,
            parent_run_id=_run_id_str(parent_run_id),
            from_node=_parse_langgraph_from_node(metadata, parent_run_id),
            to_node=(metadata or {}).get("langgraph_node"),
            triggers=_safe_jsonable((metadata or {}).get("langgraph_triggers")),
        )
        _emit_event(handler.shelf, "route_decision", route_metadata, trace_id=trace_id)


def emit_langchain_chain_end(
    handler: Any,
    outputs: Any,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_chain_end",
        state.get("metadata"),
        {
            "outputs": outputs,
            "kwargs": kwargs,
        },
        kind=state.get("kind", "chain"),
        chain_type=state.get("chain_type"),
        node_name=state.get("node_name"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        outputs=_response_output(outputs),
        state_delta_keys=sorted(list(outputs.keys())) if isinstance(outputs, dict) else [],
    )
    _emit_event(handler.shelf, "trace_finished", event_metadata, trace_id=trace_id)


def emit_langchain_chain_error(
    handler: Any,
    error: BaseException,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_chain_error",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind=state.get("kind", "chain"),
        chain_type=state.get("chain_type"),
        node_name=state.get("node_name"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        error=str(error),
        error_type=type(error).__name__,
    )
    _emit_event(handler.shelf, "trace_finished", event_metadata, trace_id=trace_id)


def emit_langchain_llm_start(
    handler: Any,
    serialized: Dict[str, Any],
    prompts: List[str],
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    tags: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> None:
    runtime_source = _runtime_source_from_kwargs(kwargs)
    framework = _langchain_framework(metadata, kwargs)
    trace_id = _run_id_str(run_id)
    model = _serialized_name(serialized, kwargs.get("name"))
    event_metadata = _event_metadata(
        framework,
        "on_llm_start",
        metadata,
        {
            "serialized": serialized,
            "prompts": prompts,
            "kwargs": kwargs,
        },
        kind="llm",
        model=model,
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        tags=tags or [],
        prompts=_safe_jsonable(prompts),
        invocation_params=_safe_jsonable(kwargs.get("invocation_params")),
    )
    _remember_run(
        handler,
        run_id,
        {
            "framework": framework,
            "kind": "llm",
            "trace_id": trace_id,
            "model": model,
            "metadata": _safe_jsonable(metadata or {}),
        },
    )
    _emit_event(handler.shelf, "trace_started", event_metadata, trace_id=trace_id)
    snapshot_metadata = _event_metadata(
        framework,
        "on_llm_start",
        metadata,
        {
            "serialized": serialized,
            "prompts": prompts,
            "kwargs": kwargs,
        },
        provider="langchain",
        model=model,
        kind="llm",
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        tags=tags or [],
    )
    _snapshot_messages(
        handler.shelf,
        trace_id,
        None,
        [{"role": "user", "content": prompt} for prompt in prompts],
        snapshot_metadata,
        runtime_source,
    )


def emit_langchain_chat_model_start(
    handler: Any,
    serialized: Dict[str, Any],
    messages: Sequence[Sequence[Any]],
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    tags: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> None:
    runtime_source = _runtime_source_from_kwargs(kwargs)
    framework = _langchain_framework(metadata, kwargs)
    trace_id = _run_id_str(run_id)
    model = _serialized_name(serialized, kwargs.get("name"))
    payload_messages = _messages_to_payload(messages)
    system = next((message["content"] for message in payload_messages if message["role"] == "system"), None)
    event_metadata = _event_metadata(
        framework,
        "on_chat_model_start",
        metadata,
        {
            "serialized": serialized,
            "messages": payload_messages,
            "kwargs": kwargs,
        },
        kind="llm",
        model=model,
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        tags=tags or [],
        messages=payload_messages,
        invocation_params=_safe_jsonable(kwargs.get("invocation_params")),
    )
    _remember_run(
        handler,
        run_id,
        {
            "framework": framework,
            "kind": "llm",
            "trace_id": trace_id,
            "model": model,
            "metadata": _safe_jsonable(metadata or {}),
        },
    )
    _emit_event(handler.shelf, "trace_started", event_metadata, trace_id=trace_id)
    snapshot_metadata = _event_metadata(
        framework,
        "on_chat_model_start",
        metadata,
        {
            "serialized": serialized,
            "messages": payload_messages,
            "kwargs": kwargs,
        },
        provider="langchain",
        model=model,
        kind="llm",
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        tags=tags or [],
    )
    _snapshot_messages(
        handler.shelf,
        trace_id,
        system,
        payload_messages,
        snapshot_metadata,
        runtime_source,
    )


def emit_langchain_llm_new_token(
    handler: Any,
    token: str,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _get_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_llm_new_token",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind=state.get("kind", "llm"),
        model=state.get("model"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        token=token,
        chunk=_safe_jsonable(kwargs.get("chunk")),
    )
    _emit_event(handler.shelf, "trace_output", event_metadata, trace_id=trace_id)


def emit_langchain_llm_end(
    handler: Any,
    response: Any,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    llm_output = _safe_jsonable(getattr(response, "llm_output", None))
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_llm_end",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind=state.get("kind", "llm"),
        model=state.get("model"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        generations=_llm_generations(response),
        token_usage=(llm_output or {}).get("token_usage") if isinstance(llm_output, dict) else None,
        llm_output=llm_output,
    )
    _emit_event(handler.shelf, "trace_finished", event_metadata, trace_id=trace_id)


def emit_langchain_llm_error(
    handler: Any,
    error: BaseException,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_llm_error",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind=state.get("kind", "llm"),
        model=state.get("model"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        error=str(error),
        error_type=type(error).__name__,
    )
    _emit_event(handler.shelf, "trace_finished", event_metadata, trace_id=trace_id)


def emit_langchain_tool_start(
    handler: Any,
    serialized: Dict[str, Any],
    input_str: str,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    tags: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    inputs: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> None:
    runtime_source = _runtime_source_from_kwargs(kwargs)
    framework = _langchain_framework(metadata, kwargs)
    trace_id = _run_id_str(run_id)
    tool_name = _serialized_name(serialized, kwargs.get("name"))
    tool_ir = attach_runtime_source_evidence(
        ContextIR(items=[context_item(
            "tool_call",
            {"name": tool_name, "input": inputs if inputs is not None else input_str},
            run_id=trace_id,
            source=f"{framework}.tool",
        )]),
        runtime_source,
    )
    _remember_run(
        handler,
        run_id,
        {
            "framework": framework,
            "kind": "tool",
            "trace_id": trace_id,
            "tool_name": tool_name,
            "metadata": _safe_jsonable(metadata or {}),
        },
    )
    event_metadata = _event_metadata(
        framework,
        "on_tool_start",
        metadata,
        {
            "serialized": serialized,
            "kwargs": kwargs,
        },
        tool_name=tool_name,
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        tags=tags or [],
        inputs=_safe_jsonable(inputs) if inputs is not None else input_str,
        input=input_str,
        context_ir=tool_ir.model_dump(mode="json"),
    )
    _emit_event(handler.shelf, "tool_start", event_metadata, trace_id=trace_id)


def emit_langchain_tool_end(
    handler: Any,
    output: Any,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    runtime_source = _runtime_source_from_kwargs(kwargs)
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    result_ir = attach_runtime_source_evidence(
        ContextIR(items=[context_item(
            "tool_result",
            output,
            run_id=trace_id,
            source=f"{state.get('framework', 'langchain')}.tool.result",
            selection="produced",
        )]),
        runtime_source,
    )
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_tool_end",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        tool_name=state.get("tool_name"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        output=_response_output(output),
        context_ir=result_ir.model_dump(mode="json"),
    )
    _emit_event(handler.shelf, "tool_end", event_metadata, trace_id=trace_id)


def emit_langchain_tool_error(
    handler: Any,
    error: BaseException,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_tool_error",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        tool_name=state.get("tool_name"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        error=str(error),
        error_type=type(error).__name__,
    )
    _emit_event(handler.shelf, "tool_end", event_metadata, trace_id=trace_id)


def emit_langchain_retriever_start(
    handler: Any,
    serialized: Dict[str, Any],
    query: str,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    tags: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> None:
    framework = _langchain_framework(metadata, kwargs)
    trace_id = _run_id_str(run_id)
    retriever_name = _serialized_name(serialized, kwargs.get("name"))
    _remember_run(
        handler,
        run_id,
        {
            "framework": framework,
            "kind": "retriever",
            "trace_id": trace_id,
            "retriever_name": retriever_name,
            "metadata": _safe_jsonable(metadata or {}),
        },
    )
    event_metadata = _event_metadata(
        framework,
        "on_retriever_start",
        metadata,
        {
            "serialized": serialized,
            "kwargs": kwargs,
        },
        kind="retriever",
        retriever_name=retriever_name,
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        tags=tags or [],
        query=query,
    )
    _emit_event(handler.shelf, "trace_started", event_metadata, trace_id=trace_id)


def emit_langchain_retriever_end(
    handler: Any,
    documents: Sequence[Any],
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    runtime_source = _runtime_source_from_kwargs(kwargs)
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    payload_documents = _documents_payload(documents)
    evidence_ir = attach_runtime_source_evidence(
        ContextIR(items=[
            context_item(
                "retrieved_evidence",
                document,
                ordinal=index,
                run_id=trace_id,
                source=f"{state.get('framework', 'langchain')}.retriever",
            )
            for index, document in enumerate(payload_documents)
        ]),
        runtime_source,
    )
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_retriever_end",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind="retriever",
        retriever_name=state.get("retriever_name"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        documents=payload_documents,
        document_count=len(payload_documents),
        context_ir=evidence_ir.model_dump(mode="json"),
    )
    _emit_event(handler.shelf, "trace_finished", event_metadata, trace_id=trace_id)


def emit_langchain_retriever_error(
    handler: Any,
    error: BaseException,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _pop_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_retriever_error",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind="retriever",
        retriever_name=state.get("retriever_name"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        error=str(error),
        error_type=type(error).__name__,
    )
    _emit_event(handler.shelf, "trace_finished", event_metadata, trace_id=trace_id)


def emit_langchain_agent_action(
    handler: Any,
    action: Any,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    trace_id = _run_id_str(run_id)
    event_metadata = _event_metadata(
        "langgraph" if kwargs.get("metadata", {}).get("langgraph_node") else "langchain",
        "on_agent_action",
        None,
        {
            "kwargs": kwargs,
        },
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        agent=_safe_jsonable(getattr(action, "agent", None)),
        action=_safe_jsonable(getattr(action, "tool", None)),
        action_input=_safe_jsonable(getattr(action, "tool_input", None)),
        log=str(getattr(action, "log", "")),
    )
    _emit_event(handler.shelf, "route_decision", event_metadata, trace_id=trace_id)


def emit_langchain_agent_finish(
    handler: Any,
    finish: Any,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    trace_id = _run_id_str(run_id)
    event_metadata = _event_metadata(
        "langchain",
        "on_agent_finish",
        None,
        {
            "kwargs": kwargs,
        },
        kind="agent",
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        output=_safe_jsonable(getattr(finish, "output", None)),
        return_values=_safe_jsonable(getattr(finish, "return_values", None)),
        log=str(getattr(finish, "log", "")),
    )
    _emit_event(handler.shelf, "trace_finished", event_metadata, trace_id=trace_id)


def emit_langchain_custom_event(
    handler: Any,
    name: str,
    data: Any,
    run_id: UUID,
    tags: Optional[List[str]] = None,
    metadata: Optional[Dict[str, Any]] = None,
    **kwargs: Any,
) -> None:
    trace_id = _run_id_str(run_id)
    event_metadata = _event_metadata(
        "langchain",
        "on_custom_event",
        metadata,
        {
            "kwargs": kwargs,
        },
        run_id=trace_id,
        tags=tags or [],
        event_name=name,
        data=_safe_jsonable(data),
    )
    _emit_event(handler.shelf, "trace_output", event_metadata, trace_id=trace_id)


def emit_langchain_retry(
    handler: Any,
    retry_state: Any,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _get_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_retry",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind=state.get("kind"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        retry_state=_safe_jsonable(retry_state),
    )
    _emit_event(handler.shelf, "trace_output", event_metadata, trace_id=trace_id)


def emit_langchain_text(
    handler: Any,
    text: str,
    run_id: UUID,
    parent_run_id: Optional[UUID] = None,
    **kwargs: Any,
) -> None:
    state = _get_run(handler, run_id)
    trace_id = state.get("trace_id") or _run_id_str(run_id)
    event_metadata = _event_metadata(
        state.get("framework", "langchain"),
        "on_text",
        state.get("metadata"),
        {
            "kwargs": kwargs,
        },
        kind=state.get("kind"),
        run_id=trace_id,
        parent_run_id=_run_id_str(parent_run_id),
        text=text,
    )
    _emit_event(handler.shelf, "trace_output", event_metadata, trace_id=trace_id)


def emit_crewai_session_start(crew: Any, session_id: str, inputs: Optional[Dict[str, Any]]) -> None:
    agent_roles = [getattr(agent, "role", "unknown") for agent in getattr(crew, "agents", [])]
    metadata = _event_metadata(
        "crewai",
        "kickoff_start",
        None,
        {"inputs": inputs},
        crew_id=getattr(crew, "crew_id", None) or str(getattr(crew, "id")),
        session_id=session_id,
        agent_roles=agent_roles,
        task_count=len(getattr(crew, "tasks", [])),
        inputs=_safe_jsonable(inputs or {}),
    )
    _emit_event(crew.shelf, "session_start", metadata, trace_id=session_id)


def emit_crewai_session_end(
    crew: Any,
    session_id: str,
    outputs: Any,
    started_at: datetime,
    error: Optional[BaseException] = None,
) -> None:
    duration_ms = int((_utc_now() - started_at).total_seconds() * 1000)
    metadata = _event_metadata(
        "crewai",
        "kickoff_end",
        None,
        None,
        crew_id=getattr(crew, "crew_id", None) or str(getattr(crew, "id")),
        session_id=session_id,
        outputs=_safe_jsonable(outputs),
        execution_time_ms=duration_ms,
        error=str(error) if error else None,
        error_type=type(error).__name__ if error else None,
    )
    _emit_event(crew.shelf, "session_end", metadata, trace_id=session_id)


def emit_crewai_task_assigned(crew: Any, task: Any, agent: Any, session_id: str) -> None:
    metadata = _event_metadata(
        "crewai",
        "task_start",
        None,
        None,
        crew_id=getattr(crew, "crew_id", None) or str(getattr(crew, "id")),
        session_id=session_id,
        task_id=str(getattr(task, "id")),
        task_name=getattr(task, "name", None),
        task_description=getattr(task, "description", ""),
        agent_role=getattr(agent, "role", None),
        expected_output=getattr(task, "expected_output", None),
    )
    _emit_event(crew.shelf, "task_assigned", metadata, trace_id=session_id)


def emit_crewai_task_updated(
    crew: Any,
    task: Any,
    session_id: str,
    output: Any = None,
    status: str = "completed",
    error: Optional[BaseException] = None,
) -> None:
    metadata = _event_metadata(
        "crewai",
        "task_end",
        None,
        None,
        crew_id=getattr(crew, "crew_id", None) or str(getattr(crew, "id")),
        session_id=session_id,
        task_id=str(getattr(task, "id")),
        task_name=getattr(task, "name", None),
        task_description=getattr(task, "description", ""),
        agent_role=getattr(getattr(task, "agent", None), "role", None),
        status=status,
        output=_safe_jsonable(output),
        error=str(error) if error else None,
        error_type=type(error).__name__ if error else None,
    )
    _emit_event(crew.shelf, "task_updated", metadata, trace_id=session_id)


def emit_crewai_step_output(crew: Any, session_id: str, agent_role: Optional[str], step: Any) -> None:
    metadata = _event_metadata(
        "crewai",
        "step_callback",
        None,
        None,
        crew_id=getattr(crew, "crew_id", None) or str(getattr(crew, "id")),
        session_id=session_id,
        agent_role=agent_role,
        step_type=type(step).__name__,
        step_data=_safe_jsonable(step),
    )
    _emit_event(crew.shelf, "trace_output", metadata, trace_id=session_id)


def wrap_crewai_step_callback(crew: Any, agent: Any, original: Optional[Callable[..., Any]], session_id: str) -> Callable[..., Any]:
    @wraps(original) if callable(original) else (lambda func: func)
    def _wrapped(step: Any) -> Any:
        emit_crewai_step_output(crew, session_id, getattr(agent, "role", None), step)
        if callable(original):
            return original(step)
        return None

    return _wrapped


def wrap_crewai_task_execution(crew: Any, task: Any, session_id: str) -> Callable[..., Any]:
    original = task._execute_core

    def _wrapped(self_task: Any, agent: Any, context: Optional[str], tools: Optional[List[Any]]) -> Any:
        emit_crewai_task_assigned(crew, self_task, agent or getattr(self_task, "agent", None), session_id)
        try:
            output = original(agent, context, tools)
            emit_crewai_task_updated(crew, self_task, session_id, output=output, status="completed")
            return output
        except Exception as error:
            emit_crewai_task_updated(crew, self_task, session_id, status="failed", error=error)
            raise

    return MethodType(_wrapped, task)


def emit_autogen_reply(
    shelf: Any,
    agent: Any,
    recipient: Any,
    messages: Optional[List[Dict[str, Any]]],
    sender: Any,
    config: Any,
) -> None:
    message = (messages or [])[-1] if messages else {}
    trace_id_factory = getattr(shelf, "generate_trace_id", None)
    trace_id = trace_id_factory() if callable(trace_id_factory) else None
    metadata = _event_metadata(
        "autogen",
        "register_reply",
        None,
        {
            "config": config,
            "messages": messages,
        },
        sender=getattr(sender, "name", None),
        receiver=getattr(recipient, "name", None),
        agent_name=getattr(agent, "name", None),
        message_kind=message.get("role") if isinstance(message, dict) else type(message).__name__,
        message=_safe_jsonable(message),
    )
    _emit_event(shelf, "tool_end", metadata, trace_id=trace_id or getattr(agent, "name", None))
