"""Telemetry helpers for the ShelfAI SDK."""

from .framework_adapter import FRAMEWORK_ADAPTER_VERSION

__all__ = ["FRAMEWORK_ADAPTER_VERSION"]
