"""Primary ShelfAI client implementation."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from contextlib import contextmanager
from contextvars import ContextVar
import asyncio
import hashlib
import hmac
import inspect
import json
import os
import re
import threading
import warnings
from typing import Any, Callable, Dict, List, Mapping, Optional, Union

import httpx

from .critical import CriticalChunk
from .context_ir import (
    ContextIR,
    context_payload_hash,
    context_payload_hashes,
    context_text_fragments,
    provider_input_ir,
)
from .capture_mode import (
    DEFAULT_CAPTURE_MODE,
    normalize_capture_mode,
    sanitize_payload_for_capture_mode,
)
from .events import ShelfEvent, snapshot_event
from .invariants import Invariant, InvariantCheck
from .lineage import ContextRef, materializer_payload
from .queue import OfflineQueue
from .runtime_source import runtime_source_enabled
from .snapshot import Context, Message
from .trace import Trace
from .transport import Transport
from .utils import env_or_default, generate_id, to_jsonable
from .wrappers import wrap_anthropic_client, wrap_openai_client


@dataclass(frozen=True)
class BaselineContextEstimate:
    approx_input_tokens: int = 0
    approx_output_tokens: int = 0


class ExperimentReplayError(RuntimeError):
    """Raised before a provider call when an explicit experiment cannot be applied."""


class _StandardReplayHandler:
    """Hybrid replay endpoint for opaque sessions with legacy event compatibility."""

    _MAX_BODY_BYTES = 64 * 1024

    def __init__(
        self,
        *,
        shelf: "ShelfAI",
        signing_secret: str,
        legacy_handler: Any,
        worker_factory: Callable[[], Any],
    ) -> None:
        self.shelf = shelf
        self._signing_secret = signing_secret
        self.legacy_handler = legacy_handler
        self._worker_factory = worker_factory
        self._worker: Any = None

    async def __call__(
        self,
        body: bytes | bytearray | memoryview | str,
        headers: Mapping[str, Any],
    ) -> dict[str, str]:
        raw = body.encode("utf-8") if isinstance(body, str) else bytes(body)
        event = self._event_name(raw)
        if event == "context.experiment.replay_requested":
            return await self.legacy_handler(raw, headers)
        self._verify_signature(raw, headers)
        worker = self._get_worker()
        payload = worker._verify_request(raw, headers)
        return await worker.dispatch(
            replay_session=payload["replay_session"],
            target_name=payload["target_name"],
            tenant_id=payload["tenant_id"],
        )

    def _get_worker(self) -> Any:
        if self._worker is None:
            self._worker = self._worker_factory()
        return self._worker

    def asgi(self):
        """Return the replay endpoint as an ASGI callable object.

        A callable *object* (not a bare function) is required so Starlette and
        FastAPI treat it as an ASGI app when passed to ``app.add_route``; a
        plain function would be wrapped as a request handler instead.
        """

        return _ReplayASGIApp(self)

    async def serve(self, scope, receive, send) -> None:
        if scope.get("type") != "http" or scope.get("method") != "POST":
            await _replay_asgi_json(send, 405, {"error": "method_not_allowed"})
            return
        headers = {
            key.decode("latin-1"): value.decode("latin-1")
            for key, value in scope.get("headers", [])
        }
        content_length = _replay_header(headers, "content-length")
        if content_length:
            try:
                if int(content_length) > self._MAX_BODY_BYTES:
                    await _replay_asgi_json(send, 413, {"error": "replay_request_too_large"})
                    return
            except ValueError:
                pass
        chunks: list[bytes] = []
        total = 0
        while True:
            message = await receive()
            if message.get("type") == "http.disconnect":
                await _replay_asgi_json(send, 401, {"error": "invalid_replay_request"})
                return
            chunk = bytes(message.get("body", b""))
            total += len(chunk)
            if total > self._MAX_BODY_BYTES:
                await _replay_asgi_json(send, 413, {"error": "replay_request_too_large"})
                return
            chunks.append(chunk)
            if not message.get("more_body", False):
                break
        try:
            result = await self(b"".join(chunks), headers)
        except Exception as exc:
            from .replay import ReplayRequestError
            from .replay_targets import ReplayTargetError

            if isinstance(exc, ReplayTargetError):
                status = {
                    "invalid_replay_signature": 401,
                    "invalid_replay_request": 401,
                    "invalid_replay_session": 401,
                    "replay_session_tenant_mismatch": 401,
                    "replay_session_target_mismatch": 401,
                    "unknown_replay_target": 404,
                    "replay_concurrency_exceeded": 409,
                    "replay_timeout": 504,
                }.get(exc.code, 422)
                await _replay_asgi_json(send, status, {"error": exc.code})
                return
            if isinstance(exc, ReplayRequestError):
                await _replay_asgi_json(send, 401, {"error": "invalid_replay_request"})
                return
            await _replay_asgi_json(send, 500, {"error": "replay_failed"})
            return
        await _replay_asgi_json(send, 200, result)

    @staticmethod
    def _event_name(raw: bytes) -> str:
        try:
            payload = json.loads(raw)
        except (TypeError, ValueError, json.JSONDecodeError):
            return ""
        if not isinstance(payload, dict):
            return ""
        return str(payload.get("event") or "")

    def _verify_signature(self, raw: bytes, headers: Mapping[str, Any]) -> None:
        from .replay_targets import ReplayTargetError

        supplied = _replay_header(headers, "X-ShelfAI-Signature")
        if supplied.startswith("sha256="):
            supplied = supplied[len("sha256=") :]
        expected = hmac.new(self._signing_secret.encode("utf-8"), raw, hashlib.sha256).hexdigest()
        if not supplied or not _signature_matches(supplied, expected):
            raise ReplayTargetError("invalid_replay_signature")


def _signature_matches(supplied: str, expected: str) -> bool:
    """Constant-time compare that treats a malformed (non-ASCII) header as a mismatch."""

    try:
        return hmac.compare_digest(supplied, expected)
    except (TypeError, ValueError):
        return False


class _ReplayASGIApp:
    """ASGI callable object for the standard replay endpoint."""

    def __init__(self, handler: "_StandardReplayHandler") -> None:
        self._handler = handler

    async def __call__(self, scope, receive, send) -> None:
        await self._handler.serve(scope, receive, send)


def _replay_header(headers: Mapping[str, Any], name: str) -> str:
    expected = name.lower()
    for key, value in headers.items():
        if str(key).lower() == expected:
            return str(value or "")
    return ""


async def _replay_asgi_json(send, status: int, payload: Mapping[str, Any]) -> None:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode("ascii")),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})


class ShelfAI:
    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        api_url: Optional[str] = None,
        capture_mode: Optional[str] = None,
        environment: str = "production",
        sensitive_mode: Optional[str] = None,
        offline_queue_path: Optional[str] = None,
        batch_size: Optional[int] = None,
        batch_interval_seconds: Optional[int] = None,
        http_client: Optional[httpx.Client] = None,
        start_background_threads: bool = True,
        experiment_id: Optional[str] = None,
        replay: Optional[Callable[..., Any]] = None,
        replay_signing_secret: Optional[str] = None,
        runtime_source_evidence: bool | str | None = None,
    ):
        self.api_key = api_key or env_or_default("SHELFAI_API_KEY")
        self.agent_id = agent_id or env_or_default("SHELFAI_AGENT_ID")
        if not self.api_key or not self.agent_id:
            raise ValueError("ShelfAI requires api_key and agent_id")
        self.api_url = (api_url or env_or_default("SHELFAI_API_URL", "http://127.0.0.1:8000")).rstrip("/")
        self.environment = environment or env_or_default("SHELFAI_ENVIRONMENT", "production")
        requested_capture_mode = (
            capture_mode
            or sensitive_mode
            or env_or_default("SHELFAI_CAPTURE_MODE")
            or env_or_default("SHELFAI_SENSITIVE_MODE", DEFAULT_CAPTURE_MODE)
        )
        self.sensitive_mode = normalize_capture_mode(requested_capture_mode)
        self.runtime_source_evidence = runtime_source_enabled(runtime_source_evidence)
        self.offline_queue_path = offline_queue_path or env_or_default(
            "SHELFAI_OFFLINE_QUEUE_PATH",
            ".shelfai-sdk",
        )
        self.batch_size = batch_size or env_or_default("SHELFAI_BATCH_SIZE", 100, int)
        self.batch_interval_seconds = batch_interval_seconds or env_or_default(
            "SHELFAI_BATCH_INTERVAL",
            5,
            int,
        )
        self._critical_chunks: dict[str, CriticalChunk] = {}
        self._invariants: list[Invariant] = []
        self._active_traces: dict[str, Trace] = {}
        self._context_lineage: dict[str, dict[str, Any]] = {}
        self._output_refs: dict[str, ContextRef] = {}
        self._automatic_output_refs: dict[str, ContextRef] = {}
        self._automatic_output_text_refs: dict[str, ContextRef] = {}
        self._last_health_payload: Optional[Dict[str, Any]] = None
        self._health_thread: Optional[threading.Thread] = None
        self._health_stop = threading.Event()
        # Experiments are activated by the signed replay endpoint.  Reading a
        # process-wide environment variable here can accidentally alter normal
        # production traffic, so the constructor value is compatibility-only.
        self._configured_experiment_id = experiment_id or None
        self._active_experiment_id: ContextVar[Optional[str]] = ContextVar(
            f"shelfai_experiment_{id(self)}",
            default=None,
        )
        self._execution_state: ContextVar[Optional[dict[str, Any]]] = ContextVar(
            f"shelfai_execution_{id(self)}",
            default=None,
        )
        self._experiment_bundle_cache: dict[str, Optional[dict[str, Any]]] = {}
        self._experiment_bundle_errors: dict[str, str] = {}
        self._configured_replay_session = env_or_default("SHELFAI_REPLAY_SESSION") or ""
        self._configured_replay_target = env_or_default("SHELFAI_REPLAY_TARGET") or ""
        self._environment_replay_unavailable = False
        #: Trace ID of the most recent captured provider call in this process.
        self.last_trace_id: Optional[str] = None
        self._active_replay_session: ContextVar[Optional[tuple[str, str]]] = ContextVar(
            f"shelfai_replay_session_{id(self)}",
            default=None,
        )
        self._replay_session_bundle_cache: dict[str, dict[str, Any]] = {}
        self._replay_callback = replay
        self._replay_signing_secret = replay_signing_secret or env_or_default("SHELFAI_REPLAY_SECRET") or ""
        self._replay_handler_instance: Any = None

        self.offline_queue = OfflineQueue(self.offline_queue_path)
        self.transport = Transport(
            api_key=self.api_key,
            agent_id=self.agent_id,
            api_url=self.api_url,
            offline_queue=self.offline_queue,
            batch_size=self.batch_size,
            batch_interval_seconds=self.batch_interval_seconds,
            client=http_client,
            start_background_thread=start_background_threads,
            capture_mode=self.sensitive_mode,
        )

    @property
    def experiment_id(self) -> Optional[str]:
        """Experiment active for this execution context, if any."""

        return self._active_experiment_id.get() or self._configured_experiment_id

    @experiment_id.setter
    def experiment_id(self, value: Optional[str]) -> None:
        """Retain compatibility with callers that select a manual replay after construction."""

        self._configured_experiment_id = value or None

    async def _run_with_experiment(self, experiment_id: str, callback: Callable[[], Any]) -> Any:
        token = self._active_experiment_id.set(experiment_id)
        try:
            with self.execution() as trace_id:
                if inspect.iscoroutinefunction(callback):
                    result = await callback()
                else:
                    result = await asyncio.to_thread(callback)
                    if inspect.isawaitable(result):
                        result = await result
                # A replay is not successful until telemetry has left the
                # in-memory buffer, and it must never claim a queued event as
                # remotely verifiable.
                self.transport.flush()
                state = self._execution_state.get() or {}
                if trace_id not in state.get("captured", set()):
                    raise RuntimeError("Replay workflow did not capture a ShelfAI provider event.")
                if self._trace_is_offline(trace_id):
                    raise RuntimeError("Replay telemetry is offline and cannot be verified.")
                return trace_id
        finally:
            self._active_experiment_id.reset(token)

    async def _run_with_replay_session(
        self,
        replay_session: str,
        target_name: str,
        callback: Callable[[], Any],
    ) -> Any:
        """Run a registered callback with opaque replay scope resolved by the SDK."""

        scope_token = self._active_replay_session.set((replay_session, target_name))
        try:
            with self.execution() as trace_id:
                if inspect.iscoroutinefunction(callback):
                    result = await callback()
                else:
                    result = await asyncio.to_thread(callback)
                    if inspect.isawaitable(result):
                        result = await result
                self.transport.flush()
                state = self._execution_state.get() or {}
                if trace_id not in state.get("captured", set()):
                    raise RuntimeError("Replay workflow did not capture a ShelfAI provider event.")
                if self._trace_is_offline(trace_id):
                    raise RuntimeError("Replay telemetry is offline and cannot be verified.")
                return trace_id
        finally:
            self._active_replay_session.reset(scope_token)

    def _trace_is_offline(self, trace_id: str) -> bool:
        """Exact-match a trace across the complete durable queue."""

        pending = self.offline_queue.load_batch(limit=max(self.offline_queue.size(), 1))
        for item in pending:
            try:
                event = json.loads(item.event_json)
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            if str(event.get("trace_id") or "") == trace_id:
                return True
        return False

    @contextmanager
    def execution(self):
        """Group all provider calls in this workflow under one run ID."""

        current = self._execution_state.get()
        if current is not None:
            yield current["trace_id"]
            return
        state = {"trace_id": self.generate_trace_id(), "captured": set()}
        token = self._execution_state.set(state)
        try:
            yield state["trace_id"]
        finally:
            self._execution_state.reset(token)

    def current_trace_id(self) -> Optional[str]:
        """Return the active execution trace ID for safe instrumentation helpers."""

        state = self._execution_state.get()
        if not isinstance(state, dict):
            return None
        trace_id = state.get("trace_id")
        return str(trace_id) if trace_id else None

    def replay_handler(self):
        """Return the signed replay handler configured for this application."""

        if self._replay_callback is None:
            raise ValueError("ShelfAI replay requires a workflow callback.")
        if not self._replay_signing_secret:
            raise ValueError("ShelfAI replay requires SHELFAI_REPLAY_SECRET or replay_signing_secret.")
        if self._replay_handler_instance is None:
            from .replay import ReplayHandler
            from .replay_targets import ReplayTargetRegistry
            from .replay_transport import ReplayBackendTransport

            legacy_handler = ReplayHandler(
                agent_id=self.agent_id,
                signing_secret=self._replay_signing_secret,
                callback=self._replay_callback,
                activate_experiment=self._run_with_experiment,
            )

            def worker_factory():
                registry = ReplayTargetRegistry(repo_root=os.getcwd())
                registry.register_callback("default", self._replay_callback)
                transport = ReplayBackendTransport(
                    api_key=self.api_key,
                    api_url=self.api_url,
                    target_name="default",
                    client=self.transport.client,
                )
                return transport.worker(
                    signing_secret=self._replay_signing_secret,
                    registry=registry,
                    shelf=self,
                )

            self._replay_handler_instance = _StandardReplayHandler(
                shelf=self,
                signing_secret=self._replay_signing_secret,
                legacy_handler=legacy_handler,
                worker_factory=worker_factory,
            )
        return self._replay_handler_instance

    def replay_app(self):
        """Return the standard ASGI endpoint for a signed replay hook."""

        return self.replay_handler().asgi()

    def generate_trace_id(self) -> str:
        return generate_id("trace")

    def unregister_trace(self, trace_id: str) -> None:
        self._active_traces.pop(trace_id, None)

    def trace(self, name: str) -> Trace:
        trace = Trace(name=name, shelf=self)
        execution = self._execution_state.get()
        if execution is not None:
            trace.id = execution["trace_id"]
        self._active_traces[trace.id] = trace
        return trace

    def context_ref(
        self,
        item_id: str,
        *,
        trace_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        stage: Optional[str] = None,
    ) -> ContextRef:
        """Create an explicit reference to a previously captured context item."""

        return ContextRef(
            item_id=str(item_id),
            trace_id=trace_id,
            agent_id=agent_id,
            stage=stage,
        )

    def handoff(
        self,
        value: Any,
        *,
        derived_from: Any = None,
        materialized_by: Callable[..., Any] | str | None = None,
        source_path: Optional[str] = None,
        revision: Optional[str] = None,
        stage: Optional[str] = None,
        name: Optional[str] = None,
    ) -> Any:
        """Annotate an assembled value while returning it unchanged.

        Provider calls remain normal Python. The wrapped client recognizes the
        value later and adds its upstream parents and materializer to Context IR.
        """

        candidates = derived_from if isinstance(derived_from, (list, tuple, set)) else [derived_from]
        refs: list[ContextRef] = []
        derived_hashes: list[str] = []
        for candidate in candidates:
            if candidate is None:
                continue
            if isinstance(candidate, ContextRef):
                refs.append(candidate)
                continue
            candidate_hash = context_payload_hash(candidate)
            derived_hashes.append(candidate_hash)
            for fingerprint in context_payload_hashes(candidate):
                ref = self._output_refs.get(fingerprint)
                if ref is not None and ref not in refs:
                    refs.append(ref)
                    break

        materialization = materializer_payload(
            materialized_by,
            source_path=source_path,
            revision=revision,
        )
        if materialization.get("path"):
            # The application author declared this locator in code. It is more
            # than an inference, but it is not an owner confirmation either.
            materialization["truth"] = "declared"
        producer = refs[0].payload() if refs else None
        annotation = {
            "parent_ids": [ref.item_id for ref in refs],
            "origin": {
                "kind": "upstream_output" if refs else "runtime_assembly",
                **({"producer": producer} if producer else {}),
                **({"derived_from": [ref.payload() for ref in refs]} if refs else {}),
            },
            "materialization": materialization,
            "metadata": {
                "context_role": "handoff",
                **({"handoff_name": name} if name else {}),
                **({"derived_from_hashes": derived_hashes} if derived_hashes else {}),
            },
            **({"stage": stage} if stage else {}),
        }
        self._context_lineage[context_payload_hash(value)] = annotation
        return value

    def _apply_context_lineage(self, envelope: ContextIR) -> ContextIR:
        annotated = []
        for item in envelope.items:
            exact = context_payload_hash(item.raw_payload)
            fingerprints = [exact, *(context_payload_hashes(item.raw_payload) - {exact})]
            annotation = next(
                (self._context_lineage[fingerprint] for fingerprint in fingerprints if fingerprint in self._context_lineage),
                None,
            )
            if annotation is None:
                refs, detection = self._infer_output_refs(item.raw_payload)
                if refs:
                    producer = refs[0].payload()
                    annotation = {
                        "parent_ids": [ref.item_id for ref in refs],
                        "origin": {
                            "kind": "upstream_output",
                            "producer": producer,
                            "derived_from": [ref.payload() for ref in refs],
                        },
                        # Runtime matching proves the causal handoff, but cannot
                        # truthfully identify the durable assembler in source.
                        "materialization": {"kind": "ephemeral"},
                        "metadata": {
                            "context_role": "handoff",
                            "lineage_detection": detection,
                            "source_annotation_required": True,
                        },
                    }
            if annotation is None:
                annotated.append(item)
                continue
            annotated.append(item.model_copy(update={
                "parent_ids": list(annotation.get("parent_ids") or item.parent_ids),
                "stage": annotation.get("stage") or item.stage,
                "origin": dict(annotation.get("origin") or {}),
                "materialization": dict(annotation.get("materialization") or {}),
                "metadata": {**dict(item.metadata or {}), **dict(annotation.get("metadata") or {})},
            }))
        return envelope.model_copy(update={"items": annotated})

    def register_output_context(self, envelope: ContextIR) -> None:
        """Remember produced values so a later handoff can cite them by value."""

        for item in envelope.items:
            ref = ContextRef(
                item_id=item.id,
                trace_id=item.run_id,
                agent_id=self.agent_id,
                stage=item.stage,
            )
            for fingerprint in context_payload_hashes(item.raw_payload):
                self._output_refs[fingerprint] = ref
            self._automatic_output_refs[context_payload_hash(item.raw_payload)] = ref
            for fragment in context_text_fragments(item.raw_payload):
                self._automatic_output_text_refs[fragment] = ref
        self._trim_lineage_cache()

    def _infer_output_refs(self, value: Any) -> tuple[list[ContextRef], str | None]:
        """Infer conservative cross-call lineage without changing caller values."""

        exact = self._automatic_output_refs.get(context_payload_hash(value))
        if exact is not None:
            return [exact], "automatic_exact"

        refs: list[ContextRef] = []
        input_fragments = context_text_fragments(value)
        if not input_fragments:
            return refs, None
        for output_text, ref in reversed(tuple(self._automatic_output_text_refs.items())):
            if any(output_text == input_text or output_text in input_text for input_text in input_fragments):
                if not any(existing.item_id == ref.item_id for existing in refs):
                    refs.append(ref)
        return refs, "automatic_contained_text" if refs else None

    def _trim_lineage_cache(self, limit: int = 512) -> None:
        """Bound process-local inference state for long-running agents."""

        for mapping in (self._automatic_output_refs, self._automatic_output_text_refs):
            overflow = len(mapping) - limit
            for key in list(mapping)[: max(overflow, 0)]:
                mapping.pop(key, None)

    def _experiment_bundle(self) -> Optional[dict[str, Any]]:
        replay_scope = self._active_replay_session.get()
        scope_from_environment = False
        if replay_scope is None and self._configured_replay_session and not self._environment_replay_unavailable:
            replay_scope = (self._configured_replay_session, self._configured_replay_target)
            scope_from_environment = True
        if replay_scope is not None:
            replay_session, target_name = replay_scope
            if not target_name:
                if scope_from_environment:
                    self._ignore_environment_replay("SHELFAI_REPLAY_TARGET is not set")
                    return None
                raise ExperimentReplayError("ShelfAI replay target is missing for the active replay session.")
            cache_key = hashlib.sha256(replay_session.encode("utf-8")).hexdigest()
            cached = self._replay_session_bundle_cache.get(cache_key)
            if cached is not None:
                return cached
            try:
                from .replay_transport import ReplayBackendTransport

                resolved = ReplayBackendTransport(
                    api_key=self.api_key,
                    api_url=self.api_url,
                    target_name=target_name,
                    client=self.transport.client,
                ).resolve_bundle(replay_session, target_name=target_name)
                bundle = dict(resolved["bundle"])
                if str(bundle.get("agent_id") or "") != self.agent_id:
                    raise ValueError("replay session is scoped to a different ShelfAI agent")
                bundle["_shelfai_replay_session_id"] = str(resolved.get("replay_session_id") or "")
                bundle["_shelfai_replay_target"] = str(resolved.get("replay_target") or "")
                if not bundle["_shelfai_replay_session_id"] or bundle["_shelfai_replay_target"] != target_name:
                    raise ValueError("replay session binding is invalid")
                self._replay_session_bundle_cache[cache_key] = bundle
                return bundle
            except ExperimentReplayError:
                raise
            except Exception as exc:
                if scope_from_environment:
                    # A stale or foreign SHELFAI_REPLAY_SESSION in a production
                    # process must not take the application down. Production
                    # traffic proceeds unmodified; a real replay still fails
                    # closed because its verified trace will not match.
                    self._ignore_environment_replay(type(exc).__name__)
                    return None
                raise ExperimentReplayError("ShelfAI replay session could not be resolved.") from exc

        experiment_id = self.experiment_id
        if not experiment_id:
            return None
        if experiment_id in self._experiment_bundle_cache:
            return self._experiment_bundle_cache[experiment_id]
        try:
            response = self._request(
                "GET",
                f"/api/context/experiments/{experiment_id}/bundle",
            )
            bundle = response.json()
            if str(bundle.get("agent_id") or "") != self.agent_id:
                raise ValueError("experiment is scoped to a different ShelfAI agent")
            self._experiment_bundle_cache[experiment_id] = bundle
        except Exception as exc:
            self._experiment_bundle_errors[experiment_id] = type(exc).__name__
            warnings.warn(
                f"ShelfAI experiment_bundle ({type(exc).__name__})",
                RuntimeWarning,
                stacklevel=2,
            )
            self._experiment_bundle_cache[experiment_id] = None
        return self._experiment_bundle_cache[experiment_id]

    def _ignore_environment_replay(self, error_type: str) -> None:
        self._environment_replay_unavailable = True
        warnings.warn(
            "ShelfAI ignored SHELFAI_REPLAY_SESSION for this process "
            f"(environment_replay_unavailable: {error_type}); production traffic is unmodified.",
            RuntimeWarning,
            stacklevel=3,
        )

    @staticmethod
    def _normalized_experiment_text(value: str) -> str:
        return " ".join(value.split())

    @staticmethod
    def _resolved_experiment_replacement(value: str, original: str, replacement: str) -> Optional[str]:
        candidate = ShelfAI._normalized_experiment_text(value)
        captured = ShelfAI._normalized_experiment_text(original)
        if candidate == captured:
            return replacement
        placeholders = list(re.finditer(r"\[REDACTED_[A-Z0-9_]+\]", captured))
        if not placeholders:
            return None
        parts: list[str] = []
        cursor = 0
        for index, match in enumerate(placeholders):
            parts.append(re.escape(captured[cursor:match.start()]))
            parts.append(f"(?P<redacted_{index}>.+?)")
            cursor = match.end()
        parts.append(re.escape(captured[cursor:]))
        matched = re.fullmatch("".join(parts), candidate)
        if matched is None:
            return None
        resolved = replacement
        for index, placeholder in enumerate(placeholders):
            resolved = resolved.replace(placeholder.group(0), matched.group(f"redacted_{index}"), 1)
        return resolved

    @staticmethod
    def _replace_context_value(value: Any, original: str, replacement: str) -> tuple[Any, bool]:
        if isinstance(value, str):
            resolved = ShelfAI._resolved_experiment_replacement(value, original, replacement)
            if resolved is not None:
                return resolved, True
            return value, False
        if isinstance(value, list):
            changed = False
            resolved = []
            for item in value:
                next_item, item_changed = ShelfAI._replace_context_value(item, original, replacement)
                resolved.append(next_item)
                changed = changed or item_changed
            return resolved, changed
        if isinstance(value, tuple):
            resolved, changed = ShelfAI._replace_context_value(list(value), original, replacement)
            return tuple(resolved), changed
        if isinstance(value, dict):
            changed = False
            resolved = {}
            for key, item in value.items():
                next_item, item_changed = ShelfAI._replace_context_value(item, original, replacement)
                resolved[key] = next_item
                changed = changed or item_changed
            return resolved, changed
        return value, False

    @staticmethod
    def _experiment_target_keys(source: Any) -> tuple[str, ...]:
        normalized = str(source or "").strip().lower()
        if normalized.endswith(".system") or normalized.endswith(".instructions"):
            return ("system",)
        if ".messages" in normalized or normalized.endswith(".input"):
            return ("messages",)
        if ".tools" in normalized:
            return ("tools",)
        return ("system", "messages", "tools")

    def _transfer_experiment_lineage(self, value: Any, original: str, replacement: str) -> None:
        """Keep a handoff annotation attached to its in-memory replacement."""

        if isinstance(value, str):
            resolved = self._resolved_experiment_replacement(value, original, replacement)
            if resolved is None:
                return
            annotation = self._context_lineage.get(context_payload_hash(value))
            if annotation is not None:
                self._context_lineage[context_payload_hash(resolved)] = annotation
            return
        if isinstance(value, dict):
            for item in value.values():
                self._transfer_experiment_lineage(item, original, replacement)
            return
        if isinstance(value, (list, tuple)):
            for item in value:
                self._transfer_experiment_lineage(item, original, replacement)

    def apply_experiment_overrides(
        self,
        *,
        system: Any,
        messages: Any,
        tools: Any = None,
    ) -> tuple[Any, Any, Any, dict[str, Any]]:
        """Apply an explicitly selected experiment in memory, never to source."""

        bundle = self._experiment_bundle()
        if bundle is None:
            if self.experiment_id:
                detail = self._experiment_bundle_errors.get(self.experiment_id) or "experiment bundle was unavailable"
                raise ExperimentReplayError(
                    f"ShelfAI experiment '{self.experiment_id}' cannot run: {detail}"
                )
            return system, messages, tools, {}
        resolved = {"system": system, "messages": messages, "tools": tools}
        applied: list[str] = []
        matched_lineage: list[tuple[Any, str, str]] = []
        patches = bundle.get("patches") or []
        expected: list[str] = []
        for ordinal, patch in enumerate(patches):
            patch_id = str(patch.get("patch_id") or f"patch-{ordinal + 1}")
            expected.append(patch_id)
            original = str(patch.get("original_content") or "")
            replacement = str(patch.get("replacement_content") or "")
            if not original:
                continue
            for key in self._experiment_target_keys(patch.get("source")):
                before = resolved[key]
                resolved[key], changed = self._replace_context_value(resolved[key], original, replacement)
                if changed:
                    matched_lineage.append((before, original, replacement))
                    if patch_id not in applied:
                        applied.append(patch_id)
        missing = [patch_id for patch_id in expected if patch_id not in applied]
        if not expected or missing:
            detail = "bundle contained no patches" if not expected else f"unmatched patches: {', '.join(missing)}"
            raise ExperimentReplayError(
                f"ShelfAI experiment '{self.experiment_id}' was not sent to the provider ({detail})."
            )
        for before, original, replacement in matched_lineage:
            self._transfer_experiment_lineage(before, original, replacement)
        metadata = {
            "experiment_id": bundle.get("experiment_id"),
            "baseline_trace_id": bundle.get("baseline_trace_id"),
            "applied_patch_ids": applied,
            "experiment_patch_count": len(expected),
        }
        replay_session_id = str(bundle.get("_shelfai_replay_session_id") or "")
        replay_target = str(bundle.get("_shelfai_replay_target") or "")
        if replay_session_id and replay_target:
            metadata["replay_session_id"] = replay_session_id
            metadata["replay_target"] = replay_target
        return resolved["system"], resolved["messages"], resolved["tools"], metadata

    def emit_event(
        self,
        name: str,
        metadata: Optional[Dict[str, Any]] = None,
        trace_id: Optional[str] = None,
        *,
        event_fields: Optional[Dict[str, Any]] = None,
    ) -> None:
        event = ShelfEvent(
            name=name,
            trace_id=trace_id,
            metadata=metadata or {},
            **(event_fields or {}),
        )
        self.transport.enqueue_event(event.payload())

    def register_critical(
        self,
        name: str,
        chunk_id: Optional[str] = None,
        chunk_ids: Optional[Union[str, List[str]]] = None,
        ttl_seconds: int = 3600,
    ) -> None:
        resolved = []
        if chunk_id:
            resolved.append(chunk_id)
        if chunk_ids:
            if isinstance(chunk_ids, str):
                resolved.append(chunk_ids)
            else:
                resolved.extend(chunk_ids)
        if not resolved:
            raise ValueError("register_critical requires chunk_id or chunk_ids")
        self._critical_chunks[name] = CriticalChunk(name=name, chunk_ids=resolved, ttl_seconds=ttl_seconds)

    def invariant(self, rule: str, severity: str = "warning") -> None:
        self._invariants.append(Invariant.parse(rule, severity=severity))

    def invariant_custom(
        self,
        name: str,
        callback: Callable[[Context], tuple[bool, str]],
        severity: str = "warning",
    ) -> None:
        self._invariants.append(Invariant.custom(name, callback, severity=severity))

    def _critical_registry(self) -> Dict[str, List[str]]:
        return {name: item.chunk_ids for name, item in self._critical_chunks.items()}

    def check_invariants(self, context: Context) -> list[InvariantCheck]:
        registry = self._critical_registry()
        return [item.check(context, registry) for item in self._invariants]

    def _emit_invariant_failures(self, checks: List[InvariantCheck], trace_id: Optional[str]) -> None:
        for check in checks:
            if check.passed:
                continue
            self.emit_event(
                "invariant_violated",
                {
                    "name": check.name,
                    "rule": check.rule,
                    "severity": check.severity,
                    "message": check.message,
                },
                trace_id=trace_id,
            )

    def _emit_missing_critical(self, context: Context) -> None:
        for item in self._critical_chunks.values():
            if not item.active(context.timestamp):
                continue
            missing = item.missing_from(context)
            if not missing:
                continue
            self.emit_event(
                "critical_missing",
                {
                    "name": item.name,
                    "missing": missing,
                    "ttl_seconds": item.ttl_seconds,
                },
                trace_id=context.trace_id,
            )

    def snapshot(self, context: Union[Context, Dict[str, Any]], trace_id: Optional[str] = None) -> None:
        resolved = context if isinstance(context, Context) else Context(**context)
        execution = self._execution_state.get()
        if not resolved.agent_id:
            resolved.agent_id = self.agent_id
        if trace_id:
            resolved.trace_id = trace_id
        elif execution is not None:
            resolved.trace_id = execution["trace_id"]
        elif resolved.trace_id is None:
            resolved.trace_id = self.generate_trace_id()

        checks = self.check_invariants(resolved)
        self._emit_invariant_failures(checks, resolved.trace_id)
        self._emit_missing_critical(resolved)
        self.transport.enqueue_event(snapshot_event(resolved).payload())
        self.last_trace_id = resolved.trace_id
        if execution is not None and resolved.trace_id == execution.get("trace_id"):
            execution["captured"].add(resolved.trace_id)

    def report_health(self, **payload: Any) -> None:
        sanitized_payload = sanitize_payload_for_capture_mode(payload, self.sensitive_mode)
        self._last_health_payload = dict(sanitized_payload)
        try:
            self._request(
                "POST",
                f"/api/agents/{self.agent_id}/heartbeat",
                json={
                    "agent_id": self.agent_id,
                    "sdk_version": "0.2.0",
                    "runtime": "python",
                    **to_jsonable(sanitized_payload),
                },
            )
        except Exception:
            pass
        self.emit_event("health_reported", to_jsonable(sanitized_payload))

    def enable_auto_health_reporting(self, interval_seconds: int = 60) -> None:
        self._health_stop.clear()

        def _runner() -> None:
            while not self._health_stop.wait(interval_seconds):
                if self._last_health_payload is None:
                    continue
                self.report_health(**self._last_health_payload)

        self._health_thread = threading.Thread(target=_runner, daemon=True)
        self._health_thread.start()

    def extract_context_from_call(
        self,
        system: Optional[str],
        messages: Union[List[Dict[str, Any]], List[Any]],
        trace_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
        tools: Optional[List[Any]] = None,
        stage: Optional[str] = None,
        runtime_source: Optional[Dict[str, Any]] = None,
    ) -> Context:
        normalized_messages = []
        for message in messages:
            if isinstance(message, Message):
                normalized_messages.append(message)
                continue
            if isinstance(message, dict):
                normalized_messages.append(
                    Message(
                        role=message.get("role", "user"),
                        content=str(message.get("content", "")),
                    )
                )
                continue
            normalized_messages.append(Message(role="user", content=str(message)))

        return Context(
            agent_id=self.agent_id,
            trace_id=trace_id,
            timestamp=datetime.now(timezone.utc),
            system_prompt=system,
            messages=normalized_messages,
            metadata=metadata or {},
            context_ir=self._apply_context_lineage(provider_input_ir(
                provider=str((metadata or {}).get("provider") or "unknown"),
                system=system,
                messages=messages,
                tools=tools,
                run_id=trace_id,
                stage=stage or str((metadata or {}).get("stage") or "") or None,
                runtime_source=runtime_source,
            )),
        )

    def reconstruct_baseline_context(
        self,
        system: Optional[str],
        messages: Union[List[Dict[str, Any]], List[Any]],
    ) -> BaselineContextEstimate:
        planner = getattr(self, "planner", None)
        raw_context_size = getattr(planner, "raw_context_size", None)
        if callable(raw_context_size):
            try:
                estimate = raw_context_size(system=system, messages=messages)
            except TypeError:
                estimate = raw_context_size()

            if isinstance(estimate, tuple):
                input_tokens = estimate[0] if len(estimate) > 0 else 0
                output_tokens = estimate[1] if len(estimate) > 1 else 0
            elif isinstance(estimate, dict):
                input_tokens = estimate.get("approx_input_tokens", estimate.get("input_tokens", 0))
                output_tokens = estimate.get("approx_output_tokens", estimate.get("output_tokens", 0))
            else:
                input_tokens = getattr(estimate, "approx_input_tokens", getattr(estimate, "input_tokens", 0))
                output_tokens = getattr(estimate, "approx_output_tokens", getattr(estimate, "output_tokens", 0))

            try:
                return BaselineContextEstimate(
                    approx_input_tokens=max(int(input_tokens or 0), 0),
                    approx_output_tokens=max(int(output_tokens or 0), 0),
                )
            except (TypeError, ValueError):
                pass

        return BaselineContextEstimate()

    def wrap(self, client: Any) -> Any:
        wrapped = wrap_anthropic_client(client, self)
        if wrapped is not client:
            return wrapped
        wrapped = wrap_openai_client(client, self)
        if wrapped is not client:
            return wrapped
        return client

    @classmethod
    def integrate(cls, *, client: Any, **kwargs: Any):
        """Return the fail-open public integration handle."""

        from .integration import integrate

        return integrate(client=client, shelf_class=cls, **kwargs)

    @classmethod
    def connect(cls, **kwargs: Any):
        """Return an optional observer handle for framework integrations."""

        from .integration import connect

        return connect(shelf_class=cls, **kwargs)

    def _request(self, method: str, path: str, **kwargs):
        client = self.transport.client
        response = client.request(
            method,
            f"{self.api_url}{path}",
            headers={"Authorization": f"Bearer {self.api_key}", **kwargs.pop("headers", {})},
            **kwargs,
        )
        response.raise_for_status()
        return response

    def get_pending_proposals(self) -> list[dict[str, Any]]:
        response = self._request(
            "GET",
            "/api/proposals",
            params={"agent_id": self.agent_id, "status": "pending"},
        )
        payload = response.json()
        return payload.get("proposals") or payload.get("items") or payload

    def get_recommendations(self, rec_type: Optional[str] = None) -> Dict[str, Any]:
        params = {}
        if rec_type:
            params["rec_type"] = rec_type
        response = self._request(
            "GET",
            f"/api/v1/agents/{self.agent_id}/recommendations",
            params=params or None,
        )
        return response.json()

    def get_health(self) -> Dict[str, Any]:
        response = self._request("GET", f"/api/v1/agents/{self.agent_id}/health")
        return response.json()

    def ask_wiki(self, question: str) -> Dict[str, Any]:
        response = self._request(
            "POST",
            "/api/v1/seeker/ask",
            json={"question": question, "stream": False, "history": [], "scope": {"type": "all"}},
        )
        return response.json()

    def approve_proposal(self, proposal_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        response = self._request("POST", f"/api/proposals/{proposal_id}/approve", json={"reason": reason or ""})
        self.emit_event("proposal_approved", {"proposal_id": proposal_id, "reason": reason or ""})
        return response.json()

    def reject_proposal(self, proposal_id: str, reason: Optional[str] = None) -> Dict[str, Any]:
        response = self._request("POST", f"/api/proposals/{proposal_id}/reject", json={"reason": reason or ""})
        self.emit_event("proposal_rejected", {"proposal_id": proposal_id, "reason": reason or ""})
        return response.json()

    def close(self) -> None:
        self._health_stop.set()
        if self._health_thread is not None:
            self._health_thread.join(timeout=1.0)
        self.transport.close()

    def __del__(self) -> None:
        try:
            self.close()
        except Exception:
            pass
