"""Critical context registry for the ShelfAI SDK."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Optional

from .snapshot import Context


@dataclass
class CriticalChunk:
    name: str
    chunk_ids: list[str]
    ttl_seconds: int
    registered_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))

    def active(self, now: Optional[datetime] = None) -> bool:
        current = now or datetime.now(timezone.utc)
        return current <= self.registered_at + timedelta(seconds=self.ttl_seconds)

    def missing_from(self, context: Context) -> list[str]:
        present = set(context.chunk_ids())
        return [chunk_id for chunk_id in self.chunk_ids if chunk_id not in present]
