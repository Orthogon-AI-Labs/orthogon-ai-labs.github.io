"""Fail-open, application-scoped ShelfAI integration helpers."""

from __future__ import annotations

from contextlib import asynccontextmanager, contextmanager
from dataclasses import dataclass
import inspect
import os
from typing import Any, Callable, Optional, Type
import weakref

from .generic_tools import wrap_tool, wrap_tools


_FALSE_VALUES = {"", "0", "false", "no", "off", "disabled"}


def _close_safely(shelf: Any) -> None:
    try:
        shelf.close()
    except Exception:
        pass


@dataclass
class IntegrationStatus:
    """Credential-free state suitable for logs and health endpoints."""

    requested: bool
    active: bool
    wrapped: bool
    reason: str
    error_type: Optional[str] = None


class _UnavailableReplayApp:
    """ASGI callable that answers 503 while ShelfAI is inactive."""

    async def __call__(self, _scope, _receive, send) -> None:
        body = b'{"error":"replay_unavailable"}'
        await send(
            {
                "type": "http.response.start",
                "status": 503,
                "headers": [
                    (b"content-type", b"application/json"),
                    (b"content-length", str(len(body)).encode("ascii")),
                ],
            }
        )
        await send({"type": "http.response.body", "body": body})


_unavailable_replay_app = _UnavailableReplayApp()


class ShelfAIIntegration:
    """Own one optional ShelfAI instance and its application lifecycle."""

    def __init__(
        self,
        *,
        client: Any,
        shelf: Any = None,
        status: IntegrationStatus,
    ) -> None:
        self.client = client
        self.shelf = shelf
        self.status = status
        self._closed = False
        self._finalizer = weakref.finalize(self, _close_safely, shelf) if shelf is not None else None

    def replay_app(self):
        """Return a mount-safe ASGI app that fails replay requests closed."""

        if self.shelf is None:
            return _UnavailableReplayApp()
        try:
            return self.shelf.replay_app()
        except Exception:
            return _UnavailableReplayApp()

    @property
    def last_trace_id(self) -> Optional[str]:
        """Trace ID of the most recent captured provider call, if any."""

        if self.shelf is None:
            return None
        return getattr(self.shelf, "last_trace_id", None)

    def install(self, app: Any, *, path: str = "/shelfai/replay") -> "ShelfAIIntegration":
        """Attach the replay endpoint and shutdown flush to a Starlette/FastAPI app.

        The endpoint is registered as an exact ``POST`` route (no trailing-slash
        redirect, so the registered hook URL can be exactly ``.../shelfai/replay``)
        and telemetry is flushed when the application's lifespan ends. The call
        never raises: an application that cannot host the route keeps working.
        """

        try:
            asgi = self.replay_app()
            add_route = getattr(app, "add_route", None)
            if callable(add_route):
                add_route(path, asgi, methods=["POST"])
            else:
                mount = getattr(app, "mount", None)
                if callable(mount):
                    mount(path, asgi)
        except Exception as exc:  # noqa: BLE001 - fail open
            self.status.reason = "replay_route_not_installed"
            self.status.error_type = type(exc).__name__
        try:
            self._install_shutdown(app)
        except Exception as exc:  # noqa: BLE001 - fail open
            self.status.error_type = type(exc).__name__
        return self

    def _install_shutdown(self, app: Any) -> None:
        router = getattr(app, "router", None)
        existing = getattr(router, "lifespan_context", None)
        if router is not None and callable(existing):
            integration = self

            @asynccontextmanager
            async def lifespan(application):
                async with existing(application) as state:
                    try:
                        yield state
                    finally:
                        integration.close()

            router.lifespan_context = lifespan
            return
        add_event_handler = getattr(app, "add_event_handler", None)
        if callable(add_event_handler):
            add_event_handler("shutdown", self.close)

    def handoff(self, value: Any, **kwargs: Any) -> Any:
        """Optionally annotate durable lineage while preserving the value."""

        if self.shelf is None:
            return value
        try:
            return self.shelf.handoff(value, **kwargs)
        except Exception:
            return value

    def tool(
        self,
        func: Optional[Callable[..., Any]] = None,
        *,
        name: Optional[str] = None,
        description: Optional[str] = None,
        stage: Optional[str] = None,
    ):
        """Instrument an ordinary callable as a generic tool.

        Supports both direct wrapping (``integration.tool(fn)``) and decorator
        forms (``@integration.tool`` or ``@integration.tool(name="search")``).
        Inactive integrations return the original function unchanged.
        """

        def decorate(candidate: Callable[..., Any]) -> Callable[..., Any]:
            if self.shelf is None:
                return candidate
            return wrap_tool(
                self.shelf,
                candidate,
                name=name,
                description=description,
                stage=stage,
            )

        if func is None:
            return decorate
        return decorate(func)

    def tools(self, tools: Any, *, stage: Optional[str] = None) -> Any:
        """Wrap a list, tuple, or mapping registry of callables once."""

        if self.shelf is None:
            return tools
        return wrap_tools(self.shelf, tools, stage=stage)

    @contextmanager
    def _safe_execution(self):
        if self.shelf is None:
            yield
            return
        try:
            scope = self.shelf.execution()
            scope.__enter__()
        except Exception:
            yield
            return
        try:
            yield
        except BaseException as exc:
            try:
                scope.__exit__(type(exc), exc, exc.__traceback__)
            except Exception:
                pass
            raise
        else:
            try:
                scope.__exit__(None, None, None)
            except Exception:
                pass

    def run(self, callback: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Run a workflow under one trace identity when ShelfAI is active."""

        with self._safe_execution():
            return callback(*args, **kwargs)

    async def run_async(self, callback: Callable[..., Any], *args: Any, **kwargs: Any) -> Any:
        """Async-aware counterpart to :meth:`run`."""

        with self._safe_execution():
            result = callback(*args, **kwargs)
            if inspect.isawaitable(result):
                return await result
            return result

    def deactivate(self, reason: str, error: Optional[BaseException] = None) -> None:
        """Safely disable a failed adapter without exposing exception details."""

        shelf = self.shelf
        self.shelf = None
        if self._finalizer is not None and self._finalizer.alive:
            self._finalizer.detach()
        if shelf is not None:
            _close_safely(shelf)
        self._closed = True
        self.status.active = False
        self.status.wrapped = False
        self.status.reason = str(reason)
        self.status.error_type = type(error).__name__ if error is not None else None

    def close(self) -> None:
        """Flush and close telemetry without affecting application shutdown."""

        if self._closed:
            return
        self._closed = True
        if self.shelf is None:
            return
        if self._finalizer is not None and self._finalizer.alive:
            self._finalizer.detach()
        try:
            self.shelf.close()
        except Exception as exc:
            self.status.active = False
            self.status.reason = "close_failed"
            self.status.error_type = type(exc).__name__

    def __enter__(self) -> "ShelfAIIntegration":
        return self

    def __exit__(self, _exc_type, _exc, _tb) -> None:
        self.close()

    async def __aenter__(self) -> "ShelfAIIntegration":
        return self

    async def __aexit__(self, _exc_type, _exc, _tb) -> None:
        self.close()


def _requested(enabled: Optional[bool], *, configured_credentials: bool = False) -> bool:
    if enabled is not None:
        return bool(enabled)
    configured = os.getenv("SHELFAI_ENABLED")
    if configured is not None:
        return configured.strip().lower() not in _FALSE_VALUES
    return configured_credentials or bool(os.getenv("SHELFAI_API_KEY") and os.getenv("SHELFAI_AGENT_ID"))


def _snapshot_provider_callables(client: Any, bindings: list[tuple[Any, str, Any]]) -> bool:
    """Recognize and snapshot every raw-provider entry point wrappers mutate."""

    messages = getattr(client, "messages", None)
    create = getattr(messages, "create", None)
    if callable(create):
        bindings.append((messages, "create", create))
        stream = getattr(messages, "stream", None)
        if callable(stream):
            bindings.append((messages, "stream", stream))

    chat = getattr(client, "chat", None)
    completions = getattr(chat, "completions", None) if chat is not None else None
    create = getattr(completions, "create", None)
    if callable(create):
        bindings.append((completions, "create", create))

    responses = getattr(client, "responses", None)
    create = getattr(responses, "create", None)
    if callable(create):
        bindings.append((responses, "create", create))
    return bool(bindings)


def _restore_provider_callables(bindings: list[tuple[Any, str, Any]]) -> None:
    for owner, name, original in reversed(bindings):
        try:
            setattr(owner, name, original)
        except Exception:
            pass


def integrate(
    *,
    client: Any,
    replay: Optional[Callable[..., Any]] = None,
    enabled: Optional[bool] = None,
    shelf_class: Optional[Type[Any]] = None,
    **kwargs: Any,
) -> ShelfAIIntegration:
    """Optionally wrap ``client`` while preserving it on every setup failure."""

    requested = _requested(
        enabled,
        configured_credentials=bool(kwargs.get("api_key") and kwargs.get("agent_id")),
    )
    if not requested:
        return ShelfAIIntegration(
            client=client,
            status=IntegrationStatus(False, False, False, "disabled"),
        )

    if shelf_class is None:
        from .client import ShelfAI

        shelf_class = ShelfAI

    shelf = None
    bindings: list[tuple[Any, str, Any]] = []
    try:
        supported = _snapshot_provider_callables(client, bindings)
        shelf = shelf_class(replay=replay, **kwargs)
        wrapped = shelf.wrap(client)
    except Exception as exc:
        _restore_provider_callables(bindings)
        if shelf is not None:
            _close_safely(shelf)
        return ShelfAIIntegration(
            client=client,
            status=IntegrationStatus(True, False, False, "configuration_failed", type(exc).__name__),
        )

    was_wrapped = supported or wrapped is not client
    if not was_wrapped:
        _close_safely(shelf)
        return ShelfAIIntegration(
            client=client,
            status=IntegrationStatus(True, False, False, "unsupported_client"),
        )
    return ShelfAIIntegration(
        client=wrapped,
        shelf=shelf,
        status=IntegrationStatus(True, True, True, "active"),
    )


def connect(
    *,
    replay: Optional[Callable[..., Any]] = None,
    enabled: Optional[bool] = None,
    shelf_class: Optional[Type[Any]] = None,
    **kwargs: Any,
) -> ShelfAIIntegration:
    """Create an optional ShelfAI lifecycle handle without a raw model client."""

    requested = _requested(
        enabled,
        configured_credentials=bool(kwargs.get("api_key") and kwargs.get("agent_id")),
    )
    if not requested:
        return ShelfAIIntegration(
            client=None,
            status=IntegrationStatus(False, False, False, "disabled"),
        )
    if shelf_class is None:
        from .client import ShelfAI

        shelf_class = ShelfAI
    try:
        shelf = shelf_class(replay=replay, **kwargs)
    except Exception as exc:
        return ShelfAIIntegration(
            client=None,
            status=IntegrationStatus(True, False, False, "configuration_failed", type(exc).__name__),
        )
    return ShelfAIIntegration(
        client=None,
        shelf=shelf,
        status=IntegrationStatus(True, True, False, "active"),
    )
