"""Lightweight, provider-neutral lineage annotations for dynamic context."""

from __future__ import annotations

from dataclasses import dataclass
import inspect
from pathlib import Path
from typing import Any, Callable, Optional

from .runtime_source import _project_root, _safe_relative_path, _validated_relative_path


@dataclass(frozen=True)
class ContextRef:
    """A stable reference to one captured Context IR item."""

    item_id: str
    trace_id: Optional[str] = None
    agent_id: Optional[str] = None
    stage: Optional[str] = None

    def payload(self) -> dict[str, str]:
        return {
            key: value
            for key, value in {
                "item_id": self.item_id,
                "trace_id": self.trace_id,
                "agent_id": self.agent_id,
                "stage": self.stage,
            }.items()
            if value
        }


def repository_relative_path(value: Any) -> Optional[str]:
    """Return a repository-relative locator or ``None``; never an absolute path.

    Explicit relative paths are validated as-is. Absolute paths (for example a
    file discovered through ``inspect``) are relativized against the same
    project root the runtime-source collector uses and dropped when they fall
    outside it, so a materializer never leaks the host filesystem layout.
    """

    if not isinstance(value, str) or not value.strip():
        return None
    validated = _validated_relative_path(value.strip())
    if validated is not None:
        return validated
    try:
        resolved = Path(value).expanduser().resolve()
    except (OSError, RuntimeError):
        return None
    root = _project_root(str(resolved.parent))
    if not root:
        return None
    return _safe_relative_path(resolved, Path(root))


def materializer_payload(
    materialized_by: Callable[..., Any] | str | None,
    *,
    source_path: str | None = None,
    revision: str | None = None,
) -> dict[str, Any]:
    """Describe the durable code/template that assembled a context value."""

    path = repository_relative_path(source_path) if source_path else None
    symbol: str | None = None
    if callable(materialized_by):
        symbol = getattr(materialized_by, "__qualname__", None) or getattr(materialized_by, "__name__", None)
        if path is None and not source_path:
            try:
                discovered = inspect.getsourcefile(materialized_by)
            except (OSError, TypeError):
                discovered = None
            if discovered:
                path = repository_relative_path(discovered)
    elif materialized_by:
        symbol = str(materialized_by)

    if not path and not symbol:
        return {"kind": "ephemeral"}
    return {
        key: value
        for key, value in {
            "kind": "repo_file" if source_path and path else "source_code",
            "path": path,
            "symbol": symbol,
            "revision": revision,
        }.items()
        if value
    }
