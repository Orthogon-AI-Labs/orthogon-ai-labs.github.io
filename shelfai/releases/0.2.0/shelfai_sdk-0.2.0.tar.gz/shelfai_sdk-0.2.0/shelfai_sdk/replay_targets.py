"""Safe, framework-neutral replay targets for services and batch workflows.

This module deliberately keeps workflow registration separate from replay dispatch.
Applications register a fixed callback or exact command once; Workbench dispatches an
opaque, short-lived session and never supplies executable arguments or environment.
"""

from __future__ import annotations

import asyncio
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
import hashlib
import hmac
import inspect
import json
import os
from pathlib import Path
import re
import secrets
import signal
import shutil
import threading
from typing import Any, Awaitable, Callable, Mapping, Optional, Sequence, Union


__all__ = [
    "ReplayInvocation",
    "ReplaySession",
    "ReplaySessionStore",
    "ReplayTargetError",
    "ReplayTargetRegistry",
    "ReplayTrace",
    "ReplayWorker",
]


MAX_REPLAY_REQUEST_BYTES = 64 * 1024
_TARGET_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
_ENV_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_SESSION_PREFIX = "srp_"
_SESSION_ENV = "SHELFAI_REPLAY_SESSION"
_TARGET_ENV = "SHELFAI_REPLAY_TARGET"


class ReplayTargetError(RuntimeError):
    """A secret-safe replay failure.

    ``code`` is stable for API adapters. The message intentionally never includes
    command output, environment values, tokens, or arbitrary callback exceptions.
    """

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


@dataclass(frozen=True)
class ReplaySession:
    """Server-side session state; the experiment scope never leaves this store."""

    session_id: str
    tenant_id: str
    target_name: str
    experiment_scope: str = field(repr=False)
    expires_at: datetime


@dataclass(frozen=True)
class ReplayInvocation:
    """Non-secret metadata available to a registered service callback."""

    session_id: str
    tenant_id: str
    target_name: str


@dataclass(frozen=True)
class ReplayTrace:
    """Trace identity resolved from trusted SDK/backend state after a replay."""

    trace_id: str
    replay_session_id: str
    tenant_id: str
    target_name: str
    sdk_captured: bool
    persisted: bool
    offline: bool = False


class ReplaySessionStore:
    """Backend-side, single-use store for signed opaque replay sessions.

    This store belongs beside trusted experiment state, not in a customer worker.
    A worker reaches it through an authenticated resolver transport. Tokens are
    authenticated and stored by digest, so neither the experiment scope nor token
    is persisted in plaintext outside the issuing backend process.
    """

    def __init__(
        self,
        *,
        signing_secret: str,
        max_ttl_seconds: int = 300,
        now: Optional[Callable[[], datetime]] = None,
    ) -> None:
        if len(signing_secret) < 16:
            raise ValueError("Replay session signing secret must contain at least 16 characters.")
        if max_ttl_seconds < 1 or max_ttl_seconds > 900:
            raise ValueError("Replay session TTL must be between 1 and 900 seconds.")
        self._secret = signing_secret.encode("utf-8")
        self._max_ttl_seconds = max_ttl_seconds
        self._now = now or (lambda: datetime.now(timezone.utc))
        self._sessions: dict[str, ReplaySession] = {}
        self._active_sessions: dict[str, ReplaySession] = {}
        self._lock = threading.Lock()

    def issue(
        self,
        *,
        tenant_id: str,
        target_name: str,
        experiment_scope: str,
        ttl_seconds: Optional[int] = None,
    ) -> str:
        tenant = _required_text(tenant_id, "tenant_id")
        target = _valid_target_name(target_name)
        scope = _required_text(experiment_scope, "experiment_scope")
        ttl = self._max_ttl_seconds if ttl_seconds is None else int(ttl_seconds)
        if ttl < 1 or ttl > self._max_ttl_seconds:
            raise ValueError("Replay session TTL exceeds the configured limit.")

        nonce = secrets.token_urlsafe(32)
        signature = hmac.new(self._secret, nonce.encode("ascii"), hashlib.sha256).hexdigest()
        token = f"{_SESSION_PREFIX}{nonce}.{signature}"
        session = ReplaySession(
            session_id=f"rps_{secrets.token_hex(12)}",
            tenant_id=tenant,
            target_name=target,
            experiment_scope=scope,
            expires_at=self._now() + timedelta(seconds=ttl),
        )
        with self._lock:
            self._discard_expired_locked()
            self._sessions[self._token_digest(token)] = session
        return token

    def activate(self, token: str, *, tenant_id: str, target_name: str) -> ReplaySession:
        """Atomically activate a single-use session for a remote worker."""

        self._verify_token(token)
        tenant = _required_text(tenant_id, "tenant_id")
        target = _valid_target_name(target_name)
        with self._lock:
            self._discard_expired_locked()
            digest = self._token_digest(token)
            session = self._sessions.get(digest)
            if session is None:
                raise ReplayTargetError("invalid_replay_session")
            if session.tenant_id != tenant:
                raise ReplayTargetError("replay_session_tenant_mismatch")
            if session.target_name != target:
                raise ReplayTargetError("replay_session_target_mismatch")
            self._sessions.pop(digest, None)
            self._active_sessions[digest] = session
        return session

    def consume(self, token: str, *, tenant_id: str, target_name: str) -> ReplaySession:
        """Backward-compatible alias for backend adapters using consume semantics."""

        return self.activate(token, tenant_id=tenant_id, target_name=target_name)

    def resolve_active(
        self,
        token: str,
        *,
        tenant_id: str,
        target_name: str,
    ) -> ReplaySession:
        """Resolve scope for SDK internals while the registered target is running."""

        self._verify_token(token)
        tenant = _required_text(tenant_id, "tenant_id")
        target = _valid_target_name(target_name)
        with self._lock:
            self._discard_expired_locked()
            session = self._active_sessions.get(self._token_digest(token))
        if session is None:
            raise ReplayTargetError("invalid_replay_session")
        if session.tenant_id != tenant:
            raise ReplayTargetError("replay_session_tenant_mismatch")
        if session.target_name != target:
            raise ReplayTargetError("replay_session_target_mismatch")
        return session

    def complete_session(self, session_id: str) -> None:
        """Revoke an active session by its non-secret identity."""

        with self._lock:
            matching = [
                digest
                for digest, session in self._active_sessions.items()
                if session.session_id == session_id
            ]
            for digest in matching:
                self._active_sessions.pop(digest, None)

    def _verify_token(self, token: str) -> None:
        if not isinstance(token, str) or not token.startswith(_SESSION_PREFIX):
            raise ReplayTargetError("invalid_replay_session")
        try:
            nonce, supplied = token[len(_SESSION_PREFIX) :].rsplit(".", 1)
        except ValueError as exc:
            raise ReplayTargetError("invalid_replay_session") from exc
        try:
            expected = hmac.new(self._secret, nonce.encode("ascii"), hashlib.sha256).hexdigest()
        except UnicodeEncodeError as exc:
            raise ReplayTargetError("invalid_replay_session") from exc
        if not nonce or not hmac.compare_digest(supplied, expected):
            raise ReplayTargetError("invalid_replay_session")

    def _token_digest(self, token: str) -> str:
        return hmac.new(self._secret, token.encode("utf-8"), hashlib.sha256).hexdigest()

    def _discard_expired_locked(self) -> None:
        now = self._now()
        expired = [key for key, session in self._sessions.items() if session.expires_at <= now]
        for key in expired:
            self._sessions.pop(key, None)
        active_expired = [key for key, session in self._active_sessions.items() if session.expires_at <= now]
        for key in active_expired:
            self._active_sessions.pop(key, None)


@dataclass
class _Target:
    name: str
    kind: str
    timeout_seconds: float
    concurrency_limit: int
    callback: Optional[Callable[..., Any]] = None
    argv: tuple[str, ...] = ()
    cwd: Optional[Path] = None
    env_allowlist: tuple[str, ...] = ()
    output_limit_bytes: int = 64 * 1024
    running: int = 0
    lock: threading.Lock = field(default_factory=threading.Lock, repr=False)

    def enter(self) -> None:
        with self.lock:
            if self.running >= self.concurrency_limit:
                raise ReplayTargetError("replay_concurrency_exceeded")
            self.running += 1

    def leave(self) -> None:
        with self.lock:
            self.running = max(0, self.running - 1)


class ReplayTargetRegistry:
    """Registry of explicitly authorized replay workflows."""

    def __init__(self, *, repo_root: str | os.PathLike[str]) -> None:
        root = Path(repo_root).expanduser().resolve(strict=True)
        if not root.is_dir():
            raise ValueError("Replay repository root must be a directory.")
        self.repo_root = root
        self._targets: dict[str, _Target] = {}
        self._lock = threading.Lock()

    def register_callback(
        self,
        name: str,
        callback: Callable[..., Any],
        *,
        timeout_seconds: float = 60.0,
        concurrency_limit: int = 1,
    ) -> None:
        if not callable(callback):
            raise TypeError("Replay callback must be callable.")
        self._register(
            _Target(
                name=_valid_target_name(name),
                kind="callback",
                callback=callback,
                timeout_seconds=_positive_timeout(timeout_seconds),
                concurrency_limit=_positive_limit(concurrency_limit, "concurrency_limit"),
            )
        )

    def register_command(
        self,
        name: str,
        argv: Sequence[str],
        *,
        cwd: str | os.PathLike[str] = ".",
        env_allowlist: Sequence[str] = (),
        timeout_seconds: float = 300.0,
        concurrency_limit: int = 1,
        output_limit_bytes: int = 64 * 1024,
    ) -> None:
        if isinstance(argv, (str, bytes)) or not argv:
            raise ValueError("Replay command must be a non-empty argument array.")
        args = tuple(str(value) for value in argv)
        if any(not value or "\x00" in value for value in args):
            raise ValueError("Replay command arguments must be non-empty and contain no NUL bytes.")
        executable = shutil.which(args[0])
        if executable is None:
            raise ValueError("Replay command executable was not found.")
        resolved_cwd = (self.repo_root / Path(cwd)).resolve(strict=True)
        try:
            resolved_cwd.relative_to(self.repo_root)
        except ValueError as exc:
            raise ValueError("Replay command cwd must remain inside the configured repository root.") from exc
        if not resolved_cwd.is_dir():
            raise ValueError("Replay command cwd must be a directory.")

        allowed: list[str] = []
        for name_value in env_allowlist:
            env_name = str(name_value)
            if not _ENV_NAME.fullmatch(env_name):
                raise ValueError("Replay environment allowlist contains an invalid name.")
            if env_name in {_SESSION_ENV, _TARGET_ENV}:
                raise ValueError("Replay internal environment names cannot be allowlisted.")
            if env_name not in allowed:
                allowed.append(env_name)

        self._register(
            _Target(
                name=_valid_target_name(name),
                kind="command",
                argv=(str(Path(executable).resolve()), *args[1:]),
                cwd=resolved_cwd,
                env_allowlist=tuple(allowed),
                timeout_seconds=_positive_timeout(timeout_seconds),
                concurrency_limit=_positive_limit(concurrency_limit, "concurrency_limit"),
                output_limit_bytes=_positive_limit(output_limit_bytes, "output_limit_bytes"),
            )
        )

    def get(self, name: str) -> _Target:
        target = self._targets.get(str(name))
        if target is None:
            raise ReplayTargetError("unknown_replay_target")
        return target

    def _register(self, target: _Target) -> None:
        with self._lock:
            if target.name in self._targets:
                raise ValueError("Replay target is already registered.")
            self._targets[target.name] = target


SessionResolver = Callable[[str, str, str], Union[ReplaySession, Awaitable[ReplaySession]]]
SessionCompleter = Callable[[str, bool], Any]
TraceResolver = Callable[[ReplaySession], Union[ReplayTrace, Awaitable[ReplayTrace]]]
ActivateScope = Callable[[str, Callable[[], Any]], Any]


class ReplayWorker:
    """Dispatch opaque replay sessions to pre-registered workflows.

    ``resolve_session`` and ``complete_session`` are trusted transport seams to
    the issuing ShelfAI backend. ``resolve_trace`` must read persisted telemetry,
    never command output or a customer-provided trace identifier.
    """

    def __init__(
        self,
        *,
        tenant_id: Optional[str] = None,
        signing_secret: str,
        registry: ReplayTargetRegistry,
        resolve_session: SessionResolver,
        complete_session: SessionCompleter,
        activate_scope: ActivateScope,
        resolve_trace: TraceResolver,
        max_request_age_seconds: int = 300,
    ) -> None:
        if len(signing_secret) < 16:
            raise ValueError("Replay request signing secret must contain at least 16 characters.")
        self.tenant_id = _required_text(tenant_id, "tenant_id") if tenant_id is not None else None
        self._signing_secret = signing_secret.encode("utf-8")
        self.registry = registry
        self.resolve_session = resolve_session
        self.complete_session = complete_session
        self.activate_scope = activate_scope
        self.resolve_trace = resolve_trace
        self.max_request_age_seconds = _positive_limit(max_request_age_seconds, "max_request_age_seconds")

    async def dispatch(
        self,
        *,
        replay_session: str,
        target_name: str,
        tenant_id: Optional[str] = None,
    ) -> dict[str, str]:
        target = self.registry.get(target_name)
        resolved_tenant = self._tenant_for_dispatch(tenant_id)
        try:
            if inspect.iscoroutinefunction(self.resolve_session):
                pending_session = self.resolve_session(replay_session, resolved_tenant, target.name)
            else:
                pending_session = asyncio.to_thread(
                    self.resolve_session,
                    replay_session,
                    resolved_tenant,
                    target.name,
                )
            if inspect.isawaitable(pending_session):
                session = await pending_session
            else:
                session = pending_session
        except ReplayTargetError:
            raise
        except Exception as exc:
            raise ReplayTargetError("invalid_replay_session") from exc
        self._verify_session(session, tenant_id=resolved_tenant, target_name=target.name)
        entered = False
        succeeded = False
        try:
            target.enter()
            entered = True
            invocation = ReplayInvocation(session.session_id, session.tenant_id, session.target_name)
            executed = False

            async def execute() -> None:
                nonlocal executed
                executed = True
                if target.kind == "command":
                    await self._run_command(target, replay_session)
                else:
                    await self._run_callback(target, invocation)

            try:
                if target.kind == "command":
                    # A child process cannot inherit Python ContextVars. It receives only
                    # the opaque session; its SDK resolves experiment scope internally.
                    await asyncio.wait_for(execute(), timeout=target.timeout_seconds)
                else:
                    activated = self.activate_scope(session.experiment_scope, execute)
                    if inspect.isawaitable(activated):
                        await asyncio.wait_for(activated, timeout=target.timeout_seconds)
                    elif not executed:
                        raise ReplayTargetError("replay_execution_failed")
            except asyncio.TimeoutError as exc:
                raise ReplayTargetError("replay_timeout") from exc
            except ReplayTargetError:
                raise
            except Exception as exc:
                raise ReplayTargetError("replay_execution_failed") from exc

            try:
                if inspect.iscoroutinefunction(self.resolve_trace):
                    pending_trace = self.resolve_trace(session)
                else:
                    pending_trace = asyncio.to_thread(self.resolve_trace, session)
                trace = await asyncio.wait_for(pending_trace, timeout=target.timeout_seconds)
                if inspect.isawaitable(trace):
                    trace = await asyncio.wait_for(trace, timeout=target.timeout_seconds)
            except asyncio.TimeoutError as exc:
                raise ReplayTargetError("replay_timeout") from exc
            except Exception as exc:
                raise ReplayTargetError("replay_trace_missing") from exc
            self._verify_trace(trace, session)
            succeeded = True
            return {"replay_trace_id": trace.trace_id}
        finally:
            if entered:
                target.leave()
            try:
                if inspect.iscoroutinefunction(self.complete_session):
                    completed = self.complete_session(session.session_id, succeeded)
                else:
                    completed = asyncio.to_thread(
                        self.complete_session,
                        session.session_id,
                        succeeded,
                    )
                if inspect.isawaitable(completed):
                    await completed
            except Exception as exc:
                raise ReplayTargetError("replay_session_completion_failed") from exc

    async def _run_callback(self, target: _Target, invocation: ReplayInvocation) -> None:
        callback = target.callback
        if callback is None:
            raise ReplayTargetError("replay_execution_failed")
        try:
            signature = inspect.signature(callback)
            takes_argument = any(
                parameter.kind in (parameter.POSITIONAL_ONLY, parameter.POSITIONAL_OR_KEYWORD)
                for parameter in signature.parameters.values()
            )
        except (TypeError, ValueError):
            takes_argument = True
        if inspect.iscoroutinefunction(callback):
            result = callback(invocation) if takes_argument else callback()
            await result
        else:
            if takes_argument:
                result = await asyncio.to_thread(callback, invocation)
            else:
                result = await asyncio.to_thread(callback)
            if inspect.isawaitable(result):
                await result

    async def _run_command(self, target: _Target, replay_session: str) -> None:
        env = {
            name: os.environ[name]
            for name in target.env_allowlist
            if name in os.environ
        }
        env[_SESSION_ENV] = replay_session
        env[_TARGET_ENV] = target.name
        try:
            process = await asyncio.create_subprocess_exec(
                *target.argv,
                cwd=str(target.cwd),
                env=env,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                start_new_session=True,
            )
        except Exception as exc:
            raise ReplayTargetError("replay_execution_failed") from exc

        total = 0

        async def drain(stream: Optional[asyncio.StreamReader]) -> None:
            nonlocal total
            if stream is None:
                return
            while True:
                chunk = await stream.read(8192)
                if not chunk:
                    return
                total += len(chunk)
                if total > target.output_limit_bytes:
                    raise ReplayTargetError("replay_output_limit_exceeded")

        try:
            await asyncio.gather(drain(process.stdout), drain(process.stderr), process.wait())
        except BaseException:
            if process.returncode is None:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except (AttributeError, OSError):
                    process.kill()
                await process.wait()
            raise
        if process.returncode != 0:
            raise ReplayTargetError("replay_nonzero_exit")

    @staticmethod
    def _verify_session(session: Any, *, tenant_id: str, target_name: str) -> None:
        if not isinstance(session, ReplaySession):
            raise ReplayTargetError("invalid_replay_session")
        if session.tenant_id != tenant_id:
            raise ReplayTargetError("replay_session_tenant_mismatch")
        if session.target_name != target_name:
            raise ReplayTargetError("replay_session_target_mismatch")
        if session.expires_at <= datetime.now(timezone.utc):
            raise ReplayTargetError("invalid_replay_session")

    @staticmethod
    def _verify_trace(trace: Any, session: ReplaySession) -> None:
        if not isinstance(trace, ReplayTrace) or not trace.trace_id.strip():
            raise ReplayTargetError("replay_trace_missing")
        if trace.replay_session_id != session.session_id:
            raise ReplayTargetError("replay_trace_session_mismatch")
        if trace.tenant_id != session.tenant_id:
            raise ReplayTargetError("replay_trace_tenant_mismatch")
        if trace.target_name != session.target_name:
            raise ReplayTargetError("replay_trace_target_mismatch")
        if not trace.sdk_captured or not trace.persisted:
            raise ReplayTargetError("replay_trace_unverified")
        if trace.offline:
            raise ReplayTargetError("replay_trace_offline")

    def asgi(self, *, path: str = "/"):
        """Return an exact-path ASGI endpoint; it never redirects requests."""

        expected_path = path or "/"
        worker = self

        async def app(scope, receive, send):
            if scope.get("type") != "http" or scope.get("method") != "POST":
                await _asgi_json(send, 405, {"error": "method_not_allowed"})
                return
            if scope.get("path", "/") != expected_path:
                await _asgi_json(send, 404, {"error": "replay_path_not_found"})
                return
            headers = {
                key.decode("latin-1"): value.decode("latin-1")
                for key, value in scope.get("headers", [])
            }
            try:
                raw = await _read_asgi_body(receive, headers)
                if raw is None:
                    await _asgi_json(send, 413, {"error": "replay_request_too_large"})
                    return
                payload = worker._verify_request(raw, headers)
                result = await worker.dispatch(
                    replay_session=payload["replay_session"],
                    target_name=payload["target_name"],
                    tenant_id=payload["tenant_id"],
                )
            except ReplayTargetError as exc:
                status = {
                    "invalid_replay_signature": 401,
                    "invalid_replay_request": 401,
                    "invalid_replay_session": 401,
                    "replay_session_tenant_mismatch": 401,
                    "replay_session_target_mismatch": 401,
                    "unknown_replay_target": 404,
                    "replay_concurrency_exceeded": 409,
                    "replay_timeout": 504,
                }.get(exc.code, 422)
                await _asgi_json(send, status, {"error": exc.code})
                return
            except Exception:
                await _asgi_json(send, 500, {"error": "replay_failed"})
                return
            await _asgi_json(send, 200, result)

        return app

    def _verify_request(self, raw: bytes, headers: Mapping[str, str]) -> dict[str, str]:
        supplied = _header(headers, "X-ShelfAI-Signature")
        if supplied.startswith("sha256="):
            supplied = supplied[len("sha256=") :]
        expected = hmac.new(self._signing_secret, raw, hashlib.sha256).hexdigest()
        try:
            matches = bool(supplied) and hmac.compare_digest(supplied, expected)
        except (TypeError, ValueError):
            matches = False
        if not matches:
            raise ReplayTargetError("invalid_replay_signature")
        try:
            payload = json.loads(raw)
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise ReplayTargetError("invalid_replay_request") from exc
        if not isinstance(payload, dict):
            raise ReplayTargetError("invalid_replay_request")
        if payload.get("version") != "1.0" or payload.get("event") != "replay.session.dispatch":
            raise ReplayTargetError("invalid_replay_request")
        tenant_id = str(payload.get("tenant_id") or "").strip()
        if not tenant_id:
            raise ReplayTargetError("invalid_replay_request")
        if self.tenant_id is not None and tenant_id != self.tenant_id:
            raise ReplayTargetError("invalid_replay_request")
        requested_at = str(payload.get("requested_at") or "")
        try:
            parsed = datetime.fromisoformat(requested_at.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
        except ValueError as exc:
            raise ReplayTargetError("invalid_replay_request") from exc
        age = abs((datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds())
        if age > self.max_request_age_seconds:
            raise ReplayTargetError("invalid_replay_request")
        replay_session = str(payload.get("replay_session") or "")
        target_name = str(payload.get("target_name") or "")
        if not replay_session or not target_name:
            raise ReplayTargetError("invalid_replay_request")
        return {"replay_session": replay_session, "target_name": target_name, "tenant_id": tenant_id}

    def _tenant_for_dispatch(self, tenant_id: Optional[str]) -> str:
        supplied = _required_text(tenant_id, "tenant_id") if tenant_id is not None else None
        if self.tenant_id is not None:
            if supplied is not None and supplied != self.tenant_id:
                raise ReplayTargetError("replay_session_tenant_mismatch")
            return self.tenant_id
        if supplied is None:
            raise ReplayTargetError("invalid_replay_request")
        return supplied


def _required_text(value: Any, name: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise ValueError(f"{name} must not be empty.")
    return text


def _valid_target_name(value: Any) -> str:
    name = _required_text(value, "target_name")
    if not _TARGET_NAME.fullmatch(name):
        raise ValueError("Replay target name contains unsupported characters.")
    return name


def _positive_limit(value: Any, name: str) -> int:
    resolved = int(value)
    if resolved < 1:
        raise ValueError(f"{name} must be positive.")
    return resolved


def _positive_timeout(value: Any) -> float:
    resolved = float(value)
    if resolved <= 0:
        raise ValueError("timeout_seconds must be positive.")
    return resolved


def _header(headers: Mapping[str, Any], name: str) -> str:
    expected = name.lower()
    for key, value in headers.items():
        if str(key).lower() == expected:
            return str(value or "")
    return ""


async def _read_asgi_body(receive, headers: Mapping[str, str]) -> Optional[bytes]:
    content_length = _header(headers, "content-length")
    try:
        if content_length and int(content_length) > MAX_REPLAY_REQUEST_BYTES:
            return None
    except ValueError:
        pass
    chunks: list[bytes] = []
    total = 0
    while True:
        message = await receive()
        if message.get("type") == "http.disconnect":
            raise ReplayTargetError("invalid_replay_request")
        chunk = bytes(message.get("body", b""))
        total += len(chunk)
        if total > MAX_REPLAY_REQUEST_BYTES:
            return None
        chunks.append(chunk)
        if not message.get("more_body", False):
            return b"".join(chunks)


async def _asgi_json(send, status: int, payload: Mapping[str, Any]) -> None:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode("ascii")),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})
