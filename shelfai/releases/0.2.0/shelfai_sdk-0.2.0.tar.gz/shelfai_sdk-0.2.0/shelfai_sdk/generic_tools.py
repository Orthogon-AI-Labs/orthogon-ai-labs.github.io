"""Framework-neutral instrumentation for ordinary Python tool callables."""

from __future__ import annotations

from collections.abc import Mapping
from contextlib import contextmanager
from contextvars import ContextVar
from functools import wraps
import inspect
import os
from pathlib import Path
from typing import Any, Callable, Optional

from ._guard import telemetry_guard
from .context_ir import ContextIR, context_item
from .runtime_source import attach_runtime_source_evidence, capture_runtime_source_evidence
from .utils import generate_id


_WRAPPED_TOOL_MARKER = "__shelfai_tool_original__"
_ToolParentEntry = tuple[int, str]
_TOOL_PARENT_STACK: ContextVar[tuple[_ToolParentEntry, ...]] = ContextVar("shelfai_tool_parent_stack", default=())


def wrap_tool(
    shelf: Any,
    func: Callable[..., Any],
    *,
    name: Optional[str] = None,
    description: Optional[str] = None,
    stage: Optional[str] = None,
) -> Callable[..., Any]:
    """Return a fail-open wrapper for one ordinary callable."""

    original = getattr(func, _WRAPPED_TOOL_MARKER, func)
    if getattr(func, _WRAPPED_TOOL_MARKER, None) is not None:
        return func
    tool_name = _safe_tool_name(func, name)
    doc = description if description is not None else inspect.getdoc(func)
    signature = telemetry_guard("tool_signature", inspect.signature, func)

    def begin(args: tuple[Any, ...], kwargs: dict[str, Any]) -> tuple[str, str | None]:
        call_id = generate_id("tool_call")
        runtime_source = _runtime_source_for_tool(shelf)

        def _capture() -> str | None:
            trace_id = getattr(shelf, "current_trace_id", lambda: None)()
            if not trace_id:
                return None
            _definition_id, call_item_id = _emit_tool_start(
                shelf,
                trace_id=trace_id,
                stage=stage,
                func=original,
                tool_name=tool_name,
                description=doc,
                call_id=call_id,
                args=args,
                kwargs=kwargs,
                runtime_source=runtime_source,
            )
            return call_item_id

        call_item_id = telemetry_guard("tool_capture_start", _capture)
        return call_id, call_item_id

    def finish(call_id: str, call_item_id: str | None, *, result: Any = None, exc: BaseException | None = None) -> None:
        runtime_source = _runtime_source_for_tool(shelf)

        def _capture() -> None:
            trace_id = getattr(shelf, "current_trace_id", lambda: None)()
            if not trace_id:
                return
            _emit_tool_end(
                shelf,
                trace_id=trace_id,
                stage=stage,
                tool_name=tool_name,
                call_id=call_id,
                call_item_id=call_item_id,
                result=result,
                exc=exc,
                runtime_source=runtime_source,
            )

        telemetry_guard("tool_capture_result", _capture)

    if inspect.iscoroutinefunction(func):

        @wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            with _tool_execution(shelf):
                call_id, call_item_id = begin(args, kwargs)
                stack_token = _push_parent_item_for_shelf(shelf, call_item_id)
                try:
                    result = await func(*args, **kwargs)
                except BaseException as exc:
                    finish(call_id, call_item_id, exc=exc)
                    raise
                finally:
                    _TOOL_PARENT_STACK.reset(stack_token)
                finish(call_id, call_item_id, result=result)
                return result

        wrapper: Callable[..., Any] = async_wrapper
    else:

        @wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            with _tool_execution(shelf):
                call_id, call_item_id = begin(args, kwargs)
                stack_token = _push_parent_item_for_shelf(shelf, call_item_id)
                try:
                    result = func(*args, **kwargs)
                except BaseException as exc:
                    finish(call_id, call_item_id, exc=exc)
                    raise
                finally:
                    _TOOL_PARENT_STACK.reset(stack_token)
                finish(call_id, call_item_id, result=result)
                return result

        wrapper = sync_wrapper

    if signature is not None:
        try:
            setattr(wrapper, "__signature__", signature)
        except Exception:
            pass
    try:
        setattr(wrapper, _WRAPPED_TOOL_MARKER, original)
    except Exception:
        pass
    return wrapper


def wrap_tools(shelf: Any, tools: Any, *, stage: Optional[str] = None) -> Any:
    """Wrap a list, tuple, or mapping registry of callables once."""

    if isinstance(tools, list):
        return [wrap_tool(shelf, item, stage=stage) if callable(item) else item for item in tools]
    if isinstance(tools, tuple):
        return tuple(wrap_tool(shelf, item, stage=stage) if callable(item) else item for item in tools)
    if isinstance(tools, Mapping):
        try:
            return type(tools)(
                (key, wrap_tool(shelf, item, name=str(key), stage=stage) if callable(item) else item)
                for key, item in tools.items()
            )
        except Exception:
            return {
                key: wrap_tool(shelf, item, name=str(key), stage=stage) if callable(item) else item
                for key, item in tools.items()
            }
    return tools


def _safe_tool_name(func: Callable[..., Any], explicit: Optional[str]) -> str:
    raw = explicit or getattr(func, "__name__", None) or "tool"
    value = "".join(character if character.isalnum() or character in {"_", ".", "-"} else "_" for character in str(raw))
    return value[:128] or "tool"


def _safe_tool_value(value: Any, _seen: set[int] | None = None, _depth: int = 0) -> Any:
    """Convert tool args/results without serializing callables or path strings."""

    if isinstance(value, str) and _looks_like_path_string(value):
        return {"type": "path"}
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if callable(value):
        return {"type": "callable"}
    if isinstance(value, (Path, os.PathLike)):
        return {"type": "path"}
    if _depth > 64:
        return "<max-depth>"
    seen = _seen if _seen is not None else set()
    marker = id(value)
    if marker in seen:
        return "<cycle>"
    seen.add(marker)
    try:
        if isinstance(value, dict):
            return {str(key): _safe_tool_value(item, seen, _depth + 1) for key, item in value.items()}
        if isinstance(value, (list, tuple, set)):
            return [_safe_tool_value(item, seen, _depth + 1) for item in value]
        model_dump = getattr(value, "model_dump", None)
        if callable(model_dump):
            return _safe_tool_value(model_dump(mode="json"), seen, _depth + 1)
        to_dict = getattr(value, "to_dict", None)
        if callable(to_dict):
            return _safe_tool_value(to_dict(), seen, _depth + 1)
        return {"type": type(value).__name__}
    finally:
        seen.discard(marker)


def _looks_like_path_string(value: str) -> bool:
    stripped = value.strip()
    if not stripped:
        return False
    if stripped.startswith(("/", "~", "file://")):
        return True
    if len(stripped) > 2 and stripped[1] == ":" and stripped[0].isalpha() and stripped[2] in {"/", "\\"}:
        return True
    return False


def _safe_signature_schema(func: Callable[..., Any]) -> dict[str, Any]:
    try:
        signature = inspect.signature(func)
    except (TypeError, ValueError):
        return {"parameters": []}
    parameters = []
    for parameter in signature.parameters.values():
        parameters.append(
            {
                "name": parameter.name,
                "kind": str(parameter.kind),
                "required": parameter.default is inspect._empty,
                "default_present": parameter.default is not inspect._empty,
                "annotation_present": parameter.annotation is not inspect._empty,
            }
        )
    return {
        "parameters": parameters,
        "return_annotation_present": signature.return_annotation is not inspect._empty,
    }


def _tool_definition_payload(
    func: Callable[..., Any],
    *,
    tool_name: str,
    description: Optional[str],
) -> dict[str, Any]:
    return {
        "type": "function",
        "function": {
            "name": tool_name,
            **({"description": description} if description else {}),
            "parameters": _safe_signature_schema(func),
        },
    }


def _tool_call_payload(
    *,
    tool_name: str,
    call_id: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
) -> dict[str, Any]:
    return {
        "type": "function_call",
        "name": tool_name,
        "call_id": call_id,
        "arguments": {
            "args": _safe_tool_value(args),
            "kwargs": _safe_tool_value(kwargs),
        },
    }


def _tool_result_payload(
    *,
    tool_name: str,
    call_id: str,
    result: Any = None,
    exc: Optional[BaseException] = None,
) -> dict[str, Any]:
    if exc is not None:
        return {
            "type": "function_call_output",
            "name": tool_name,
            "call_id": call_id,
            "status": "error",
            "error_type": type(exc).__name__,
        }
    return {
        "type": "function_call_output",
        "name": tool_name,
        "call_id": call_id,
        "status": "success",
        "result": _safe_tool_value(result),
    }


def _runtime_source_for_tool(shelf: Any) -> dict[str, Any] | None:
    return capture_runtime_source_evidence(enabled=getattr(shelf, "runtime_source_evidence", True))


def _shelf_identity(shelf: Any) -> int:
    return id(shelf)


def _parent_item_ids_for_shelf(shelf: Any) -> list[str]:
    identity = _shelf_identity(shelf)
    return [item_id for shelf_id, item_id in _TOOL_PARENT_STACK.get() if shelf_id == identity]


def _push_parent_item_for_shelf(shelf: Any, item_id: str | None):
    if not item_id:
        return _TOOL_PARENT_STACK.set(_TOOL_PARENT_STACK.get())
    return _TOOL_PARENT_STACK.set((*_TOOL_PARENT_STACK.get(), (_shelf_identity(shelf), item_id)))


@contextmanager
def _tool_execution(shelf: Any):
    try:
        scope = shelf.execution()
        scope.__enter__()
    except Exception:
        yield
        return
    try:
        yield
    except BaseException as exc:
        try:
            scope.__exit__(type(exc), exc, exc.__traceback__)
        except Exception:
            pass
        raise
    else:
        try:
            scope.__exit__(None, None, None)
        except Exception:
            pass


def _emit_tool_start(
    shelf: Any,
    *,
    trace_id: str,
    stage: Optional[str],
    func: Callable[..., Any],
    tool_name: str,
    description: Optional[str],
    call_id: str,
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    runtime_source: dict[str, Any] | None,
) -> tuple[str | None, str | None]:
    definition = context_item(
        "tool_definition",
        _tool_definition_payload(func, tool_name=tool_name, description=description),
        ordinal=0,
        run_id=trace_id,
        stage=stage,
        source="generic.tools",
        selection="available",
        provenance={"provider": "generic", "tool_name": tool_name},
        permissions={"declared": True},
    )
    call = context_item(
        "tool_call",
        _tool_call_payload(tool_name=tool_name, call_id=call_id, args=args, kwargs=kwargs),
        ordinal=1,
        run_id=trace_id,
        stage=stage,
        source="generic.tool_call",
        parent_ids=[definition.id, *_parent_item_ids_for_shelf(shelf)],
        selection="selected",
        provenance={"provider": "generic", "tool_name": tool_name, "call_id": call_id},
        metadata={"call_id": call_id},
    )
    envelope = attach_runtime_source_evidence(ContextIR(items=[definition, call]), runtime_source)
    shelf.emit_event(
        "tool_start",
        trace_id=trace_id,
        metadata={
            "provider": "generic",
            "api": "tool",
            "task_type": "tool",
            **({"stage": stage} if stage else {}),
            "context_ir": envelope.model_dump(mode="json"),
        },
    )
    try:
        shelf.last_trace_id = trace_id
    except Exception:
        pass
    return definition.id, call.id


def _emit_tool_end(
    shelf: Any,
    *,
    trace_id: str,
    stage: Optional[str],
    tool_name: str,
    call_id: str,
    call_item_id: Optional[str],
    result: Any = None,
    exc: Optional[BaseException] = None,
    runtime_source: dict[str, Any] | None,
) -> None:
    item = context_item(
        "tool_result",
        _tool_result_payload(tool_name=tool_name, call_id=call_id, result=result, exc=exc),
        ordinal=2,
        run_id=trace_id,
        stage=stage,
        source="generic.tool_result",
        parent_ids=[call_item_id] if call_item_id else [],
        selection="produced",
        provenance={"provider": "generic", "tool_name": tool_name, "call_id": call_id},
        metadata={"call_id": call_id, "status": "error" if exc is not None else "success"},
    )
    envelope = attach_runtime_source_evidence(ContextIR(items=[item]), runtime_source)
    shelf.register_output_context(envelope)
    shelf.emit_event(
        "tool_end",
        trace_id=trace_id,
        metadata={
            "provider": "generic",
            "api": "tool",
            "task_type": "tool",
            **({"stage": stage} if stage else {}),
            "context_ir": envelope.model_dump(mode="json"),
        },
    )
    try:
        shelf.last_trace_id = trace_id
    except Exception:
        pass


__all__ = ["wrap_tool", "wrap_tools"]
