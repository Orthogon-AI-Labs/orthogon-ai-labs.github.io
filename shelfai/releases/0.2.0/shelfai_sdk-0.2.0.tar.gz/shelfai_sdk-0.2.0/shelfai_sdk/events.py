"""Structured event helpers for the ShelfAI SDK."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional

from pydantic import BaseModel, ConfigDict, Field

from .snapshot import Context


class ShelfEvent(BaseModel):
    model_config = ConfigDict(extra="allow")

    name: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    trace_id: Optional[str] = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    def payload(self) -> dict[str, Any]:
        return self.model_dump(mode="json")


def snapshot_event(context: Context) -> ShelfEvent:
    return ShelfEvent(
        name="context_snapshot",
        trace_id=context.trace_id,
        metadata={
            "snapshot": context.snapshot_payload(),
            "chunk_ids": context.chunk_ids(),
            "chunk_count": context.chunk_count,
            "message_count": context.message_count,
            "token_count": context.token_count,
            "task_type": context.metadata.get("task_type"),
        },
    )
