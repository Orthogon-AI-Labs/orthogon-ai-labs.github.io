"""SQLite-backed offline queue for the ShelfAI SDK."""

from __future__ import annotations

from dataclasses import dataclass
import logging
import os
from pathlib import Path
import sqlite3
import tempfile
import threading
from typing import Iterable, List

from .utils import ensure_dir, safe_json_dumps

logger = logging.getLogger("shelfai_sdk")


@dataclass
class QueuedEvent:
    row_id: int
    agent_id: str
    event_json: str
    attempts: int


def _fallback_queue_root() -> Path:
    try:
        owner = str(os.getuid())  # type: ignore[attr-defined]
    except AttributeError:  # pragma: no cover - Windows
        owner = os.environ.get("USERNAME", "user")
    return Path(tempfile.gettempdir()) / f"shelfai-sdk-{owner}"


class OfflineQueue:
    """Durable retry queue that degrades gracefully instead of disabling capture.

    Read-only working directories (hardened containers, ``WORKDIR`` unset so the
    process runs from ``/``) used to make the SDK constructor raise, which the
    fail-open integration turned into "capture silently off". The queue now
    falls back to the system temp directory, and finally to a non-persistent
    no-op, while the live transport keeps sending.
    """

    def __init__(self, root_path: str):
        self.available = False
        self.root: Path | None = None
        self.db_path: Path | None = None
        self.dead_letter_path: Path | None = None
        self._lock = threading.Lock()
        candidates = [Path(root_path), _fallback_queue_root() / "queue"]
        for index, candidate in enumerate(candidates):
            try:
                root = ensure_dir(candidate)
                db_path = root / "queue.db"
                self._init_schema(db_path)
            except (OSError, sqlite3.Error) as exc:
                if index == 0:
                    logger.warning(
                        "ShelfAI offline_queue_fallback (%s)",
                        type(exc).__name__,
                    )
                continue
            self.root = root
            self.db_path = db_path
            self.dead_letter_path = root / "dead_letter.log"
            self.available = True
            return
        logger.warning("ShelfAI offline_queue_unavailable (QueueUnavailable)")

    def _connect(self):
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    @staticmethod
    def _init_schema(db_path: Path) -> None:
        with sqlite3.connect(str(db_path)) as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS offline_queue (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    agent_id TEXT NOT NULL,
                    event_json TEXT NOT NULL,
                    enqueued_at TEXT DEFAULT CURRENT_TIMESTAMP,
                    attempts INTEGER DEFAULT 0,
                    last_error TEXT,
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
                """
            )

    def enqueue(self, agent_id: str, event: dict) -> None:
        if not self.available:
            return
        payload = safe_json_dumps(event)
        with self._lock, self._connect() as conn:
            conn.execute(
                "INSERT INTO offline_queue (agent_id, event_json) VALUES (?, ?)",
                (agent_id, payload),
            )

    def enqueue_many(self, agent_id: str, events: List[str], _timestamp: str) -> None:
        if not self.available:
            return
        with self._lock, self._connect() as conn:
            conn.executemany(
                "INSERT INTO offline_queue (agent_id, event_json) VALUES (?, ?)",
                [(agent_id, event) for event in events],
            )

    def load_batch(self, limit: int = 100) -> list[QueuedEvent]:
        if not self.available:
            return []
        with self._lock, self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, agent_id, event_json, attempts
                FROM offline_queue
                ORDER BY id ASC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [
            QueuedEvent(
                row_id=row["id"],
                agent_id=row["agent_id"],
                event_json=row["event_json"],
                attempts=row["attempts"],
            )
            for row in rows
        ]

    def oldest(self, limit: int = 100):
        if not self.available:
            return []
        with self._lock, self._connect() as conn:
            return conn.execute(
                """
                SELECT id, agent_id, event_json, attempts
                FROM offline_queue
                ORDER BY id ASC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()

    def mark_success(self, row_ids: Iterable[int]) -> None:
        ids = list(row_ids)
        if not ids or not self.available:
            return
        placeholders = ",".join("?" for _ in ids)
        with self._lock, self._connect() as conn:
            conn.execute(f"DELETE FROM offline_queue WHERE id IN ({placeholders})", ids)

    def mark_delivered(self, row_ids: Iterable[int]) -> None:
        self.mark_success(row_ids)

    def mark_failure(self, row_ids: Iterable[int], error: str) -> None:
        ids = list(row_ids)
        if not ids or not self.available:
            return
        placeholders = ",".join("?" for _ in ids)
        with self._lock, self._connect() as conn:
            conn.execute(
                f"""
                UPDATE offline_queue
                SET attempts = attempts + 1, last_error = ?
                WHERE id IN ({placeholders})
                """,
                [error, *ids],
            )
            rows = conn.execute(
                f"""
                SELECT id, agent_id, event_json, attempts, last_error
                FROM offline_queue
                WHERE id IN ({placeholders}) AND attempts >= 5
                """,
                ids,
            ).fetchall()
            if rows:
                with self.dead_letter_path.open("a", encoding="utf-8") as handle:
                    for row in rows:
                        handle.write(
                            safe_json_dumps(
                                {
                                    "id": row["id"],
                                    "agent_id": row["agent_id"],
                                    "event_json": row["event_json"],
                                    "attempts": row["attempts"],
                                    "last_error": row["last_error"],
                                }
                            )
                            + "\n"
                        )
                conn.execute(f"DELETE FROM offline_queue WHERE id IN ({placeholders})", ids)

    def size(self) -> int:
        if not self.available:
            return 0
        with self._lock, self._connect() as conn:
            return int(conn.execute("SELECT COUNT(*) FROM offline_queue").fetchone()[0])

    def count(self) -> int:
        return self.size()
