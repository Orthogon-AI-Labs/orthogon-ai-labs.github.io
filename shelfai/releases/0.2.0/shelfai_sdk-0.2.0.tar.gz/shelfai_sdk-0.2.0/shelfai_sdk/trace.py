"""Trace context manager for the ShelfAI SDK."""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

from .snapshot import Context


class Trace:
    def __init__(self, name: str, shelf: Any):
        self.name = name
        self.shelf = shelf
        self.id = shelf.generate_trace_id()

    def __enter__(self) -> "Trace":
        self.shelf.emit_event("trace_started", metadata={"name": self.name}, trace_id=self.id)
        return self

    def __exit__(self, exc_type, exc, _tb) -> None:
        if exc is not None:
            self.event(
                "agent_error",
                {
                    "error_type": exc.__class__.__name__,
                    "trace_name": self.name,
                },
            )
        self.shelf.emit_event("trace_finished", metadata={"name": self.name}, trace_id=self.id)
        self.shelf.unregister_trace(self.id)

    def snapshot(self, context: Union[Context, Dict[str, Any]]) -> None:
        self.shelf.snapshot(context, trace_id=self.id)

    def record_output(self, output: Any) -> None:
        self.event("trace_output", {"output": output, "trace_name": self.name})

    def event(self, name: str, metadata: Optional[Dict[str, Any]] = None) -> None:
        self.shelf.emit_event(name, metadata=metadata, trace_id=self.id)
