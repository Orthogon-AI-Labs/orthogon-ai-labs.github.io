"""Public exports for the ShelfAI Python SDK."""

from .capture_mode import DEFAULT_CAPTURE_MODE, normalize_capture_mode, sanitize_event_for_capture_mode
from .client import ExperimentReplayError, ShelfAI
from .diagnostics import (
    DiagnosticCheck,
    DiagnosticProbes,
    DiagnosticReport,
    DiagnosticStatus,
    doctor,
    read_only_backend_probes,
    verify_integration,
)
from .integration import IntegrationStatus, ShelfAIIntegration, connect, integrate
from .context_ir import CONTEXT_IR_VERSION, ContextIR, ContextIRItem
from .lineage import ContextRef
from .replay import ReplayHandler, ReplayRequest, ReplayRequestError, verify_replay_request
from .replay_targets import (
    ReplayInvocation,
    ReplaySession,
    ReplayTargetError,
    ReplayTargetRegistry,
    ReplayTrace,
    ReplayWorker,
)
from .replay_transport import ReplayBackendTransport
from .snapshot import Chunk, Context, Message

__all__ = [
    "ShelfAI",
    "ShelfAIIntegration",
    "IntegrationStatus",
    "integrate",
    "connect",
    "DiagnosticStatus",
    "DiagnosticCheck",
    "DiagnosticReport",
    "DiagnosticProbes",
    "doctor",
    "verify_integration",
    "read_only_backend_probes",
    "ExperimentReplayError",
    "Context",
    "Chunk",
    "Message",
    "ContextIR",
    "ContextIRItem",
    "ContextRef",
    "ReplayHandler",
    "ReplayRequest",
    "ReplayRequestError",
    "verify_replay_request",
    "ReplayBackendTransport",
    "ReplayInvocation",
    "ReplaySession",
    "ReplayTargetError",
    "ReplayTargetRegistry",
    "ReplayTrace",
    "ReplayWorker",
    "CONTEXT_IR_VERSION",
    "DEFAULT_CAPTURE_MODE",
    "normalize_capture_mode",
    "sanitize_event_for_capture_mode",
]
