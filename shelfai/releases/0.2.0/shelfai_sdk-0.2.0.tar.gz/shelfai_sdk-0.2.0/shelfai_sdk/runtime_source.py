"""Privacy-safe runtime callsite evidence for provider boundaries.

The collector deliberately records code metadata only.  It never reads source
lines, frame locals, arguments, environment values, or absolute paths into the
returned payload.
"""

from __future__ import annotations

from functools import lru_cache
import hashlib
import json
import os
from pathlib import Path
from pathlib import PurePosixPath
import platform
import re
import sys
import sysconfig
from typing import Any


MAX_RUNTIME_SOURCE_FRAMES = 8
MAX_SCANNED_FRAMES = 64

_FALSE_VALUES = {"0", "false", "no", "off", "disabled"}
_SHA_RE = re.compile(r"[0-9a-fA-F]{7,64}")
_SAFE_SYMBOL_RE = re.compile(r"[A-Za-z_$<][A-Za-z0-9_$.:#<>-]{0,255}")
_SAFE_RUNTIME_RE = re.compile(r"(?:CPython|PyPy|Python) [0-9]+\.[0-9]+(?:\.[0-9]+)?")
_UNSAFE_STRUCTURAL_RE = re.compile(
    r"(?:\b(?:api[_-]?key|secret|password|token)\s*[:=]|"
    r"\b(?:sk|pk|rk|api)[-_][A-Za-z0-9_-]{12,}|@|\[REDACTED_)",
    re.IGNORECASE,
)
_EXCLUDED_MODULE_PREFIXES = (
    "shelfai_sdk",
    "anthropic",
    "openai",
    "langchain",
    "langchain_core",
    "langchain_community",
    "langgraph",
    "crewai",
    "autogen",
    "llama_index",
    "llamaindex",
    "pytest",
    "_pytest",
    "pluggy",
)
_EXCLUDED_PATH_PARTS = {
    ".venv",
    "venv",
    "site-packages",
    "dist-packages",
    "node_modules",
    "__pypackages__",
}
_PROJECT_MARKERS = (
    "pyproject.toml",
    "setup.py",
    "setup.cfg",
    "requirements.txt",
    "package.json",
)


def runtime_source_enabled(value: bool | str | None = None) -> bool:
    """Resolve the opt-out switch without exposing any environment value."""

    if isinstance(value, bool):
        return value
    if value is not None:
        return str(value).strip().lower() not in _FALSE_VALUES
    return os.getenv("SHELFAI_RUNTIME_SOURCE_EVIDENCE", "1").strip().lower() not in _FALSE_VALUES


def _is_excluded_module(module_name: str) -> bool:
    return any(
        module_name == prefix or module_name.startswith(f"{prefix}.")
        for prefix in _EXCLUDED_MODULE_PREFIXES
    )


@lru_cache(maxsize=1)
def _stdlib_roots() -> tuple[Path, ...]:
    roots: list[Path] = []
    for name in ("stdlib", "platstdlib"):
        raw = sysconfig.get_path(name)
        if raw:
            try:
                roots.append(Path(raw).resolve())
            except (OSError, RuntimeError):
                continue
    return tuple(dict.fromkeys(roots))


def _is_under(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _looks_like_library_path(path: Path) -> bool:
    if any(part.lower() in _EXCLUDED_PATH_PARTS for part in path.parts):
        return True
    for root in _stdlib_roots():
        if _is_under(path, root):
            return True
    return False


@lru_cache(maxsize=512)
def _repository_root(directory: str) -> str | None:
    """Find a repository root by reading the filesystem, never invoking git."""

    try:
        current = Path(directory).resolve()
    except (OSError, RuntimeError):
        return None
    for candidate in (current, *current.parents):
        try:
            if (candidate / ".git").exists():
                return str(candidate)
        except OSError:
            return None
    return None


@lru_cache(maxsize=512)
def _project_root(directory: str) -> str | None:
    """Find a safe project root even when a deployment omits ``.git``.

    Git remains the strongest boundary.  Container builds commonly omit it,
    so we next use conventional project markers and finally the process
    working directory when the observed frame is actually beneath it.  The
    returned root is used only to derive a relative path; it is never emitted.
    """

    repository = _repository_root(directory)
    if repository:
        return repository
    try:
        current = Path(directory).resolve()
    except (OSError, RuntimeError):
        return None
    for candidate in (current, *current.parents):
        try:
            if any((candidate / marker).is_file() for marker in _PROJECT_MARKERS):
                return str(candidate)
        except OSError:
            return None
    try:
        working_directory = Path.cwd().resolve()
    except (OSError, RuntimeError):
        return None
    if working_directory == Path(working_directory.anchor):
        return None
    return str(working_directory) if _is_under(current, working_directory) else None


def _git_directory(repo_root: Path) -> Path | None:
    marker = repo_root / ".git"
    try:
        if marker.is_dir():
            return marker.resolve()
        if not marker.is_file():
            return None
        first_line = marker.read_text(encoding="utf-8", errors="replace").splitlines()[0]
        prefix, separator, value = first_line.partition(":")
        if not separator or prefix.strip().lower() != "gitdir":
            return None
        target = Path(value.strip())
        if not target.is_absolute():
            target = repo_root / target
        return target.resolve()
    except (IndexError, OSError, RuntimeError):
        return None


def _read_revision_file(path: Path) -> str | None:
    try:
        value = path.read_text(encoding="ascii", errors="ignore").strip()
    except OSError:
        return None
    return value.lower() if _SHA_RE.fullmatch(value) else None


@lru_cache(maxsize=128)
def _git_revision(repo_root: str) -> str | None:
    root = Path(repo_root)
    git_dir = _git_directory(root)
    if git_dir is None:
        return None
    head = _read_revision_file(git_dir / "HEAD")
    if head:
        return head
    try:
        head_text = (git_dir / "HEAD").read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return None
    if not head_text.startswith("ref: "):
        return None
    ref = head_text[5:].strip()
    if not ref or ref.startswith(("/", "\\")) or ".." in Path(ref).parts:
        return None

    search_dirs = [git_dir]
    try:
        common = (git_dir / "commondir").read_text(encoding="utf-8", errors="replace").strip()
        if common:
            common_dir = Path(common)
            if not common_dir.is_absolute():
                common_dir = git_dir / common_dir
            search_dirs.append(common_dir.resolve())
    except (OSError, RuntimeError):
        pass

    for directory in search_dirs:
        revision = _read_revision_file(directory / ref)
        if revision:
            return revision
    for directory in search_dirs:
        try:
            lines = (directory / "packed-refs").read_text(
                encoding="ascii", errors="ignore"
            ).splitlines()
        except OSError:
            continue
        for line in lines:
            if not line or line.startswith(("#", "^")):
                continue
            revision, separator, packed_ref = line.partition(" ")
            if separator and packed_ref == ref and _SHA_RE.fullmatch(revision):
                return revision.lower()
    return None


def _safe_relative_path(path: Path, root: Path) -> str | None:
    try:
        relative = path.relative_to(root)
    except ValueError:
        return None
    value = relative.as_posix()
    if (
        not value
        or len(value) > 1024
        or value.startswith(("/", "~"))
        or "\\" in value
        or any(part in {"", ".", ".."} for part in relative.parts)
        or any(ord(character) < 32 or ord(character) == 127 for character in value)
        or _UNSAFE_STRUCTURAL_RE.search(value)
    ):
        return None
    return value


def _validated_relative_path(value: Any) -> str | None:
    if not isinstance(value, str) or len(value) > 1024:
        return None
    path = PurePosixPath(value)
    if (
        not value
        or path.is_absolute()
        or value.startswith(("~", "file://"))
        or "\\" in value
        or any(part in {"", ".", ".."} for part in path.parts)
        or any(ord(character) < 32 or ord(character) == 127 for character in value)
        or _UNSAFE_STRUCTURAL_RE.search(value)
    ):
        return None
    return path.as_posix()


def _validated_frame(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, dict):
        return None
    path = _validated_relative_path(value.get("path"))
    line = value.get("line")
    symbol = value.get("symbol")
    if path is None or isinstance(line, bool) or not isinstance(line, int) or line < 1:
        return None
    if symbol is not None and (
        not isinstance(symbol, str) or _SAFE_SYMBOL_RE.fullmatch(symbol) is None
    ):
        return None
    frame = {"path": path, "line": line}
    if symbol:
        frame["symbol"] = symbol
    return frame


def normalize_runtime_source_evidence(value: Any) -> dict[str, Any] | None:
    """Validate and copy the exact provider-neutral evidence contract."""

    if not isinstance(value, dict):
        return None
    callsite = _validated_frame(value.get("callsite"))
    stack_value = value.get("stack")
    revision = value.get("git_revision")
    fingerprint = value.get("fingerprint")
    if (
        value.get("version") != "1.0"
        or value.get("truth") != "observed"
        or value.get("language") != "python"
        or not isinstance(value.get("runtime"), str)
        or _SAFE_RUNTIME_RE.fullmatch(value["runtime"]) is None
        or callsite is None
        or not isinstance(stack_value, list)
        or len(stack_value) > MAX_RUNTIME_SOURCE_FRAMES
        or not isinstance(fingerprint, str)
        or len(fingerprint) != 64
        or _SHA_RE.fullmatch(fingerprint) is None
        or (
            revision is not None
            and (not isinstance(revision, str) or _SHA_RE.fullmatch(revision) is None)
        )
    ):
        return None
    stack: list[dict[str, Any]] = []
    for candidate in stack_value:
        frame = _validated_frame(candidate)
        if frame is None:
            return None
        stack.append(frame)
    normalized = {
        "version": "1.0",
        "truth": "observed",
        "callsite": callsite,
        "stack": stack,
        "language": "python",
        "runtime": value["runtime"],
        "fingerprint": fingerprint.lower(),
    }
    if revision is not None:
        normalized["git_revision"] = revision.lower()
    return normalized


def _frame_candidates() -> list[tuple[Path, str, int, str]]:
    candidates: list[tuple[Path, str, int, str]] = []
    frame = None
    try:
        frame = sys._getframe(2)
        scanned = 0
        while frame is not None and scanned < MAX_SCANNED_FRAMES:
            scanned += 1
            module_name = str(frame.f_globals.get("__name__") or "")
            filename = frame.f_code.co_filename
            # ``co_qualname`` arrived after the oldest interpreter we still
            # support; ``co_name`` remains a safe structural fallback.
            symbol = getattr(frame.f_code, "co_qualname", frame.f_code.co_name)
            line = frame.f_lineno
            if (
                filename
                and not filename.startswith("<")
                and not _is_excluded_module(module_name)
            ):
                try:
                    path = Path(filename).resolve()
                except (OSError, RuntimeError):
                    path = None
                if path is not None and path.is_absolute() and not _looks_like_library_path(path):
                    safe_symbol = symbol if _SAFE_SYMBOL_RE.fullmatch(symbol) else ""
                    candidates.append((path, safe_symbol, line, module_name))
            frame = frame.f_back
    except (AttributeError, ValueError):
        return []
    finally:
        del frame
    return candidates


def _fingerprint(callsite: dict[str, Any], revision: str | None) -> str:
    stable = {
        "path": callsite["path"],
        "symbol": callsite.get("symbol"),
        "line": callsite["line"],
        "revision": revision,
    }
    encoded = json.dumps(stable, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def capture_runtime_source_evidence(
    *,
    enabled: bool | str | None = None,
    max_frames: int = MAX_RUNTIME_SOURCE_FRAMES,
) -> dict[str, Any] | None:
    """Capture bounded, observed customer-code callsite metadata.

    This function is intentionally fail-open so framework adapters can reuse it
    at any provider boundary without affecting the customer call.
    """

    if not runtime_source_enabled(enabled):
        return None
    try:
        limit = max(1, min(int(max_frames), MAX_RUNTIME_SOURCE_FRAMES))
        candidates = _frame_candidates()
        if not candidates:
            return None

        selected_root: Path | None = None
        revision: str | None = None
        frames: list[dict[str, Any]] = []
        for path, symbol, line, _module_name in candidates:
            symbol = symbol if _SAFE_SYMBOL_RE.fullmatch(symbol) else ""
            root_value = _project_root(str(path.parent))
            if not root_value:
                continue
            root = Path(root_value)
            if selected_root is None:
                selected_root = root
                revision = _git_revision(root_value)
            if root != selected_root:
                continue
            relative = _safe_relative_path(path, root)
            if relative is None:
                continue
            captured_frame: dict[str, Any] = {
                "path": relative,
                "line": max(int(line), 1),
            }
            if symbol:
                captured_frame["symbol"] = symbol
            frames.append(captured_frame)
            if len(frames) >= limit:
                break
        if not frames:
            return None

        payload: dict[str, Any] = {
            "version": "1.0",
            "truth": "observed",
            "callsite": dict(frames[0]),
            "stack": frames,
            "language": "python",
            "runtime": f"{platform.python_implementation()} {platform.python_version()}",
            "fingerprint": _fingerprint(frames[0], revision),
        }
        if revision:
            payload["git_revision"] = revision
        return payload
    except Exception:
        return None


def attach_runtime_source_evidence(envelope: Any, evidence: dict[str, Any] | None) -> Any:
    """Return a Context IR envelope whose items cite observed runtime evidence."""

    normalized = normalize_runtime_source_evidence(evidence)
    if normalized is None or envelope is None:
        return envelope
    try:
        items = [item.model_copy(update={"runtime_source": normalized}) for item in envelope.items]
        return envelope.model_copy(update={"items": items})
    except Exception:
        return envelope
