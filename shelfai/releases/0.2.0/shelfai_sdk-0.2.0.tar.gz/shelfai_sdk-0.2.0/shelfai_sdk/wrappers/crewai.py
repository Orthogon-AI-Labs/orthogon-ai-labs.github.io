"""CrewAI integration helpers for the ShelfAI SDK."""

from __future__ import annotations

import asyncio
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from pydantic import Field, PrivateAttr

try:
    from crewai import Crew
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "ShelfAI CrewAI integration requires the optional CrewAI extra. "
        'Install with `pip install "shelfai-sdk[crewai]"`.'
    ) from exc

from ..telemetry import framework_adapter


class ShelfAICrew(Crew):
    """CrewAI subclass that emits canonical ShelfAI events through the adapter."""

    shelf: Any = Field(exclude=True, repr=False)
    crew_id: Optional[str] = Field(default=None, exclude=True, repr=False)

    _shelfai_session_id: Optional[str] = PrivateAttr(default=None)
    _shelfai_started_at: Optional[datetime] = PrivateAttr(default=None)
    _shelfai_original_agent_callbacks: Dict[int, Any] = PrivateAttr(default_factory=dict)
    _shelfai_original_task_execute: Dict[int, Any] = PrivateAttr(default_factory=dict)

    def _resolved_crew_id(self) -> str:
        return self.crew_id or str(self.id)

    def _begin_shelfai_session(self, inputs: Optional[Dict[str, Any]]) -> str:
        self.crew_id = self._resolved_crew_id()
        self._shelfai_session_id = self.shelf.generate_trace_id()
        self._shelfai_started_at = datetime.now(timezone.utc)
        framework_adapter.emit_crewai_session_start(self, self._shelfai_session_id, inputs)
        return self._shelfai_session_id

    def _install_shelfai_hooks(self, session_id: str) -> None:
        self._shelfai_original_agent_callbacks = {}
        self._shelfai_original_task_execute = {}
        for agent in self.agents:
            self._shelfai_original_agent_callbacks[id(agent)] = getattr(agent, "step_callback", None)
            agent.step_callback = framework_adapter.wrap_crewai_step_callback(
                self,
                agent,
                getattr(agent, "step_callback", None),
                session_id,
            )
        for task in self.tasks:
            self._shelfai_original_task_execute[id(task)] = task._execute_core
            task._execute_core = framework_adapter.wrap_crewai_task_execution(self, task, session_id)

    def _restore_shelfai_hooks(self) -> None:
        for agent in self.agents:
            if id(agent) in self._shelfai_original_agent_callbacks:
                agent.step_callback = self._shelfai_original_agent_callbacks[id(agent)]
        for task in self.tasks:
            if id(task) in self._shelfai_original_task_execute:
                task._execute_core = self._shelfai_original_task_execute[id(task)]
        self._shelfai_original_agent_callbacks = {}
        self._shelfai_original_task_execute = {}

    async def _run_base_kickoff_async(self, inputs: Optional[Dict[str, Any]]) -> Any:
        native_async = getattr(super(), "akickoff", None)
        if native_async is not None:
            return await native_async(inputs=inputs)
        # CrewAI's thread-based kickoff_async delegates to self.kickoff in current
        # releases, so call the base kickoff directly to avoid double events.
        return await asyncio.to_thread(super().kickoff, inputs)

    def kickoff(self, inputs: Optional[Dict[str, Any]] = None) -> Any:
        session_id = self._begin_shelfai_session(inputs)
        self._install_shelfai_hooks(session_id)
        try:
            result = super().kickoff(inputs=inputs)
            framework_adapter.emit_crewai_session_end(
                self,
                session_id,
                result,
                self._shelfai_started_at or datetime.now(timezone.utc),
            )
            return result
        except Exception as error:
            framework_adapter.emit_crewai_session_end(
                self,
                session_id,
                None,
                self._shelfai_started_at or datetime.now(timezone.utc),
                error=error,
            )
            raise
        finally:
            self._restore_shelfai_hooks()

    async def kickoff_async(self, inputs: Optional[Dict[str, Any]] = None) -> Any:
        session_id = self._begin_shelfai_session(inputs)
        self._install_shelfai_hooks(session_id)
        try:
            result = await asyncio.to_thread(super().kickoff, inputs)
            framework_adapter.emit_crewai_session_end(
                self,
                session_id,
                result,
                self._shelfai_started_at or datetime.now(timezone.utc),
            )
            return result
        except Exception as error:
            framework_adapter.emit_crewai_session_end(
                self,
                session_id,
                None,
                self._shelfai_started_at or datetime.now(timezone.utc),
                error=error,
            )
            raise
        finally:
            self._restore_shelfai_hooks()

    async def akickoff(self, inputs: Optional[Dict[str, Any]] = None) -> Any:
        session_id = self._begin_shelfai_session(inputs)
        self._install_shelfai_hooks(session_id)
        try:
            result = await self._run_base_kickoff_async(inputs)
            framework_adapter.emit_crewai_session_end(
                self,
                session_id,
                result,
                self._shelfai_started_at or datetime.now(timezone.utc),
            )
            return result
        except Exception as error:
            framework_adapter.emit_crewai_session_end(
                self,
                session_id,
                None,
                self._shelfai_started_at or datetime.now(timezone.utc),
                error=error,
            )
            raise
        finally:
            self._restore_shelfai_hooks()
