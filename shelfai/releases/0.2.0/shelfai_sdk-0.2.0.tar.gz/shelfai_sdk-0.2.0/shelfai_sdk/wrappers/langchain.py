"""LangChain callback handler for the ShelfAI SDK."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Dict, List, Optional
from uuid import UUID

try:
    from langchain_core.callbacks.base import BaseCallbackHandler
except ImportError as exc:  # pragma: no cover
    raise ImportError(
        "ShelfAI LangChain integration requires the optional LangChain extra. "
        'Install with `pip install "shelfai-sdk[langchain]"`.'
    ) from exc

from ..telemetry import framework_adapter
from ..runtime_source import capture_runtime_source_evidence

if TYPE_CHECKING:
    from langchain_core.agents import AgentAction, AgentFinish
    from langchain_core.messages import BaseMessage
    from langchain_core.outputs import ChatGenerationChunk, GenerationChunk, LLMResult
    from tenacity import RetryCallState

    from ..client import ShelfAI


class ShelfAICallbackHandler(BaseCallbackHandler):
    """Drop-in LangChain callback handler that emits canonical ShelfAI events."""

    raise_error: bool = False
    run_inline: bool = False

    def __init__(self, shelf: "ShelfAI") -> None:
        super().__init__()
        self.shelf = shelf
        self._framework_runs: Dict[str, Dict[str, Any]] = {}

    def _runtime_source(self) -> dict[str, Any] | None:
        try:
            return capture_runtime_source_evidence(
                enabled=getattr(self.shelf, "runtime_source_evidence", True)
            )
        except Exception:
            return None

    def on_llm_start(
        self,
        serialized: Dict[str, Any],
        prompts: List[str],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_llm_start(
            self, serialized, prompts, run_id, parent_run_id, tags, metadata,
            _shelfai_runtime_source=self._runtime_source(), **kwargs
        )

    def on_chat_model_start(
        self,
        serialized: Dict[str, Any],
        messages: List[List["BaseMessage"]],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_chat_model_start(
            self, serialized, messages, run_id, parent_run_id, tags, metadata,
            _shelfai_runtime_source=self._runtime_source(), **kwargs
        )

    def on_llm_new_token(
        self,
        token: str,
        *,
        chunk: Optional["GenerationChunk | ChatGenerationChunk"] = None,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_llm_new_token(self, token, run_id, parent_run_id, chunk=chunk, **kwargs)

    def on_llm_end(
        self,
        response: "LLMResult",
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_llm_end(self, response, run_id, parent_run_id, **kwargs)

    def on_llm_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_llm_error(self, error, run_id, parent_run_id, **kwargs)

    def on_chain_start(
        self,
        serialized: Dict[str, Any],
        inputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_chain_start(
            self, serialized, inputs, run_id, parent_run_id, tags, metadata,
            _shelfai_runtime_source=self._runtime_source(), **kwargs
        )

    def on_chain_end(
        self,
        outputs: Dict[str, Any],
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_chain_end(self, outputs, run_id, parent_run_id, **kwargs)

    def on_chain_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_chain_error(self, error, run_id, parent_run_id, **kwargs)

    def on_tool_start(
        self,
        serialized: Dict[str, Any],
        input_str: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        inputs: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_tool_start(
            self, serialized, input_str, run_id, parent_run_id, tags, metadata, inputs,
            _shelfai_runtime_source=self._runtime_source(), **kwargs
        )

    def on_tool_end(
        self,
        output: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_tool_end(
            self, output, run_id, parent_run_id,
            _shelfai_runtime_source=self._runtime_source(), **kwargs
        )

    def on_tool_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_tool_error(self, error, run_id, parent_run_id, **kwargs)

    def on_retriever_start(
        self,
        serialized: Dict[str, Any],
        query: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_retriever_start(self, serialized, query, run_id, parent_run_id, tags, metadata, **kwargs)

    def on_retriever_end(
        self,
        documents: Any,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_retriever_end(
            self, documents, run_id, parent_run_id,
            _shelfai_runtime_source=self._runtime_source(), **kwargs
        )

    def on_retriever_error(
        self,
        error: BaseException,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_retriever_error(self, error, run_id, parent_run_id, **kwargs)

    def on_agent_action(
        self,
        action: "AgentAction",
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_agent_action(self, action, run_id, parent_run_id, **kwargs)

    def on_agent_finish(
        self,
        finish: "AgentFinish",
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_agent_finish(self, finish, run_id, parent_run_id, **kwargs)

    def on_custom_event(
        self,
        name: str,
        data: Any,
        *,
        run_id: UUID,
        tags: Optional[List[str]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_custom_event(self, name, data, run_id, tags, metadata, **kwargs)

    def on_retry(
        self,
        retry_state: "RetryCallState",
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_retry(self, retry_state, run_id, parent_run_id, **kwargs)

    def on_text(
        self,
        text: str,
        *,
        run_id: UUID,
        parent_run_id: Optional[UUID] = None,
        **kwargs: Any,
    ) -> Any:
        return framework_adapter.emit_langchain_text(self, text, run_id, parent_run_id, **kwargs)
