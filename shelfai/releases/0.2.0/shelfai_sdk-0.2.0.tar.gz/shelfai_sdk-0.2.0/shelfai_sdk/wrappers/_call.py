"""Shared, fail-open telemetry lifecycle for one wrapped provider call."""

from __future__ import annotations

import time
from typing import Any, Callable, Optional

from .._guard import telemetry_guard
from ..runtime_source import capture_runtime_source_evidence


def runtime_source_for_call(shelf: Any) -> dict[str, Any] | None:
    return capture_runtime_source_evidence(enabled=getattr(shelf, "runtime_source_evidence", True))


def baseline_for_call(shelf: Any, system: Any, messages: Any) -> tuple[int, int]:
    def _compute() -> tuple[int, int]:
        baseline = shelf.reconstruct_baseline_context(system=system, messages=messages)
        return (
            max(int(getattr(baseline, "approx_input_tokens", 0) or 0), 0),
            max(int(getattr(baseline, "approx_output_tokens", 0) or 0), 0),
        )

    return telemetry_guard("baseline", _compute, default=(0, 0)) or (0, 0)


class ProviderCall:
    """Observe one provider call without ever raising into the application.

    ``begin`` opens the trace and captures the input context, ``error`` records
    a provider failure, ``finish`` records the response, and ``passthrough``
    closes the trace when the SDK deliberately does not inspect the response
    (streaming). Every step is individually guarded; a failure in one step
    leaves the others best-effort and the customer's call untouched.
    """

    def __init__(
        self,
        shelf: Any,
        *,
        name: str,
        provider: str,
        model: str,
        system: Any,
        messages: Any,
        tools: Any,
        experiment: dict[str, Any],
        runtime_source: dict[str, Any] | None,
        metadata: Optional[dict[str, Any]] = None,
        record_error: Callable[..., Any],
    ) -> None:
        self.shelf = shelf
        self.model = model
        self.provider = provider
        self.runtime_source = runtime_source
        self.trace: Any = None
        self.started_at: float | None = None
        self.baseline = baseline_for_call(shelf, system, messages)
        self._record_error = record_error
        self._closed = False

        def _begin() -> None:
            trace = shelf.trace(name)
            trace.__enter__()
            self.trace = trace
            context = shelf.extract_context_from_call(
                system=system,
                messages=messages,
                trace_id=trace.id,
                metadata={"provider": provider, "model": model, **(metadata or {}), **experiment},
                tools=tools,
                runtime_source=runtime_source,
            )
            trace.snapshot(context)

        telemetry_guard("capture_input", _begin)

    @property
    def trace_id(self) -> Optional[str]:
        return getattr(self.trace, "id", None)

    def start_timer(self) -> None:
        self.started_at = time.perf_counter()

    def latency_ms(self) -> Optional[int]:
        if self.started_at is None:
            return None
        return int((time.perf_counter() - self.started_at) * 1000)

    def error(self, exc: BaseException) -> None:
        if self._closed or self.trace is None:
            return
        self._closed = True
        telemetry_guard("record_error", self._record_error, self.trace, self.model, exc)
        telemetry_guard("close_trace", self.trace.__exit__, type(exc), exc, getattr(exc, "__traceback__", None))

    def finish(self, recorder: Callable[..., Any], response: Any) -> None:
        if self._closed or self.trace is None:
            return
        self._closed = True
        telemetry_guard(
            "record_output",
            recorder,
            self.shelf,
            self.trace,
            self.model,
            response,
            self.baseline[0],
            self.baseline[1],
            latency_ms=self.latency_ms(),
            runtime_source=self.runtime_source,
        )
        telemetry_guard("close_trace", self.trace.__exit__, None, None, None)

    def passthrough(self) -> None:
        """Close the trace without inspecting a response the SDK does not parse."""

        if self._closed or self.trace is None:
            return
        self._closed = True
        telemetry_guard("close_trace", self.trace.__exit__, None, None, None)


__all__ = ["ProviderCall", "baseline_for_call", "runtime_source_for_call"]
