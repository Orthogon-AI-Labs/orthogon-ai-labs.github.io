"""LlamaIndex instrumentation integration."""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, Field

from ..context_ir import ContextIR, context_item, provider_input_ir, provider_output_ir
from ..runtime_source import attach_runtime_source_evidence, capture_runtime_source_evidence


def _runtime_source(shelf: Any) -> dict[str, Any] | None:
    try:
        return capture_runtime_source_evidence(
            enabled=getattr(shelf, "runtime_source_evidence", True)
        )
    except Exception:
        return None

try:  # pragma: no cover - optional dependency
    from llama_index.core.instrumentation.event_handlers.base import BaseEventHandler
except ImportError:  # pragma: no cover
    class BaseEventHandler(BaseModel):  # type: ignore[no-redef]
        pass


class ShelfAILlamaIndexHandler(BaseEventHandler):
    """Handle LlamaIndex 0.10.20+ instrumentation events as Context IR."""

    model_config = ConfigDict(arbitrary_types_allowed=True)
    shelf: Any = Field(exclude=True)

    @classmethod
    def class_name(cls) -> str:
        return "ShelfAILlamaIndexHandler"

    def handle(self, event: Any, **kwargs: Any) -> None:
        event_type = event.class_name() if callable(getattr(event, "class_name", None)) else type(event).__name__
        payload = event.model_dump(mode="json") if hasattr(event, "model_dump") else {
            key: value for key, value in vars(event).items() if not key.startswith("_")
        }
        trace_id = str(payload.get("span_id") or payload.get("id_") or self.shelf.generate_trace_id())
        normalized = event_type.lower()
        metadata: dict[str, Any] = {
            "framework": "llamaindex",
            "hook": "instrumentation",
            "event_type": event_type,
            "model": (payload.get("model_dict") or {}).get("model") if isinstance(payload.get("model_dict"), dict) else None,
            "framework_event": payload,
        }
        ir: ContextIR
        name = "trace_output"
        if "llm" in normalized and ("start" in normalized or "inprogress" in normalized):
            ir = provider_input_ir(
                provider="llamaindex",
                messages=payload.get("messages") or [],
                tools=payload.get("tools"),
                run_id=trace_id,
            )
            name = "trace_started"
        elif "llm" in normalized and "end" in normalized:
            ir = provider_output_ir(provider="llamaindex", response=payload.get("response"), run_id=trace_id)
            name = "trace_finished"
        elif "tool" in normalized:
            item_type = "tool_result" if "end" in normalized or "result" in normalized else "tool_call"
            ir = ContextIR(items=[context_item(item_type, payload, run_id=trace_id, source="llamaindex.event", selection="produced" if item_type == "tool_result" else "selected")])
            name = "tool_end" if item_type == "tool_result" else "tool_start"
        elif "retriev" in normalized:
            values = payload.get("nodes") or payload.get("documents") or [payload]
            if not isinstance(values, list):
                values = [values]
            ir = ContextIR(items=[context_item("retrieved_evidence", value, ordinal=index, run_id=trace_id, source="llamaindex.retrieval") for index, value in enumerate(values)])
        else:
            ir = ContextIR(items=[context_item("state_snapshot", payload, run_id=trace_id, source="llamaindex.event")])
        ir = attach_runtime_source_evidence(
            ir,
            _runtime_source(self.shelf),
        )
        metadata["context_ir"] = ir.model_dump(mode="json")
        self.shelf.emit_event(name, metadata, trace_id=trace_id)

    # Pre-instrumentation CallbackManager compatibility.
    def on_event_start(self, event_type, payload=None, **kwargs):
        self.shelf.emit_event("tool_start", {"framework": "llamaindex", "event_type": str(event_type), "payload": payload or {}})

    def on_event_end(self, event_type, payload=None, **kwargs):
        self.shelf.emit_event("tool_end", {"framework": "llamaindex", "event_type": str(event_type), "payload": payload or {}})


def register_llamaindex_handler(shelf: Any, dispatcher: Any = None) -> ShelfAILlamaIndexHandler:
    """Attach ShelfAI to the root LlamaIndex dispatcher in one line."""

    if dispatcher is None:
        try:
            import llama_index.core.instrumentation as instrument
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise ImportError(
                "ShelfAI LlamaIndex integration requires llama-index-core. "
                'Install with `pip install "shelfai-sdk[llamaindex]`. '
            ) from exc
        dispatcher = instrument.get_dispatcher()
    handler = ShelfAILlamaIndexHandler(shelf=shelf)
    dispatcher.add_event_handler(handler)
    return handler
