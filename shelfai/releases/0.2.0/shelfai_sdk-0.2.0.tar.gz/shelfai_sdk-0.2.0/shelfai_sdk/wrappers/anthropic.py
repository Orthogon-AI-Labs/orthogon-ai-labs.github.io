"""Anthropic wrapper for the ShelfAI SDK."""

from __future__ import annotations

import inspect
from typing import Any

from .._guard import telemetry_guard
from .._pricing import get_rate
from ..context_ir import provider_output_ir
from ._call import ProviderCall, runtime_source_for_call


def _emit_llm_call(
    shelf,
    trace_id: str,
    *,
    model: str,
    provider: str,
    tokens_input: int,
    tokens_output: int,
    tokens_cache_read: int,
    tokens_cache_write: int,
    baseline_tokens_input: int,
    baseline_tokens_output: int,
) -> None:
    rate = get_rate(model)
    resolved_baseline_input = baseline_tokens_input or tokens_input
    resolved_baseline_output = baseline_tokens_output or tokens_output
    shelf.emit_event(
        "llm_call",
        trace_id=trace_id,
        event_fields={
            "model": model,
            "provider": provider,
            "tokens_input": int(tokens_input or 0),
            "tokens_output": int(tokens_output or 0),
            "tokens_cache_read": int(tokens_cache_read or 0),
            "tokens_cache_write": int(tokens_cache_write or 0),
            "baseline_tokens_input": int(resolved_baseline_input or 0),
            "baseline_tokens_output": int(resolved_baseline_output or 0),
            "rate_snapshot": rate.rate_snapshot(),
        },
    )


def _usage_attr(usage: Any, name: str) -> int:
    try:
        return int(getattr(usage, name, 0) or 0)
    except (TypeError, ValueError):
        return 0


def _record_error(trace: Any, model: Any, exc: BaseException) -> None:
    trace.event(
        "trace_error",
        {
            "provider": "anthropic",
            "model": model,
            "error_type": exc.__class__.__name__,
            "error_message": "[REDACTED_TEXT]",
        },
    )


def _record_non_streaming_call(
    shelf,
    trace,
    model: str,
    response: Any,
    baseline_input: int,
    baseline_output: int,
    *,
    latency_ms: int | None = None,
    runtime_source: dict[str, Any] | None = None,
) -> None:
    usage = getattr(response, "usage", None)
    tokens_input = _usage_attr(usage, "input_tokens")
    tokens_output = _usage_attr(usage, "output_tokens")
    tokens_cache_read = _usage_attr(usage, "cache_read_input_tokens")
    tokens_cache_write = _usage_attr(usage, "cache_creation_input_tokens")

    _emit_llm_call(
        shelf,
        trace.id,
        model=model,
        provider="anthropic",
        tokens_input=tokens_input,
        tokens_output=tokens_output,
        tokens_cache_read=tokens_cache_read,
        tokens_cache_write=tokens_cache_write,
        baseline_tokens_input=baseline_input,
        baseline_tokens_output=baseline_output,
    )
    output_ir = provider_output_ir(
        provider="anthropic",
        response=response,
        run_id=trace.id,
        runtime_source=runtime_source,
    )
    shelf.register_output_context(output_ir)
    trace.record_output(
        {
            "provider": "anthropic",
            "model": model,
            "response_id": getattr(response, "id", None),
            "latency_ms": latency_ms,
            "input_tokens": tokens_input,
            "output_tokens": tokens_output,
            "total_tokens": tokens_input + tokens_output,
            "cache_creation_input_tokens": tokens_cache_write,
            "cache_read_input_tokens": tokens_cache_read,
            "cache_read": tokens_cache_read,
            "cache_write": tokens_cache_write,
            "stop_reason": getattr(response, "stop_reason", None),
            "context_ir": output_ir.model_dump(mode="json"),
        }
    )


def _prepare(shelf: Any, kwargs: dict[str, Any]) -> tuple[str, Any, Any, Any, dict[str, Any]]:
    model = kwargs.get("model", "unknown")
    system = kwargs.get("system")
    messages = kwargs.get("messages") or []
    system, messages, tools, experiment = shelf.apply_experiment_overrides(
        system=system,
        messages=messages,
        tools=kwargs.get("tools"),
    )
    kwargs["messages"] = messages
    if system is not None or "system" in kwargs:
        kwargs["system"] = system
    if tools is not None or "tools" in kwargs:
        kwargs["tools"] = tools
    return model, system, messages, tools, experiment


def _call(shelf: Any, kwargs: dict[str, Any], runtime_source: dict[str, Any] | None) -> ProviderCall:
    model, system, messages, tools, experiment = _prepare(shelf, kwargs)
    return ProviderCall(
        shelf,
        name=f"anthropic_call_{model}",
        provider="anthropic",
        model=model,
        system=system,
        messages=messages,
        tools=tools,
        experiment=experiment,
        runtime_source=runtime_source,
        record_error=_record_error,
    )


class _EnteredStream:
    """Proxy for the object yielded by ``with client.messages.stream(...) as stream``.

    The real Anthropic SDK yields a ``MessageStream`` (``text_stream``,
    ``get_final_message()``, iteration) from its ``MessageStreamManager``. The
    proxy forwards everything to that entered object so customer code sees the
    exact provider API.
    """

    def __init__(self, entered: Any) -> None:
        self._entered = entered

    def __iter__(self):
        return iter(self._entered)

    def __aiter__(self):
        return self._entered.__aiter__()

    def __getattr__(self, name: str) -> Any:
        return getattr(self._entered, name)


def _resolve_final_message(stream: Any) -> Any:
    final_getter = getattr(stream, "get_final_message", None)
    if callable(final_getter):
        try:
            result = final_getter()
        except Exception:  # noqa: BLE001 - never surface to the customer
            result = None
        if result is not None and not inspect.isawaitable(result):
            return result
    for attribute in ("final_message", "current_message_snapshot"):
        candidate = getattr(stream, attribute, None)
        if candidate is not None and not callable(candidate):
            return candidate
    return None


class _AnthropicStreamWrapper:
    """Wrap an Anthropic ``MessageStreamManager`` without changing its contract."""

    def __init__(self, manager: Any, call: ProviderCall) -> None:
        self._manager = manager
        self._call = call
        self._entered: Any = None
        self._closed = False

    def _finalize(self, exc_type=None, exc=None, tb=None) -> None:
        if self._closed:
            return
        self._closed = True
        if exc is not None:
            self._call.error(exc)
            return
        stream = self._entered if self._entered is not None else self._manager
        response = telemetry_guard("resolve_stream_response", _resolve_final_message, stream)
        if response is None:
            self._call.passthrough()
            return
        self._call.finish(_record_non_streaming_call, response)

    def __enter__(self):
        enter = getattr(self._manager, "__enter__", None)
        self._entered = enter() if callable(enter) else self._manager
        return _EnteredStream(self._entered)

    def __exit__(self, exc_type, exc, tb):
        try:
            exit_ = getattr(self._manager, "__exit__", None)
            return exit_(exc_type, exc, tb) if callable(exit_) else False
        finally:
            self._finalize(exc_type, exc, tb)

    # Compatibility for callers that iterate the manager directly.
    def __iter__(self):
        target = self._entered if self._entered is not None else self._manager
        return iter(target)

    def __getattr__(self, name: str) -> Any:
        target = self._entered if self._entered is not None else self._manager
        return getattr(target, name)


class _AnthropicAsyncStreamWrapper:
    """Wrap an ``AsyncMessageStreamManager`` for ``async with client.messages.stream(...)``."""

    def __init__(self, manager: Any, call: ProviderCall) -> None:
        self._manager = manager
        self._call = call
        self._entered: Any = None
        self._closed = False

    async def _finalize(self, exc_type=None, exc=None, tb=None) -> None:
        if self._closed:
            return
        self._closed = True
        if exc is not None:
            self._call.error(exc)
            return
        stream = self._entered if self._entered is not None else self._manager
        response = None
        final_getter = getattr(stream, "get_final_message", None)
        if callable(final_getter):
            try:
                candidate = final_getter()
                response = await candidate if inspect.isawaitable(candidate) else candidate
            except Exception:  # noqa: BLE001
                response = None
        if response is None:
            response = telemetry_guard("resolve_stream_response", _resolve_final_message, stream)
        if response is None:
            self._call.passthrough()
            return
        self._call.finish(_record_non_streaming_call, response)

    async def __aenter__(self):
        enter = getattr(self._manager, "__aenter__", None)
        self._entered = await enter() if callable(enter) else self._manager
        return _EnteredStream(self._entered)

    async def __aexit__(self, exc_type, exc, tb):
        try:
            exit_ = getattr(self._manager, "__aexit__", None)
            return await exit_(exc_type, exc, tb) if callable(exit_) else False
        finally:
            await self._finalize(exc_type, exc, tb)

    def __aiter__(self):
        target = self._entered if self._entered is not None else self._manager
        return target.__aiter__()

    def __getattr__(self, name: str) -> Any:
        target = self._entered if self._entered is not None else self._manager
        return getattr(target, name)


def wrap_anthropic_client(client: Any, shelf) -> Any:
    if not hasattr(client, "messages") or not hasattr(client.messages, "create"):
        return client

    original_create = client.messages.create

    def traced_create(*args, **kwargs):
        runtime_source = runtime_source_for_call(shelf)
        call = _call(shelf, kwargs, runtime_source)
        try:
            if kwargs.get("stream") is True:
                stream = original_create(*args, **kwargs)
                call.passthrough()
                return stream
            call.start_timer()
            response = original_create(*args, **kwargs)
        except BaseException as exc:
            call.error(exc)
            raise
        call.finish(_record_non_streaming_call, response)
        return response

    async def traced_create_async(*args, **kwargs):
        runtime_source = runtime_source_for_call(shelf)
        call = _call(shelf, kwargs, runtime_source)
        try:
            if kwargs.get("stream") is True:
                stream = await original_create(*args, **kwargs)
                call.passthrough()
                return stream
            call.start_timer()
            response = await original_create(*args, **kwargs)
        except BaseException as exc:
            call.error(exc)
            raise
        call.finish(_record_non_streaming_call, response)
        return response

    client.messages.create = traced_create_async if inspect.iscoroutinefunction(original_create) else traced_create

    if hasattr(client.messages, "stream"):
        original_stream = client.messages.stream

        def traced_stream(*args, **kwargs):
            runtime_source = runtime_source_for_call(shelf)
            call = _call(shelf, kwargs, runtime_source)
            try:
                call.start_timer()
                manager = original_stream(*args, **kwargs)
            except BaseException as exc:
                call.error(exc)
                raise
            if hasattr(manager, "__aenter__"):
                return _AnthropicAsyncStreamWrapper(manager, call)
            return _AnthropicStreamWrapper(manager, call)

        client.messages.stream = traced_stream

    return client
