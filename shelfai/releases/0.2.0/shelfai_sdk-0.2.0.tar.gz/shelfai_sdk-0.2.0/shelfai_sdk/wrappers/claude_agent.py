"""Claude Agent SDK integration for the ShelfAI SDK."""

from __future__ import annotations

import json
import logging
import threading
import time
from contextvars import ContextVar
from pathlib import Path
from typing import Any, Optional, TYPE_CHECKING

try:  # pragma: no cover - optional dependency
    import tiktoken
except Exception:  # pragma: no cover - optional in local/test environments
    tiktoken = None

from .._pricing import get_rate
from ..snapshot import Chunk, Context
from ..utils import generate_id, safe_json_dumps, to_jsonable

if TYPE_CHECKING:
    from ..client import ShelfAI


logger = logging.getLogger(__name__)


class ShelfAIAdapterCollisionError(RuntimeError):
    """Raised when an existing Claude option owns ShelfAI's reserved name."""


def connect_claude_agent(options: Any, *, replay=None, enabled=None, **kwargs: Any):
    """Fail-open, one-call Claude Agent SDK integration."""

    from ..integration import connect

    handle = connect(replay=replay, enabled=enabled, **kwargs)
    if handle.shelf is None:
        return handle, options
    try:
        ShelfAIIntegration(shelf=handle.shelf).install(options)
    except ShelfAIAdapterCollisionError as exc:
        handle.deactivate("adapter_collision", exc)
    except Exception as exc:
        handle.deactivate("adapter_failed", exc)
    return handle, options


def _require_claude_agent_sdk():
    try:
        from claude_agent_sdk import HookMatcher, create_sdk_mcp_server, tool
    except ImportError as exc:  # pragma: no cover - exercised indirectly in environments without the package
        raise ImportError(
            "ShelfAI Claude Agent integration requires the optional Claude extra. "
            "Install with `pip install \"shelfai-sdk[claude]\"`."
        ) from exc
    return HookMatcher, create_sdk_mcp_server, tool


def _metadata_from_hook(input_data: dict[str, Any]) -> dict[str, Any]:
    metadata: dict[str, Any] = {
        "integration": "claude_agent_sdk",
        "claude_session_id": input_data.get("session_id"),
        "cwd": input_data.get("cwd"),
        "transcript_path": input_data.get("transcript_path"),
        "permission_mode": input_data.get("permission_mode"),
    }
    return {key: value for key, value in metadata.items() if value not in (None, "")}


def _resolve_tool_use_id(input_data: dict[str, Any], explicit_tool_use_id: Optional[str]) -> Optional[str]:
    return explicit_tool_use_id or input_data.get("tool_use_id")


def _normalize_chunk_id(file_path: str) -> str:
    raw = str(file_path or "").strip()
    if not raw:
        return "file:unknown"
    return f"file:{Path(raw).as_posix()}"


def _extract_text_content(value: Any, _depth: int = 0, _max_depth: int = 32) -> str:
    if value is None:
        return ""
    if _depth > _max_depth:
        logger.warning("ShelfAI Claude integration truncated deeply nested text content")
        try:
            return safe_json_dumps(value)
        except Exception:
            return str(value)
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        if "content" in value:
            return _extract_text_content(value["content"], _depth=_depth + 1, _max_depth=_max_depth)
        if "text" in value:
            return _extract_text_content(value["text"], _depth=_depth + 1, _max_depth=_max_depth)
        if "result" in value:
            return _extract_text_content(value["result"], _depth=_depth + 1, _max_depth=_max_depth)
        if "file" in value and isinstance(value["file"], dict):
            return _extract_text_content(value["file"].get("content"), _depth=_depth + 1, _max_depth=_max_depth)
        return safe_json_dumps(value)
    if isinstance(value, list):
        parts = []
        for item in value:
            text = _extract_text_content(item, _depth=_depth + 1, _max_depth=_max_depth)
            if text:
                parts.append(text)
        return "\n".join(parts)
    return str(value)


def _as_mapping(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    return dict(getattr(value, "__dict__", {}))


def _usage_int(value: Any) -> int:
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _count_results(value: Any, _depth: int = 0, _max_depth: int = 32) -> int:
    if value is None:
        return 0
    if _depth > _max_depth:
        logger.warning("ShelfAI Claude integration truncated deeply nested result counts")
        return 1
    if isinstance(value, dict):
        for key in ("matches", "files", "results", "paths"):
            item = value.get(key)
            if isinstance(item, list):
                return len(item)
        if "content" in value:
            return _count_results(value["content"], _depth=_depth + 1, _max_depth=_max_depth)
        return 1
    if isinstance(value, list):
        return len(value)
    return 1


def _mcp_success(payload: Any) -> dict[str, Any]:
    rendered = safe_json_dumps(payload)
    return {
        "content": [{"type": "text", "text": rendered}],
        "structuredContent": to_jsonable(payload),
    }


def _mcp_error(message: str) -> dict[str, Any]:
    return {
        "content": [{"type": "text", "text": message}],
        "isError": True,
    }


def _token_count_for_text(file_text: str) -> tuple[int, bool]:
    if not file_text:
        return 0, False
    if tiktoken is not None:
        try:
            encoding = tiktoken.get_encoding("cl100k_base")
            return len(encoding.encode(file_text)), False
        except Exception:
            logger.warning("ShelfAI Claude integration fell back to estimated token counting")
    return max(len(file_text) // 4, 1), True


class ShelfAIIntegration:
    """Thin Claude Agent SDK integration over the existing ShelfAI client."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        api_url: Optional[str] = None,
        environment: str = "production",
        sensitive_mode: Optional[str] = None,
        offline_queue_path: Optional[str] = None,
        batch_size: Optional[int] = None,
        batch_interval_seconds: Optional[int] = None,
        http_client: Optional[Any] = None,
        start_background_threads: bool = True,
        shelf: Optional["ShelfAI"] = None,
    ):
        from ..client import ShelfAI

        self._owns_shelf = shelf is None
        self.shelf: ShelfAI = shelf or ShelfAI(
            api_key=api_key,
            agent_id=agent_id,
            api_url=api_url,
            environment=environment,
            sensitive_mode=sensitive_mode,
            offline_queue_path=offline_queue_path,
            batch_size=batch_size,
            batch_interval_seconds=batch_interval_seconds,
            http_client=http_client,
            start_background_threads=start_background_threads,
        )
        self._lock = threading.Lock()
        self._active_runs: dict[str, dict[str, Any]] = {}
        self._tool_call_starts: dict[str, dict[str, Any]] = {}
        self._hook_cache: Optional[dict[str, list[Any]]] = None
        self._mcp_server_cache: Optional[dict[str, Any]] = None
        self._synthetic_session_key: ContextVar[Optional[str]] = ContextVar(
            f"shelfai_claude_agent_session_{id(self)}",
            default=None,
        )

    def close(self) -> None:
        self._reap_stale_runs(max_age_seconds=0)
        with self._lock:
            self._active_runs.clear()
            self._tool_call_starts.clear()
        if self._owns_shelf:
            self.shelf.close()

    def install(self, options: Any) -> Any:
        """Add ShelfAI to Claude options without replacing customer config."""

        original_hooks = getattr(options, "hooks", None)
        original_servers = getattr(options, "mcp_servers", None)
        customer_hooks = dict(original_hooks or {})
        customer_servers = dict(original_servers or {})
        if "shelfai" in customer_servers:
            raise ShelfAIAdapterCollisionError("Claude options already contain an MCP server named 'shelfai'.")
        merged_hooks = {key: list(value or []) for key, value in customer_hooks.items()}
        for key, values in self.hooks().items():
            merged_hooks.setdefault(key, []).extend(values)
        merged_servers = {**customer_servers, **self.mcp_servers()}
        try:
            setattr(options, "hooks", merged_hooks)
            setattr(options, "mcp_servers", merged_servers)
        except Exception:
            try:
                setattr(options, "hooks", original_hooks)
                setattr(options, "mcp_servers", original_servers)
            except Exception:
                pass
            raise
        return options

    apply = install

    def hooks(self) -> dict[str, list[Any]]:
        if self._hook_cache is not None:
            return self._hook_cache

        HookMatcher, _create_sdk_mcp_server, _tool = _require_claude_agent_sdk()
        self._hook_cache = {
            "UserPromptSubmit": [HookMatcher(hooks=[self._on_user_prompt_submit])],
            "PreToolUse": [HookMatcher(hooks=[self._on_pre_tool_use])],
            "PostToolUse": [HookMatcher(hooks=[self._on_post_tool_use])],
            "PostToolUseFailure": [HookMatcher(hooks=[self._on_post_tool_use_failure])],
            "Stop": [HookMatcher(hooks=[self._on_stop])],
            "SubagentStop": [HookMatcher(hooks=[self._on_subagent_stop])],
        }
        return self._hook_cache

    def mcp_servers(self) -> dict[str, Any]:
        if self._mcp_server_cache is not None:
            return self._mcp_server_cache

        _HookMatcher, create_sdk_mcp_server, tool = _require_claude_agent_sdk()

        @tool(
            "recommend",
            "Fetch ShelfAI context recommendations for this agent.",
            {},
        )
        async def recommend(_args: dict[str, Any]) -> dict[str, Any]:
            return await self._invoke_mcp_tool("recommend", _args, self.shelf.get_recommendations)

        @tool(
            "health",
            "Fetch the current ShelfAI health summary for this agent.",
            {},
        )
        async def health(_args: dict[str, Any]) -> dict[str, Any]:
            return await self._invoke_mcp_tool("health", _args, self.shelf.get_health)

        @tool(
            "ask",
            "Ask the ShelfAI wiki about current operational knowledge.",
            {"question": str},
        )
        async def ask(args: dict[str, Any]) -> dict[str, Any]:
            question = str(args.get("question") or "").strip()
            if not question:
                return _mcp_error("ShelfAI ask requires a non-empty question.")
            return await self._invoke_mcp_tool("ask", args, lambda: self.shelf.ask_wiki(question))

        self._mcp_server_cache = {
            "shelfai": create_sdk_mcp_server(
                name="shelfai",
                version="1.0.0",
                tools=[recommend, health, ask],
            )
        }
        return self._mcp_server_cache

    def _session_key(self, input_data: dict[str, Any], *, create_if_missing: bool = True) -> Optional[str]:
        session_id = str(input_data.get("session_id") or "").strip()
        if session_id:
            return f"claude:{session_id}"
        transcript = str(input_data.get("transcript_path") or "").strip()
        if transcript:
            return f"transcript:{transcript}"
        synthetic_key = self._synthetic_session_key.get()
        if synthetic_key is not None:
            return synthetic_key
        if not create_if_missing:
            return None
        synthetic_key = f"synthetic:{generate_id('session')}"
        self._synthetic_session_key.set(synthetic_key)
        logger.warning(
            "ShelfAI Claude integration received a hook without claude_session_id or transcript_path; "
            "using synthetic session key %s",
            synthetic_key,
        )
        return synthetic_key

    def _ensure_run(self, input_data: dict[str, Any], *, prompt: Optional[str] = None) -> dict[str, Any]:
        self._reap_stale_runs()
        key = self._session_key(input_data)
        if key is None:
            key = f"synthetic:{generate_id('session')}"
        with self._lock:
            run = self._active_runs.get(key)
            if run is None:
                run = {
                    "session_id": generate_id("session"),
                    "claude_session_id": input_data.get("session_id"),
                    "prompt": None,
                    "created_at": time.time(),
                    "session_key": key,
                }
                self._active_runs[key] = run
            if prompt is not None:
                run["prompt"] = prompt
            return dict(run)

    def _active_run(self, input_data: dict[str, Any]) -> Optional[dict[str, Any]]:
        key = self._session_key(input_data, create_if_missing=False)
        with self._lock:
            if key is None:
                unkeyed_runs = [
                    item
                    for item in self._active_runs.values()
                    if not item.get("claude_session_id")
                ]
                if len(unkeyed_runs) == 1:
                    return dict(unkeyed_runs[0])
                return None
            run = self._active_runs.get(key)
            return dict(run) if run is not None else None

    def _finish_run(self, input_data: dict[str, Any]) -> Optional[dict[str, Any]]:
        key = self._session_key(input_data, create_if_missing=False)
        with self._lock:
            if key is None:
                unkeyed_keys = [
                    candidate_key
                    for candidate_key, candidate_run in self._active_runs.items()
                    if not candidate_run.get("claude_session_id")
                ]
                if len(unkeyed_keys) != 1:
                    return None
                key = unkeyed_keys[0]
            run = self._active_runs.pop(key, None)
            if run is not None:
                self._clear_tool_starts_for_session_locked(str(run.get("session_id") or ""))
        if run is not None and not input_data.get("session_id") and not input_data.get("transcript_path"):
            self._synthetic_session_key.set(None)
        return dict(run) if run is not None else None

    def _single_active_session_id(self) -> Optional[str]:
        with self._lock:
            if len(self._active_runs) != 1:
                return None
            return next(iter(self._active_runs.values())).get("session_id")

    def _event_metadata(
        self,
        input_data: dict[str, Any],
        run: dict[str, Any],
        **extra: Any,
    ) -> dict[str, Any]:
        metadata = {
            **_metadata_from_hook(input_data),
            "session_id": run["session_id"],
            **extra,
        }
        return {key: to_jsonable(value) for key, value in metadata.items() if value is not None}

    def _emit_integration_issue(
        self,
        event_name: str,
        method: str,
        *,
        trace_id: Optional[str] = None,
        reason: Optional[str] = None,
        exc: Optional[Exception] = None,
    ) -> None:
        metadata: dict[str, Any] = {
            "integration": "claude_agent_sdk",
            "method": method,
        }
        if reason is not None:
            metadata["reason"] = reason
        if exc is not None:
            metadata["error_type"] = type(exc).__name__
            metadata["error_message"] = "[REDACTED_TEXT]"
        try:
            self.shelf.emit_event(event_name, metadata=metadata, trace_id=trace_id)
        except Exception as emit_exc:
            logger.warning("ShelfAI claude_emit_issue (%s)", type(emit_exc).__name__)

    def _record_integration_error(self, method: str, exc: Exception, *, trace_id: Optional[str] = None) -> None:
        self._emit_integration_issue("shelfai_integration_error", method, trace_id=trace_id, exc=exc)

    def _record_malformed_hook_input(
        self,
        method: str,
        *,
        trace_id: Optional[str] = None,
        field: str = "tool_input",
        detail: str = "invalid",
    ) -> None:
        logger.warning("ShelfAI claude_malformed_hook_input (MalformedHookInput)")
        try:
            self.shelf.emit_event(
                "shelfai_integration_warning",
                metadata={
                    "integration": "claude_agent_sdk",
                    "method": method,
                    "reason": "malformed_hook_input",
                    "field": field,
                    "detail": detail,
                },
                trace_id=trace_id,
            )
        except Exception as emit_exc:
            logger.warning("ShelfAI claude_malformed_hook_warning (%s)", type(emit_exc).__name__)

    def _parse_tool_input(
        self,
        input_data: dict[str, Any],
        *,
        method: str,
        run: dict[str, Any],
    ) -> Optional[dict[str, Any]]:
        if "tool_input" not in input_data:
            self._record_malformed_hook_input(
                method,
                trace_id=run.get("session_id"),
                field="tool_input",
                detail="missing",
            )
            return None
        raw_tool_input = input_data.get("tool_input")
        if isinstance(raw_tool_input, dict):
            return raw_tool_input
        if raw_tool_input is None:
            self._record_malformed_hook_input(
                method,
                trace_id=run.get("session_id"),
                field="tool_input",
                detail="null",
            )
            return None
        if isinstance(raw_tool_input, str):
            try:
                parsed = json.loads(raw_tool_input)
            except Exception:
                self._record_malformed_hook_input(
                    method,
                    trace_id=run.get("session_id"),
                    field="tool_input",
                    detail="invalid_json",
                )
                return None
            if isinstance(parsed, dict):
                return parsed
            self._record_malformed_hook_input(
                method,
                trace_id=run.get("session_id"),
                field="tool_input",
                detail="json_not_object",
            )
            return None
        self._record_malformed_hook_input(
            method,
            trace_id=run.get("session_id"),
            field="tool_input",
            detail=type(raw_tool_input).__name__,
        )
        return None

    def _clear_tool_starts_for_session_locked(self, session_id: str) -> None:
        if not session_id:
            return
        tool_use_ids = [
            tool_use_id
            for tool_use_id, details in self._tool_call_starts.items()
            if details.get("session_id") == session_id
        ]
        for tool_use_id in tool_use_ids:
            self._tool_call_starts.pop(tool_use_id, None)

    def _reap_stale_runs(self, max_age_seconds: int = 3600) -> None:
        cutoff = time.time() - max_age_seconds
        stale_session_ids: list[str] = []
        with self._lock:
            for key, run in list(self._active_runs.items()):
                created_at = float(run.get("created_at") or 0.0)
                if created_at <= cutoff:
                    stale_session_id = str(run.get("session_id") or "")
                    if stale_session_id:
                        stale_session_ids.append(stale_session_id)
                    self._active_runs.pop(key, None)
            for tool_use_id, details in list(self._tool_call_starts.items()):
                created_at = float(details.get("created_at") or 0.0)
                if created_at <= cutoff:
                    self._tool_call_starts.pop(tool_use_id, None)
            for session_id in stale_session_ids:
                self._clear_tool_starts_for_session_locked(session_id)

    def _track_tool_start(
        self,
        input_data: dict[str, Any],
        run: dict[str, Any],
        *,
        tool_name: str,
        tool_use_id: Optional[str],
    ) -> None:
        started_at = time.time()
        if tool_use_id:
            with self._lock:
                self._tool_call_starts[tool_use_id] = {
                    "created_at": started_at,
                    "started_at": time.perf_counter(),
                    "session_id": run["session_id"],
                    "tool_name": tool_name,
                }
        self._safe_emit_event(
            "tool_start",
            input_data,
            run,
            tool_name=tool_name,
            tool_use_id=tool_use_id,
            started_at=started_at,
        )

    def _track_tool_end(
        self,
        input_data: dict[str, Any],
        run: dict[str, Any],
        *,
        tool_name: str,
        tool_use_id: Optional[str],
    ) -> None:
        latency_ms: Optional[int] = None
        started_at: Optional[float] = None
        if tool_use_id:
            with self._lock:
                tool_start = self._tool_call_starts.pop(tool_use_id, None)
            if tool_start is None and run.get("session_id"):
                with self._lock:
                    matching_ids = [
                        candidate_tool_use_id
                        for candidate_tool_use_id, details in self._tool_call_starts.items()
                        if details.get("session_id") == run.get("session_id")
                    ]
                    if len(matching_ids) == 1:
                        tool_start = self._tool_call_starts.pop(matching_ids[0], None)
            if tool_start is not None:
                started_at = float(tool_start.get("created_at") or 0.0)
                started_perf = tool_start.get("started_at")
                if isinstance(started_perf, (int, float)):
                    latency_ms = max(0, int(round((time.perf_counter() - float(started_perf)) * 1000)))
        self._safe_emit_event(
            "tool_end",
            input_data,
            run,
            tool_name=tool_name,
            tool_use_id=tool_use_id,
            latency_ms=latency_ms,
            started_at=started_at,
        )

    def _safe_emit_event(self, name: str, input_data: dict[str, Any], run: dict[str, Any], **extra: Any) -> None:
        try:
            self.shelf.emit_event(
                name,
                metadata=self._event_metadata(input_data, run, **extra),
                trace_id=run["session_id"],
            )
        except Exception as exc:
            logger.warning("ShelfAI claude_emit_event (%s)", type(exc).__name__)
            self._record_integration_error("_safe_emit_event", exc, trace_id=run.get("session_id"))

    def _llm_call_fields(self, input_data: dict[str, Any]) -> Optional[dict[str, Any]]:
        transcript_snapshot = _as_mapping(input_data.get("transcript_snapshot"))
        usage = _as_mapping(transcript_snapshot.get("usage"))
        if not usage:
            return None

        model = str(
            transcript_snapshot.get("model")
            or input_data.get("model")
            or usage.get("model")
            or "unknown"
        ).strip()
        provider = str(input_data.get("provider") or "anthropic").strip() or "anthropic"

        prompt_details = _as_mapping(usage.get("prompt_tokens_details"))
        tokens_input = _usage_int(
            usage.get("input_tokens", usage.get("prompt_tokens", usage.get("promptTokens")))
        )
        tokens_output = _usage_int(
            usage.get("output_tokens", usage.get("completion_tokens", usage.get("completionTokens")))
        )
        tokens_cache_read = _usage_int(
            usage.get(
                "cache_read_input_tokens",
                prompt_details.get("cached_tokens", usage.get("cacheReadInputTokens")),
            )
        )
        tokens_cache_write = _usage_int(
            usage.get("cache_creation_input_tokens", usage.get("cacheCreationInputTokens"))
        )
        if tokens_input <= 0 and tokens_output <= 0:
            return None

        rate = get_rate(model)
        return {
            "model": model,
            "provider": provider,
            "tokens_input": tokens_input,
            "tokens_output": tokens_output,
            "tokens_cache_read": tokens_cache_read,
            "tokens_cache_write": tokens_cache_write,
            "baseline_tokens_input": tokens_input,
            "baseline_tokens_output": tokens_output,
            "rate_snapshot": rate.rate_snapshot(),
        }

    def _safe_emit_llm_call(self, input_data: dict[str, Any], run: dict[str, Any]) -> None:
        fields = self._llm_call_fields(input_data)
        if fields is None:
            return
        try:
            self.shelf.emit_event("llm_call", trace_id=run["session_id"], event_fields=fields)
        except Exception as exc:
            logger.warning("ShelfAI claude_emit_llm_call (%s)", type(exc).__name__)

    def _safe_snapshot_read(
        self,
        input_data: dict[str, Any],
        run: dict[str, Any],
        *,
        file_path: str,
        tool_response: Any,
    ) -> None:
        try:
            file_text = _extract_text_content(tool_response)
            token_count, token_count_estimated = _token_count_for_text(file_text)
            metadata = self._event_metadata(
                input_data,
                run,
                file_path=file_path,
                tool_name="Read",
                tool_use_id=_resolve_tool_use_id(input_data, None),
            )
            if token_count_estimated:
                metadata["token_count_estimated"] = True
            context = Context(
                agent_id=self.shelf.agent_id,
                trace_id=run["session_id"],
                retrieved_chunks=[
                    Chunk(
                        id=_normalize_chunk_id(file_path),
                        source="claude_read",
                        text=file_text,
                        metadata={"file_path": file_path},
                    )
                ],
                token_count=token_count,
                metadata=metadata,
            )
            self.shelf.snapshot(context)
        except Exception as exc:
            logger.warning("ShelfAI claude_snapshot_read (%s)", type(exc).__name__)
            self._record_integration_error("_safe_snapshot_read", exc, trace_id=run.get("session_id"))

    def _safe_emit_mcp_trace(
        self,
        tool_name: str,
        args: dict[str, Any],
        payload: Any = None,
        error: Optional[str] = None,
    ) -> None:
        session_id = self._single_active_session_id()
        if not session_id:
            return
        try:
            metadata = {
                "integration": "claude_agent_sdk",
                "session_id": session_id,
                "tool_name": f"mcp__shelfai__{tool_name}",
                "tool_input": to_jsonable(args),
            }
            if payload is not None:
                metadata["output"] = to_jsonable(payload)
            if error is not None:
                metadata["error"] = error
            self.shelf.emit_event("trace_output", metadata=metadata, trace_id=session_id)
        except Exception as exc:
            logger.warning("ShelfAI claude_emit_mcp_trace (%s)", type(exc).__name__)
            self._record_integration_error("_safe_emit_mcp_trace", exc, trace_id=session_id)

    async def _invoke_mcp_tool(self, tool_name: str, args: dict[str, Any], callback) -> dict[str, Any]:
        try:
            payload = callback()
        except Exception as exc:
            self._safe_emit_mcp_trace(tool_name, args, error="[REDACTED_TEXT]")
            logger.warning("ShelfAI claude_invoke_mcp_tool (%s)", type(exc).__name__)
            self._record_integration_error("_invoke_mcp_tool", exc, trace_id=self._single_active_session_id())
            return _mcp_error(f"ShelfAI {tool_name} request failed: {exc}")
        self._safe_emit_mcp_trace(tool_name, args, payload=payload)
        return _mcp_success(payload)

    async def _on_user_prompt_submit(
        self,
        input_data: dict[str, Any],
        _tool_use_id: Optional[str],
        _context: Any,
    ) -> dict[str, Any]:
        prompt = str(input_data.get("prompt") or "")
        run = self._ensure_run(input_data, prompt=prompt)
        self._safe_emit_event(
            "session_start",
            input_data,
            run,
            prompt=prompt,
            prompt_length=len(prompt),
        )
        return {}

    async def _on_pre_tool_use(
        self,
        input_data: dict[str, Any],
        tool_use_id: Optional[str],
        _context: Any,
    ) -> dict[str, Any]:
        tool_name = str(input_data.get("tool_name") or "")
        run = self._ensure_run(input_data)
        resolved_tool_use_id = _resolve_tool_use_id(input_data, tool_use_id)
        self._track_tool_start(input_data, run, tool_name=tool_name, tool_use_id=resolved_tool_use_id)
        if tool_name not in {"Edit", "Write"}:
            return {}
        tool_input = self._parse_tool_input(input_data, method="_on_pre_tool_use", run=run)
        if tool_input is None:
            return {}
        file_path = str(tool_input.get("file_path") or "")
        self._safe_emit_event(
            "review_proposed",
            input_data,
            run,
            tool_name=tool_name,
            tool_use_id=resolved_tool_use_id,
            file_path=file_path,
            change_type="edit" if tool_name == "Edit" else "write",
            tool_input=tool_input,
        )
        return {}

    async def _on_post_tool_use(
        self,
        input_data: dict[str, Any],
        tool_use_id: Optional[str],
        _context: Any,
    ) -> dict[str, Any]:
        tool_name = str(input_data.get("tool_name") or "")
        run = self._ensure_run(input_data)
        resolved_tool_use_id = _resolve_tool_use_id(input_data, tool_use_id)
        self._track_tool_end(input_data, run, tool_name=tool_name, tool_use_id=resolved_tool_use_id)
        tool_response = input_data.get("tool_response")

        if tool_name == "Read":
            tool_input = self._parse_tool_input(input_data, method="_on_post_tool_use", run=run)
            if tool_input is None:
                return {}
            file_path = str(tool_input.get("file_path") or "")
            if file_path:
                self._safe_snapshot_read(input_data, run, file_path=file_path, tool_response=tool_response)
            return {}

        if tool_name in {"Glob", "Grep"}:
            tool_input = self._parse_tool_input(input_data, method="_on_post_tool_use", run=run)
            if tool_input is None:
                return {}
            pattern = str(tool_input.get("pattern") or "")
            self._safe_emit_event(
                "route_decision",
                input_data,
                run,
                tool_name=tool_name,
                tool_use_id=resolved_tool_use_id,
                pattern=pattern,
                route_decision=tool_name.lower(),
                result_count=_count_results(tool_response),
            )
            return {}

        if tool_name in {"Edit", "Write"}:
            tool_input = self._parse_tool_input(input_data, method="_on_post_tool_use", run=run)
            if tool_input is None:
                return {}
            self._safe_emit_event(
                "review_approved",
                input_data,
                run,
                tool_name=tool_name,
                tool_use_id=resolved_tool_use_id,
                file_path=tool_input.get("file_path"),
                status="approved",
                outcome="success",
            )
        return {}

    async def _on_post_tool_use_failure(
        self,
        input_data: dict[str, Any],
        tool_use_id: Optional[str],
        _context: Any,
    ) -> dict[str, Any]:
        tool_name = str(input_data.get("tool_name") or "")
        run = self._ensure_run(input_data)
        resolved_tool_use_id = _resolve_tool_use_id(input_data, tool_use_id)
        if resolved_tool_use_id:
            with self._lock:
                self._tool_call_starts.pop(resolved_tool_use_id, None)
        else:
            with self._lock:
                if run.get("session_id"):
                    matching_ids = [
                        candidate_tool_use_id
                        for candidate_tool_use_id, details in self._tool_call_starts.items()
                        if details.get("session_id") == run.get("session_id")
                    ]
                    if len(matching_ids) == 1:
                        self._tool_call_starts.pop(matching_ids[0], None)
        if tool_name not in {"Edit", "Write"}:
            return {}
        tool_input = self._parse_tool_input(input_data, method="_on_post_tool_use_failure", run=run)
        if tool_input is None:
            return {}
        self._safe_emit_event(
            "review_rejected",
            input_data,
            run,
            tool_name=tool_name,
            tool_use_id=resolved_tool_use_id,
            file_path=tool_input.get("file_path"),
            error=input_data.get("error"),
            is_interrupt=bool(input_data.get("is_interrupt")),
            status="rejected",
            outcome="error",
        )
        return {}

    async def _on_stop(
        self,
        input_data: dict[str, Any],
        _tool_use_id: Optional[str],
        _context: Any,
    ) -> dict[str, Any]:
        run = self._finish_run(input_data)
        if run is None:
            return {}
        self._safe_emit_llm_call(input_data, run)
        self._safe_emit_event(
            "session_end",
            input_data,
            run,
            stop_hook_active=bool(input_data.get("stop_hook_active")),
            prompt=run.get("prompt"),
        )
        return {}

    async def _on_subagent_stop(
        self,
        input_data: dict[str, Any],
        _tool_use_id: Optional[str],
        _context: Any,
    ) -> dict[str, Any]:
        run = self._active_run(input_data)
        if run is None:
            return {}
        self._safe_emit_llm_call(input_data, run)
        self._safe_emit_event(
            "trace_output",
            input_data,
            run,
            event_name="subagent_stop",
            subagent_id=input_data.get("agent_id"),
            subagent_type=input_data.get("agent_type"),
            agent_transcript_path=input_data.get("agent_transcript_path"),
        )
        return {}
