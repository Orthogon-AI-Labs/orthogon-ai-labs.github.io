"""AutoGen integration helpers for the ShelfAI SDK."""

from __future__ import annotations

import logging
from typing import Any, Dict, List, Optional, Tuple

from ..context_ir import ContextIR, context_item, provider_input_ir, provider_output_ir
from ..runtime_source import attach_runtime_source_evidence, capture_runtime_source_evidence
from ..telemetry import framework_adapter


def _runtime_source(shelf: Any) -> dict[str, Any] | None:
    try:
        return capture_runtime_source_evidence(
            enabled=getattr(shelf, "runtime_source_evidence", True)
        )
    except Exception:
        return None


def _event_payload(value: Any) -> Dict[str, Any]:
    if isinstance(value, dict):
        return value
    if hasattr(value, "model_dump"):
        payload = value.model_dump(mode="json")
        return payload if isinstance(payload, dict) else {"value": payload}
    if hasattr(value, "__dict__"):
        return {key: item for key, item in vars(value).items() if not key.startswith("_")}
    return {"value": str(value)}


class ShelfAIAutoGenLogHandler(logging.Handler):
    """Consume AutoGen 0.4+ structured events without patching agent methods."""

    def __init__(self, shelf: Any, trace_id: str | None = None):
        super().__init__()
        self.shelf = shelf
        self.trace_id = trace_id or shelf.generate_trace_id()

    def emit(self, record: logging.LogRecord) -> None:
        try:
            message = record.msg
            payload = _event_payload(message)
            event_type = type(message).__name__
            normalized = event_type.lower()
            metadata: Dict[str, Any] = {
                "framework": "autogen",
                "hook": "structured_logger",
                "event_type": event_type,
                "sender": payload.get("sender") or payload.get("source"),
                "receiver": payload.get("receiver") or payload.get("recipient"),
                "model": payload.get("model") or payload.get("model_name"),
                "framework_event": payload,
            }
            ir: ContextIR | None = None
            name = "trace_output"
            if "llmcall" in normalized:
                messages = payload.get("messages") or payload.get("prompt_messages") or []
                if payload.get("response") is not None:
                    ir = provider_output_ir(provider="autogen", response=payload["response"], run_id=self.trace_id)
                    name = "trace_finished"
                else:
                    ir = provider_input_ir(provider="autogen", messages=messages, tools=payload.get("tools"), run_id=self.trace_id)
                    name = "trace_started"
            elif "toolcall" in normalized:
                item_type = "tool_result" if payload.get("result") is not None else "tool_call"
                value = payload.get("result") if item_type == "tool_result" else payload
                ir = ContextIR(items=[context_item(item_type, value, run_id=self.trace_id, source="autogen.event", selection="produced" if item_type == "tool_result" else "selected")])
                name = "tool_end" if item_type == "tool_result" else "tool_start"
            elif "message" in normalized:
                item_type = "handoff" if metadata["sender"] and metadata["receiver"] else "message"
                ir = ContextIR(items=[context_item(item_type, payload, run_id=self.trace_id, source="autogen.message")])
                name = "handoff" if item_type == "handoff" else "trace_output"
            if ir is not None:
                ir = attach_runtime_source_evidence(
                    ir,
                    _runtime_source(self.shelf),
                )
                metadata["context_ir"] = ir.model_dump(mode="json")
            self.shelf.emit_event(name, metadata, trace_id=self.trace_id)
        except Exception:
            # Logging handlers must never break the agent runtime.
            self.handleError(record)


def install_autogen_logging(shelf: Any, logger: logging.Logger | None = None) -> ShelfAIAutoGenLogHandler:
    """Install the current AutoGen structured-event integration in one line."""

    if logger is None:
        try:
            from autogen_core import EVENT_LOGGER_NAME
        except ImportError as exc:  # pragma: no cover - optional dependency
            raise ImportError(
                "ShelfAI AutoGen integration requires autogen-core. "
                'Install with `pip install "shelfai-sdk[autogen]`. '
            ) from exc
        logger = logging.getLogger(EVENT_LOGGER_NAME)
    handler = ShelfAIAutoGenLogHandler(shelf)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)
    return handler


def register_shelfai_tracking(agent: Any, shelf: Optional[Any] = None) -> Any:
    """Attach the legacy AutoGen 0.2 reply hook.

    New AutoGen applications should use :func:`install_autogen_logging`.
    """
    if not hasattr(agent, "register_reply"):
        raise TypeError("register_shelfai_tracking() expected an AutoGen agent with register_reply().")

    if shelf is None:
        from ..client import ShelfAI

        try:
            shelf = ShelfAI()
        except ValueError as exc:
            raise ValueError(
                "register_shelfai_tracking(agent) requires SHELFAI_API_KEY and "
                "SHELFAI_AGENT_ID in the environment, or an explicit ShelfAI client."
            ) from exc

    if not hasattr(shelf, "emit_event") or not hasattr(shelf, "generate_trace_id"):
        raise TypeError("register_shelfai_tracking() expected a ShelfAI-like client with emit_event() and generate_trace_id().")

    def _tracking_reply(
        recipient: Any,
        messages: Optional[List[Dict[str, Any]]] = None,
        sender: Optional[Any] = None,
        config: Optional[Any] = None,
        **kwargs: Any,
    ) -> Tuple[bool, Optional[Any]]:
        framework_adapter.emit_autogen_reply(shelf, agent, recipient, messages, sender, config)
        return False, None

    agent.register_reply(lambda _sender: True, _tracking_reply, position=0)
    return agent
