"""OpenAI wrapper for the ShelfAI SDK."""

from __future__ import annotations

import inspect
from collections.abc import Mapping
from typing import Any

from .._pricing import get_rate
from ..context_ir import provider_output_ir
from ._call import ProviderCall, runtime_source_for_call


def _response_get(obj: Any, key: str, default: Any = None) -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def _usage_get(usage: Any, key: str, default: int = 0) -> int:
    if usage is None:
        return default
    raw = usage.get(key, default) if isinstance(usage, dict) else getattr(usage, key, default)
    try:
        return int(raw or 0)
    except (TypeError, ValueError):
        return default


def _read_attr_or_key(obj: Any, key: str) -> Any:
    if obj is None:
        return None
    if hasattr(obj, key):
        return getattr(obj, key)
    if isinstance(obj, Mapping):
        return obj.get(key)
    return None


def _read_index(obj: Any, index: int) -> Any:
    if obj is None:
        return None
    try:
        return obj[index]
    except (IndexError, KeyError, TypeError):
        return None


def _record_error(trace: Any, model: Any, exc: BaseException) -> None:
    trace.event(
        "trace_error",
        {
            "provider": "openai",
            "model": model,
            "error_type": exc.__class__.__name__,
            "error_message": "[REDACTED_TEXT]",
        },
    )


def _record_non_streaming_call(
    shelf,
    trace,
    model: str,
    response: Any,
    baseline_input: int,
    baseline_output: int,
    *,
    latency_ms: int | None = None,
    runtime_source: dict[str, Any] | None = None,
) -> None:
    usage = _response_get(response, "usage")
    tokens_input = _usage_get(usage, "prompt_tokens")
    tokens_output = _usage_get(usage, "completion_tokens")
    prompt_details = _response_get(usage, "prompt_tokens_details")
    tokens_cache_read = _usage_get(prompt_details, "cached_tokens")
    tokens_cache_write = 0
    total_tokens = _read_attr_or_key(usage, "total_tokens")
    if total_tokens is None:
        total_tokens = (tokens_input or 0) + (tokens_output or 0)

    choice0 = _read_index(_read_attr_or_key(response, "choices"), 0)
    finish_reason = _read_attr_or_key(choice0, "finish_reason")
    if finish_reason is None:
        finish_reason = _read_attr_or_key(response, "finish_reason")

    rate = get_rate(model)
    shelf.emit_event(
        "llm_call",
        trace_id=trace.id,
        event_fields={
            "model": model,
            "provider": "openai",
            "tokens_input": tokens_input,
            "tokens_output": tokens_output,
            "tokens_cache_read": tokens_cache_read,
            "tokens_cache_write": tokens_cache_write,
            "baseline_tokens_input": baseline_input or tokens_input,
            "baseline_tokens_output": baseline_output or tokens_output,
            "rate_snapshot": rate.rate_snapshot(),
        },
    )
    output_ir = provider_output_ir(
        provider="openai",
        response=response,
        run_id=trace.id,
        runtime_source=runtime_source,
    )
    shelf.register_output_context(output_ir)
    trace.record_output(
        {
            "provider": "openai",
            "model": model,
            "response_id": _response_get(response, "id"),
            "latency_ms": latency_ms,
            "input_tokens": tokens_input,
            "output_tokens": tokens_output,
            "total_tokens": total_tokens,
            "finish_reason": finish_reason,
            "cache_read": tokens_cache_read,
            "context_ir": output_ir.model_dump(mode="json"),
        }
    )


def _chat_call(shelf: Any, kwargs: dict[str, Any], runtime_source: dict[str, Any] | None) -> ProviderCall:
    model = kwargs.get("model", "unknown")
    system = kwargs.get("system")
    messages = kwargs.get("messages") or []
    system, messages, tools, experiment = shelf.apply_experiment_overrides(
        system=system,
        messages=messages,
        tools=kwargs.get("tools"),
    )
    kwargs["messages"] = messages
    if system is not None or "system" in kwargs:
        kwargs["system"] = system
    if tools is not None or "tools" in kwargs:
        kwargs["tools"] = tools
    return ProviderCall(
        shelf,
        name=f"openai_call_{model}",
        provider="openai",
        model=model,
        system=system,
        messages=messages,
        tools=tools,
        experiment=experiment,
        runtime_source=runtime_source,
        record_error=_record_error,
    )


def _wrap_chat_completions(client: Any, shelf) -> Any:
    chat = getattr(client, "chat", None)
    completions = getattr(chat, "completions", None) if chat else None
    if completions is None or not hasattr(completions, "create"):
        return client

    original_create = completions.create

    def traced_create(*args, **kwargs):
        runtime_source = runtime_source_for_call(shelf)
        call = _chat_call(shelf, kwargs, runtime_source)
        try:
            if kwargs.get("stream") is True:
                stream = original_create(*args, **kwargs)
                call.passthrough()
                return stream
            call.start_timer()
            response = original_create(*args, **kwargs)
        except BaseException as exc:
            call.error(exc)
            raise
        call.finish(_record_non_streaming_call, response)
        return response

    async def traced_create_async(*args, **kwargs):
        runtime_source = runtime_source_for_call(shelf)
        call = _chat_call(shelf, kwargs, runtime_source)
        try:
            if kwargs.get("stream") is True:
                stream = await original_create(*args, **kwargs)
                call.passthrough()
                return stream
            call.start_timer()
            response = await original_create(*args, **kwargs)
        except BaseException as exc:
            call.error(exc)
            raise
        call.finish(_record_non_streaming_call, response)
        return response

    completions.create = traced_create_async if inspect.iscoroutinefunction(original_create) else traced_create
    return client


def _responses_messages(value: Any) -> list[Any]:
    """Normalize Responses input without flattening typed output/tool items."""

    if value is None:
        return []
    if isinstance(value, list):
        return value
    return [{"role": "user", "content": value}]


def _record_responses_call(
    shelf: Any,
    trace: Any,
    model: str,
    response: Any,
    baseline_input: int = 0,
    baseline_output: int = 0,
    *,
    latency_ms: int | None,
    runtime_source: dict[str, Any] | None = None,
) -> None:
    del baseline_input, baseline_output
    usage = _response_get(response, "usage")
    tokens_input = _usage_get(usage, "input_tokens")
    tokens_output = _usage_get(usage, "output_tokens")
    input_details = _response_get(usage, "input_tokens_details")
    tokens_cache_read = _usage_get(input_details, "cached_tokens")
    total_tokens = _usage_get(usage, "total_tokens", tokens_input + tokens_output)
    output_ir = provider_output_ir(
        provider="openai.responses",
        response=response,
        run_id=trace.id,
        runtime_source=runtime_source,
    )
    shelf.register_output_context(output_ir)
    shelf.emit_event(
        "llm_call",
        trace_id=trace.id,
        event_fields={
            "model": model,
            "provider": "openai",
            "tokens_input": tokens_input,
            "tokens_output": tokens_output,
            "tokens_cache_read": tokens_cache_read,
            "tokens_cache_write": 0,
            "rate_snapshot": get_rate(model).rate_snapshot(),
        },
    )
    trace.record_output(
        {
            "provider": "openai",
            "api": "responses",
            "model": model,
            "response_id": _response_get(response, "id"),
            "latency_ms": latency_ms,
            "input_tokens": tokens_input,
            "output_tokens": tokens_output,
            "total_tokens": total_tokens,
            "finish_reason": _response_get(response, "status"),
            "cache_read": tokens_cache_read,
            "context_ir": output_ir.model_dump(mode="json"),
        }
    )


def _responses_call(shelf: Any, kwargs: dict[str, Any], runtime_source: dict[str, Any] | None) -> ProviderCall:
    model = str(kwargs.get("model", "unknown"))
    system = kwargs.get("instructions")
    messages = _responses_messages(kwargs.get("input"))
    system, messages, tools, experiment = shelf.apply_experiment_overrides(
        system=system,
        messages=messages,
        tools=kwargs.get("tools"),
    )
    kwargs["input"] = messages
    if system is not None or "instructions" in kwargs:
        kwargs["instructions"] = system
    if tools is not None or "tools" in kwargs:
        kwargs["tools"] = tools
    return ProviderCall(
        shelf,
        name=f"openai_response_{model}",
        provider="openai",
        model=model,
        system=system,
        messages=messages,
        tools=tools,
        experiment=experiment,
        runtime_source=runtime_source,
        metadata={"api": "responses"},
        record_error=_record_error,
    )


def _wrap_responses(client: Any, shelf: Any) -> Any:
    responses = getattr(client, "responses", None)
    if responses is None or not hasattr(responses, "create"):
        return client
    original_create = responses.create

    def traced_create(*args: Any, **kwargs: Any) -> Any:
        runtime_source = runtime_source_for_call(shelf)
        call = _responses_call(shelf, kwargs, runtime_source)
        try:
            if kwargs.get("stream") is True:
                stream = original_create(*args, **kwargs)
                call.passthrough()
                return stream
            call.start_timer()
            response = original_create(*args, **kwargs)
        except BaseException as exc:
            call.error(exc)
            raise
        call.finish(_record_responses_call, response)
        return response

    async def traced_create_async(*args: Any, **kwargs: Any) -> Any:
        runtime_source = runtime_source_for_call(shelf)
        call = _responses_call(shelf, kwargs, runtime_source)
        try:
            if kwargs.get("stream") is True:
                stream = await original_create(*args, **kwargs)
                call.passthrough()
                return stream
            call.start_timer()
            response = await original_create(*args, **kwargs)
        except BaseException as exc:
            call.error(exc)
            raise
        call.finish(_record_responses_call, response)
        return response

    responses.create = traced_create_async if inspect.iscoroutinefunction(original_create) else traced_create
    return client


def wrap_openai_client(client: Any, shelf: Any) -> Any:
    """Instrument both legacy Chat Completions and the current Responses API."""

    _wrap_chat_completions(client, shelf)
    _wrap_responses(client, shelf)
    return client
