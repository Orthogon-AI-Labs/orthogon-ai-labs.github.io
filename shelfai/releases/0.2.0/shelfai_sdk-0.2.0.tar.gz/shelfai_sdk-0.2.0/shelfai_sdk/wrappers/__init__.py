"""Framework wrappers for the ShelfAI SDK."""

from .anthropic import wrap_anthropic_client
from .claude_agent import ShelfAIAdapterCollisionError, ShelfAIIntegration, connect_claude_agent
from .llamaindex import ShelfAILlamaIndexHandler, register_llamaindex_handler
from .openai import wrap_openai_client

try:  # pragma: no cover - exercised in environments with optional extras
    from .autogen import ShelfAIAutoGenLogHandler, install_autogen_logging, register_shelfai_tracking
except ImportError:  # pragma: no cover
    register_shelfai_tracking = None  # type: ignore[assignment]
    ShelfAIAutoGenLogHandler = None  # type: ignore[assignment]
    install_autogen_logging = None  # type: ignore[assignment]

try:  # pragma: no cover - exercised in environments with optional extras
    from .crewai import ShelfAICrew
except ImportError:  # pragma: no cover
    ShelfAICrew = None  # type: ignore[assignment]

try:  # pragma: no cover - exercised in environments with optional extras
    from .crewai_listener import ShelfAICrewListener, register_crewai_listener
except ImportError:  # pragma: no cover
    ShelfAICrewListener = None  # type: ignore[assignment]
    register_crewai_listener = None  # type: ignore[assignment]

try:  # pragma: no cover - exercised in environments with optional extras
    from .langchain import ShelfAICallbackHandler
except ImportError:  # pragma: no cover
    ShelfAICallbackHandler = None  # type: ignore[assignment]

try:  # pragma: no cover - exercised in environments with optional extras
    from .langgraph import wrap_graph
except ImportError:  # pragma: no cover
    wrap_graph = None  # type: ignore[assignment]

__all__ = [
    "wrap_anthropic_client",
    "wrap_openai_client",
    "register_shelfai_tracking",
    "ShelfAIAutoGenLogHandler",
    "install_autogen_logging",
    "ShelfAIIntegration",
    "ShelfAIAdapterCollisionError",
    "connect_claude_agent",
    "ShelfAICrew",
    "ShelfAICrewListener",
    "register_crewai_listener",
    "ShelfAICallbackHandler",
    "wrap_graph",
    "ShelfAILlamaIndexHandler",
    "register_llamaindex_handler",
]
