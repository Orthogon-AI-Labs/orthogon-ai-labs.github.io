"""LangGraph helpers for the ShelfAI SDK."""

from __future__ import annotations

from typing import Any, Optional

from .langchain import ShelfAICallbackHandler


def wrap_graph(graph: Any, handler: Optional[ShelfAICallbackHandler] = None) -> Any:
    """Compile a StateGraph if needed and attach the ShelfAI callback handler.

    If no handler is provided, a ShelfAI-backed handler is created from the
    default SDK configuration / environment variables.
    """
    candidate = graph
    if not hasattr(candidate, "with_config"):
        if not hasattr(candidate, "compile"):
            raise TypeError("wrap_graph() expected a LangGraph StateGraph or compiled graph.")
        candidate = candidate.compile()

    if handler is None:
        from ..client import ShelfAI

        try:
            handler = ShelfAICallbackHandler(ShelfAI())
        except ValueError as exc:
            raise ValueError(
                "wrap_graph(graph) requires SHELFAI_API_KEY and SHELFAI_AGENT_ID "
                "in the environment, or an explicit ShelfAICallbackHandler."
            ) from exc

    return candidate.with_config({"callbacks": [handler]})
