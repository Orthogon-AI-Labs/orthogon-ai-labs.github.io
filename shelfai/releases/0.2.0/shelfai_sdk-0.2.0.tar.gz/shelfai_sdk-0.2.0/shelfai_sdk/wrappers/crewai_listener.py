"""Public CrewAI event-bus integration.

This is the preferred CrewAI adapter.  The older ``ShelfAICrew`` subclass is
kept as a compatibility shim for pre-1.0 projects.
"""

from __future__ import annotations

from typing import Any, Callable

try:
    import crewai.events as crewai_events
    from crewai.events import BaseEventListener
except ImportError as exc:  # pragma: no cover - optional dependency
    raise ImportError(
        "ShelfAI CrewAI integration requires CrewAI 1.x. "
        'Install with `pip install "shelfai-sdk[crewai]"`.'
    ) from exc

from ..context_ir import ContextIR, context_item, provider_input_ir, provider_output_ir
from ..runtime_source import attach_runtime_source_evidence, capture_runtime_source_evidence


def _runtime_source(shelf: Any) -> dict[str, Any] | None:
    try:
        return capture_runtime_source_evidence(
            enabled=getattr(shelf, "runtime_source_evidence", True)
        )
    except Exception:
        return None


def _payload(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        data = value.model_dump(mode="json")
    elif hasattr(value, "dict"):
        data = value.dict()
    elif hasattr(value, "__dict__"):
        data = {key: item for key, item in vars(value).items() if not key.startswith("_")}
    else:
        data = {"value": str(value)}
    return data if isinstance(data, dict) else {"value": data}


def _first(data: dict[str, Any], *keys: str) -> Any:
    for key in keys:
        if data.get(key) is not None:
            return data[key]
    return None


class ShelfAICrewListener(BaseEventListener):
    """Translate CrewAI's supported public events into ShelfAI Run Graph data."""

    def __init__(self, shelf: Any):
        self.shelf = shelf
        self._run_ids: dict[str, str] = {}
        self._event_runs: dict[str, str] = {}
        self._last_run_id: str | None = None
        super().__init__()

    def _source_key(self, source: Any, data: dict[str, Any]) -> str:
        identity = _first(data, "crew_id", "flow_id", "execution_id", "source_fingerprint")
        if identity is None:
            identity = getattr(source, "id", None) or id(source)
        return str(identity)

    def _trace_id(self, source: Any, data: dict[str, Any], *, begin: bool = False) -> str:
        key = self._source_key(source, data)
        trace_id: str | None = None
        if begin:
            trace_id = self.shelf.generate_trace_id()
        else:
            for lineage_key in ("started_event_id", "parent_event_id", "triggered_by_event_id", "previous_event_id"):
                event_id = data.get(lineage_key)
                if event_id is not None and str(event_id) in self._event_runs:
                    trace_id = self._event_runs[str(event_id)]
                    break
            trace_id = trace_id or self._run_ids.get(key) or self._last_run_id
        if trace_id is None:
            trace_id = self.shelf.generate_trace_id()
        self._run_ids[key] = trace_id
        if data.get("event_id") is not None:
            self._event_runs[str(data["event_id"])] = trace_id
        self._last_run_id = trace_id
        return trace_id

    def _metadata(self, hook: str, data: dict[str, Any], ir: ContextIR | None = None) -> dict[str, Any]:
        metadata = {
            "framework": "crewai",
            "hook": hook,
            "agent_role": _first(data, "agent_role", "role"),
            "task_id": _first(data, "task_id", "id"),
            "tool_name": _first(data, "tool_name", "name"),
            "model": _first(data, "model", "model_name"),
            "framework_event": data,
        }
        if ir is not None:
            ir = attach_runtime_source_evidence(
                ir,
                _runtime_source(self.shelf),
            )
            metadata["context_ir"] = ir.model_dump(mode="json")
        return metadata

    def _register(self, bus: Any, event_name: str, handler: Callable[[Any, Any], None]) -> None:
        event_type = getattr(crewai_events, event_name, None)
        if event_type is not None:
            bus.on(event_type)(handler)

    def setup_listeners(self, crewai_event_bus: Any) -> None:
        def crew_started(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data, begin=True)
            inputs = _first(data, "inputs", "input")
            ir = ContextIR(items=[context_item("state_snapshot", inputs, run_id=trace_id, source="crewai.inputs")]) if inputs is not None else None
            self.shelf.emit_event("session_start", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        def crew_finished(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            self.shelf.emit_event("session_end", self._metadata(type(event).__name__, data), trace_id=trace_id)

        def task_started(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            description = _first(data, "task_prompt", "context", "task_description", "description", "prompt")
            if description is None and isinstance(data.get("task"), dict):
                description = _first(data["task"], "description", "name")
            ir = ContextIR(items=[context_item("instruction", description, run_id=trace_id, source="crewai.task")]) if description is not None else None
            self.shelf.emit_event("task_assigned", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        def task_finished(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            output = _first(data, "output", "result")
            ir = ContextIR(items=[context_item("artifact", output, run_id=trace_id, source="crewai.task.output", selection="produced")]) if output is not None else None
            self.shelf.emit_event("task_updated", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        def llm_started(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            ir = provider_input_ir(
                provider="crewai",
                system=_first(data, "system", "system_prompt"),
                messages=_first(data, "messages", "input") or [],
                tools=data.get("tools"),
                run_id=trace_id,
            )
            self.shelf.emit_event("trace_started", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        def llm_finished(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            response = _first(data, "response", "output", "result")
            ir = provider_output_ir(provider="crewai", response=response, run_id=trace_id)
            self.shelf.emit_event("trace_finished", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        def tool_started(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            call = {"name": _first(data, "tool_name", "name"), "input": _first(data, "tool_args", "input", "arguments")}
            ir = ContextIR(items=[context_item("tool_call", call, run_id=trace_id, source="crewai.tool")])
            self.shelf.emit_event("tool_start", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        def tool_finished(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            result = _first(data, "output", "result")
            ir = ContextIR(items=[context_item("tool_result", result, run_id=trace_id, source="crewai.tool.result", selection="produced")])
            self.shelf.emit_event("tool_end", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        def human_feedback(source: Any, event: Any) -> None:
            data = _payload(event)
            trace_id = self._trace_id(source, data)
            feedback = _first(data, "feedback", "response", "output")
            ir = ContextIR(items=[context_item("human_decision", feedback, run_id=trace_id, source="crewai.human", selection="produced")])
            self.shelf.emit_event("human_decision", self._metadata(type(event).__name__, data, ir), trace_id=trace_id)

        for name in ("CrewKickoffStartedEvent", "FlowStartedEvent"):
            self._register(crewai_event_bus, name, crew_started)
        for name in ("CrewKickoffCompletedEvent", "CrewKickoffFailedEvent", "FlowFinishedEvent", "FlowFailedEvent"):
            self._register(crewai_event_bus, name, crew_finished)
        for name in ("TaskStartedEvent", "AgentExecutionStartedEvent"):
            self._register(crewai_event_bus, name, task_started)
        for name in ("TaskCompletedEvent", "TaskFailedEvent", "AgentExecutionCompletedEvent", "AgentExecutionErrorEvent"):
            self._register(crewai_event_bus, name, task_finished)
        self._register(crewai_event_bus, "LLMCallStartedEvent", llm_started)
        for name in ("LLMCallCompletedEvent", "LLMCallFailedEvent"):
            self._register(crewai_event_bus, name, llm_finished)
        self._register(crewai_event_bus, "ToolUsageStartedEvent", tool_started)
        for name in ("ToolUsageFinishedEvent", "ToolUsageErrorEvent", "ToolExecutionErrorEvent"):
            self._register(crewai_event_bus, name, tool_finished)
        self._register(crewai_event_bus, "HumanFeedbackReceivedEvent", human_feedback)


def register_crewai_listener(shelf: Any) -> ShelfAICrewListener:
    """One-line CrewAI installation; keep the returned listener alive."""

    return ShelfAICrewListener(shelf)
