"""Launch capture-mode helpers for the public ShelfAI trust boundary."""

from __future__ import annotations

import copy
import re
from typing import Any

LAUNCH_CAPTURE_MODES = {"metadata_only", "full"}
DEFAULT_CAPTURE_MODE = "metadata_only"
LEGACY_CAPTURE_MODE_ALIASES = {"local_only"}

_EMAIL_RE = re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.IGNORECASE)
_PHONE_RE = re.compile(r"(?<!\w)(?:\+?1[-.\s]?)?(?:\(?\d{3}\)?[-.\s]?){2}\d{4}(?!\w)")
_SSN_RE = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")
_CARD_RE = re.compile(r"\b(?:\d[ -]*?){13,19}\b")
_JWT_RE = re.compile(r"\beyJ[A-Za-z0-9_-]+\.[A-Za-z0-9._-]+\.[A-Za-z0-9._-]+\b")
_API_KEY_RE = re.compile(
    r"\b(?:sk_[A-Za-z0-9_-]{8,}|sk-[A-Za-z0-9_-]{8,}|AIza[0-9A-Za-z_-]{20,}"
    r"|(?:AKIA|ASIA)[0-9A-Z]{16}|xox[abprs]-[A-Za-z0-9-]{10,}"
    r"|(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"
)
_PEM_RE = re.compile(r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*?-----END [A-Z0-9 ]*PRIVATE KEY-----", re.DOTALL)
_PEM_OPEN_RE = re.compile(r"-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----.*", re.DOTALL)
_AUTH_HEADER_RE = re.compile(r"\b(Bearer|Basic|Token)\s+([A-Za-z0-9._~+/=-]{8,})")
_ASSIGNMENT_RE = re.compile(
    r"\b((?:api[_-]?key|access[_-]?key|secret[_-]?key|client[_-]?secret|private[_-]?key"
    r"|passw(?:or)?d|passphrase|secret|token|auth(?:orization)?)\s*[:=]\s*[\"']?)([^\s\"',;]{4,})",
    re.IGNORECASE,
)
_BASE64_SECRET_RE = re.compile(r"\b[A-Za-z0-9+/=_-]{32,}\b")
_HUMAN_SLUG_RE = re.compile(r"[a-z0-9]+(?:-[a-z0-9]+){2,}")
_WINDOWS_DRIVE_RE = re.compile(r"^[A-Za-z]:[/\\]")
_MATERIALIZATION_SYMBOL_RE = re.compile(r"[A-Za-z_$<][A-Za-z0-9_$.:#<>-]{0,255}")
_RUNTIME_RE = re.compile(r"(?:CPython|PyPy|Python) [0-9]+\.[0-9]+(?:\.[0-9]+)?")
_HEX_REVISION_RE = re.compile(r"[0-9a-f]{7,64}", re.IGNORECASE)
_REPLAY_SESSION_ID_RE = re.compile(r"rps_[0-9a-f]{24}")
_REPLAY_TARGET_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}")
_EXPERIMENT_ID_RE = re.compile(r"exp_[0-9a-f]{32}")
_PATCH_ID_RE = re.compile(r"patch(?:-[0-9]{1,6}|_[0-9a-f]{32})")
_STRUCTURAL_ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,190}")
_PREFIXED_ID_RE = re.compile(
    r"(?:evt|trace|run|ctx|call|msg|tool|toolu|chunk|agent|handoff|artifact|span|session|exp|patch|rps|chatcmpl|resp)[-_:][A-Za-z0-9._:-]{1,190}",
    re.IGNORECASE,
)
_UUID_RE = re.compile(r"(?:[a-f0-9]{32}|[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12})", re.IGNORECASE)
# Identifier keys whose canonical shapes must survive the broad base64 heuristic.
_STRUCTURAL_ID_KEYS = {
    "event_id",
    "session_id",
    "trace_id",
    "run_id",
    "parent_ids",
    "chunk_ids",
    "call_id",
    "id",
    "item_id",
    "patch_id",
    "experiment_id",
    "baseline_trace_id",
    "applied_patch_ids",
    "replay_session_id",
    "response_id",
    "tool_use_id",
    "tool_call_id",
}
MATERIALIZATION_TRUTH_VALUES = {"declared", "inferred", "confirmed"}

# Keys whose string values are structural labels rather than captured content.
# They are honored only OUTSIDE captured content subtrees (see
# _CONTENT_ROOT_KEYS); inside provider payloads the same key names are data.
_PRESERVED_STRING_KEYS = {
    "task_type",
    "severity",
    "role",
    "source",
    "name",
    "provider",
    "api",
    "version",
    "type",
    "selection",
    "stage",
    "contextRole",
    "context_role",
    "handoffName",
    "handoff_name",
    "lineageDetection",
    "lineage_detection",
    "actions",
    "parentIds",
    "parent_ids",
    "itemId",
    "item_id",
    "chunk_ids",
    "id",
    "agent_id",
    "trace_id",
    "timestamp",
    "session_id",
    "tool_use_id",
    "reason",
    "framework",
    "hook",
    "adapter_version",
    "kind",
    "model",
    "response_id",
    "stop_reason",
    "finish_reason",
    "error_type",
    "chain_type",
    "node_name",
    "run_id",
    "parent_run_id",
    "tool_name",
    "from_node",
    "to_node",
    "crew_id",
    "task_id",
    "agent_role",
    "message_kind",
    "sender",
    "receiver",
    "status",
    "state_snapshot_keys",
    "state_delta_keys",
    "agent_roles",
}

# Any subtree under these keys is captured application/provider content. In
# metadata-only mode every string inside it is redacted except a few provider
# block labels, so a tool argument called "name" or "reason" can never leak.
_CONTENT_ROOT_KEYS = {
    "raw_payload",
    "input",
    "inputs",
    "arguments",
    "content",
    "text",
    "messages",
    "message",
    "system",
    "system_prompt",
    "instructions",
    "prompt",
    "prompts",
    "tool_outputs",
    "retrieved_chunks",
    "generations",
    "response_text",
    "output_text",
    "outputs",
    "result",
    "results",
    "state_snapshot",
    "state_delta",
    "delta",
    "error_message",
    "rendered_preview",
}
_CONTENT_STRUCTURAL_KEYS = {"type", "role", "tool_use_id", "tool_call_id", "call_id", "stop_reason", "finish_reason"}
_TOOL_SHAPE_KEYS = {"arguments", "input", "parameters", "input_schema", "function", "tool_calls"}
_STRUCTURAL_CONTAINER_KEYS = {"retrieved_chunks", "tool_calls", "tool_outputs", "chunks"}
_KNOWN_BLOCK_TYPES = {
    "text",
    "message",
    "tool_use",
    "tool_result",
    "tool_call",
    "function",
    "function_call",
    "function_call_output",
    "image",
    "input_text",
    "output_text",
    "reasoning",
}
_NAMED_PROVIDER_BLOCK_TYPES = {"tool_use", "tool_call", "function", "function_call"}
_ROLE_VALUES = {"system", "developer", "user", "assistant", "tool"}
_STOP_REASON_VALUES = {
    "end_turn", "max_tokens", "stop_sequence", "tool_use", "content_filter",
    "length", "function_call", "stop",
}
_TIMESTAMP_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:\d{2})")
_MODEL_RE = re.compile(r"(?:gpt(?:-[A-Za-z0-9.]+)?|chatgpt-[A-Za-z0-9.-]+|o[1-9](?:-[A-Za-z0-9.-]+)?|claude(?:-[A-Za-z0-9.-]+)?|gemini(?:-[A-Za-z0-9.-]+)?|llama(?:-[A-Za-z0-9.-]+)?|mistral(?:-[A-Za-z0-9.-]+)?|command(?:-[A-Za-z0-9.-]+)?)", re.IGNORECASE)
_OUTER_ENUM_VALUES = {
    "framework": {"autogen", "claude_agent_sdk", "crewai", "langchain", "langgraph", "llamaindex", "openai", "anthropic"},
    "provider": {"openai", "anthropic", "azure_openai", "bedrock", "google", "cohere", "mistral"},
    "api": {"chat.completions", "responses", "messages"},
    "severity": {"debug", "info", "warning", "error", "critical"},
    "status": {"active", "completed", "failed", "pending", "queued", "running", "replayed", "verified", "disabled"},
    "selection": {"selected", "available", "excluded", "produced", "unknown"},
    "contextRole": {"system", "instruction", "message", "memory", "retrieved_evidence", "tool", "handoff", "output"},
    "context_role": {"system", "instruction", "message", "memory", "retrieved_evidence", "tool", "handoff", "output"},
    "kind": {"repo_file", "source_code", "config", "ephemeral", "upstream_output", "runtime_assembly", "llm", "chain", "agent", "tool"},
    "lineageDetection": {"automatic_exact", "automatic_contained_text", "declared"},
    "lineage_detection": {"automatic_exact", "automatic_contained_text", "declared"},
    "task_type": {"chat", "completion", "tool", "agent", "retrieval", "planning", "writer", "support"},
    "type": _KNOWN_BLOCK_TYPES | {"instruction", "memory", "retrieved_evidence", "tool_definition", "artifact", "state_snapshot", "handoff", "policy", "goal", "human_decision", "compaction", "transformation"},
}
_OUTER_ACTION_VALUES = {"experiment_here", "fix_at_source", "give_feedback"}


def _safe_structural_value(key: str | None, value: str) -> bool:
    """Accept only enumerated labels and identifier-shaped structural values.

    Keys such as ``name`` and ``role`` occur in customer JSON too, so being a
    structural *key* is insufficient: a prose value must not survive capture.
    """
    if not value or "[REDACTED_" in value or _contains_explicit_secret(value):
        return False
    if key == "role":
        return value in _ROLE_VALUES
    if key == "version":
        return value == "1.0"
    if key in {"stop_reason", "finish_reason"}:
        return value in _STOP_REASON_VALUES
    if key in _STRUCTURAL_ID_KEYS:
        return _PREFIXED_ID_RE.fullmatch(value) is not None or _UUID_RE.fullmatch(value) is not None
    if key in _OUTER_ENUM_VALUES:
        return value in _OUTER_ENUM_VALUES[key]
    if key == "actions":
        return value in _OUTER_ACTION_VALUES
    if key == "timestamp":
        return _TIMESTAMP_RE.fullmatch(value) is not None
    if key == "model":
        return _MODEL_RE.fullmatch(value) is not None
    if key == "error_type":
        return value.endswith(("Error", "Exception")) and value.isidentifier()
    # Values such as name, sender, receiver, source, reason, model, and tool
    # labels are customer-controlled unless a schema provides an enum above.
    return False


def _safe_provider_block_name(value: str) -> bool:
    """Tool/function names survive only inside a validated provider block."""

    return re.fullmatch(r"[A-Za-z_][A-Za-z0-9_.-]{0,127}", value) is not None


def normalize_capture_mode(value: str | None) -> str:
    """Normalize a requested capture mode into the supported launch contract."""
    raw = (value or "").strip().lower()
    if raw in LAUNCH_CAPTURE_MODES:
        return raw
    if raw in LEGACY_CAPTURE_MODE_ALIASES:
        return DEFAULT_CAPTURE_MODE
    return DEFAULT_CAPTURE_MODE


def sanitize_event_for_capture_mode(event: dict[str, Any], capture_mode: str | None) -> dict[str, Any]:
    """Return a sanitized event payload for the requested launch capture mode."""
    normalized_mode = normalize_capture_mode(capture_mode)
    sanitized = _scrub_value(copy.deepcopy(event))
    if normalized_mode == "metadata_only":
        sanitized["metadata"] = _strip_text_values(sanitized.get("metadata", {}))
    return sanitized


def sanitize_payload_for_capture_mode(payload: dict[str, Any], capture_mode: str | None) -> dict[str, Any]:
    """Return a sanitized non-event payload such as a heartbeat body."""
    normalized_mode = normalize_capture_mode(capture_mode)
    sanitized = _scrub_value(copy.deepcopy(payload))
    if normalized_mode == "metadata_only":
        return _strip_text_values(sanitized)
    return sanitized


def _contains_explicit_secret(value: str) -> bool:
    return any(
        pattern.search(value)
        for pattern in (
            _PEM_OPEN_RE,
            _AUTH_HEADER_RE,
            _ASSIGNMENT_RE,
            _EMAIL_RE,
            _PHONE_RE,
            _SSN_RE,
            _CARD_RE,
            _JWT_RE,
            _API_KEY_RE,
        )
    )


def _scrub_value(
    value: Any,
    *,
    key: str | None = None,
    parent_key: str | None = None,
    inside_runtime_source: bool = False,
) -> Any:
    if isinstance(value, dict):
        nested_runtime_source = inside_runtime_source or key == "runtime_source"
        return {
            str(item_key): _scrub_value(
                item,
                key=str(item_key),
                parent_key=key,
                inside_runtime_source=nested_runtime_source,
            )
            for item_key, item in value.items()
        }
    if isinstance(value, list):
        return [
            _scrub_value(
                item,
                key=key,
                parent_key=parent_key,
                inside_runtime_source=inside_runtime_source,
            )
            for item in value
        ]
    if isinstance(value, str):
        # Trace-graph identifiers are routing metadata; keep only canonical
        # shapes on explicitly structural keys. Known secret formats still win.
        if (
            key in _STRUCTURAL_ID_KEYS
            and not _API_KEY_RE.search(value)
            and not _JWT_RE.search(value)
            and (_PREFIXED_ID_RE.fullmatch(value) or _UUID_RE.fullmatch(value))
        ):
            return value
        # Long source symbols can resemble opaque base64 tokens. Only bypass
        # that broad heuristic for a validated materialization locator; known
        # secret and PII shapes still win.
        if (
            parent_key == "materialization"
            and _safe_materialization_value(key, value)
            and not _contains_explicit_secret(value)
        ):
            return value
        if (
            inside_runtime_source
            and _safe_runtime_source_value(key, value)
            and not _contains_explicit_secret(value)
        ):
            return value
        return _scrub_text(value)
    return value


def _scrub_text(value: str) -> str:
    scrubbed = _PEM_RE.sub("[REDACTED_SECRET]", value)
    scrubbed = _PEM_OPEN_RE.sub("[REDACTED_SECRET]", scrubbed)
    scrubbed = _AUTH_HEADER_RE.sub(r"\1 [REDACTED_SECRET]", scrubbed)
    scrubbed = _ASSIGNMENT_RE.sub(r"\1[REDACTED_SECRET]", scrubbed)
    replacements = (
        (_API_KEY_RE, "[REDACTED_SECRET]"),
        (_JWT_RE, "[REDACTED_JWT]"),
        (_EMAIL_RE, "[REDACTED_EMAIL]"),
        (_PHONE_RE, "[REDACTED_PHONE]"),
        (_SSN_RE, "[REDACTED_SSN]"),
        (_CARD_RE, "[REDACTED_CARD]"),
    )
    for pattern, replacement in replacements:
        scrubbed = pattern.sub(replacement, scrubbed)
    scrubbed = _BASE64_SECRET_RE.sub(
        lambda match: match.group(0) if _HUMAN_SLUG_RE.fullmatch(match.group(0)) else "[REDACTED_SECRET]",
        scrubbed,
    )
    return scrubbed


def _safe_materialization_value(key: str | None, value: str) -> bool:
    """Allow only non-secret source locators that are safe to leave as metadata."""

    if not value or "[REDACTED_" in value or any(ord(character) < 32 or ord(character) == 127 for character in value):
        return False
    if key == "path":
        if len(value) > 512 or value.startswith(("/", "\\", "~")) or "\\" in value or "://" in value:
            return False
        if _WINDOWS_DRIVE_RE.match(value):
            return False
        return all(segment not in {"", ".", ".."} for segment in value.split("/"))
    if key == "symbol":
        return _MATERIALIZATION_SYMBOL_RE.fullmatch(value) is not None
    if key == "truth":
        return value in MATERIALIZATION_TRUTH_VALUES
    return False


def _strip_text_values(
    value: Any,
    *,
    key: str | None = None,
    parent_key: str | None = None,
    inside_runtime_source: bool = False,
    inside_content: bool = False,
    structural_block: bool = False,
) -> Any:
    if isinstance(value, dict):
        nested_runtime_source = inside_runtime_source or key == "runtime_source"
        nested_content = inside_content or (key in _CONTENT_ROOT_KEYS and not nested_runtime_source)
        block = False
        if nested_content:
            block_type = value.get("type")
            block = (
                key in _STRUCTURAL_CONTAINER_KEYS
                or any(marker in value for marker in _TOOL_SHAPE_KEYS)
                or (isinstance(block_type, str) and block_type in _NAMED_PROVIDER_BLOCK_TYPES)
            )
        return {
            str(item_key): _strip_text_values(
                item,
                key=str(item_key),
                parent_key=key,
                inside_runtime_source=nested_runtime_source,
                inside_content=nested_content,
                structural_block=block,
            )
            for item_key, item in value.items()
        }
    if isinstance(value, list):
        nested_content = inside_content or (key in _CONTENT_ROOT_KEYS and not inside_runtime_source)
        return [
            _strip_text_values(
                item,
                key=key,
                parent_key=parent_key,
                inside_runtime_source=inside_runtime_source,
                inside_content=nested_content,
                structural_block=structural_block,
            )
            for item in value
        ]
    if isinstance(value, str):
        if inside_runtime_source:
            return value if _safe_runtime_source_value(key, value) else "[REDACTED_TEXT]"
        if key == "replay_session_id":
            return value if _REPLAY_SESSION_ID_RE.fullmatch(value) else "[REDACTED_TEXT]"
        if key == "replay_target":
            return value if _REPLAY_TARGET_RE.fullmatch(value) else "[REDACTED_TEXT]"
        if key == "experiment_id":
            return value if _EXPERIMENT_ID_RE.fullmatch(value) else "[REDACTED_TEXT]"
        if key == "applied_patch_ids":
            return value if _PATCH_ID_RE.fullmatch(value) else "[REDACTED_TEXT]"
        if key == "baseline_trace_id":
            return value if _STRUCTURAL_ID_RE.fullmatch(value) else "[REDACTED_TEXT]"
        if inside_content:
            if key in _CONTENT_STRUCTURAL_KEYS and _safe_structural_value(key, value):
                return value
            if key == "id" and structural_block and _safe_structural_value(key, value):
                return value
            if key == "name" and structural_block and _safe_provider_block_name(value):
                return value
            if (
                key == "source"
                and structural_block
                and parent_key in _STRUCTURAL_CONTAINER_KEYS
                and _safe_structural_value(key, value)
            ):
                return value
            return "[REDACTED_TEXT]"
        if key and key in _PRESERVED_STRING_KEYS and _safe_structural_value(key, value):
            return value
        if parent_key == "materialization" and _safe_materialization_value(key, value):
            return value
        return "[REDACTED_TEXT]"
    return value


def _safe_runtime_source_value(key: str | None, value: str) -> bool:
    """Preserve only validated structural source evidence in metadata-only mode."""

    if not value or "[REDACTED_" in value:
        return False
    if key == "path":
        return _safe_materialization_value("path", value)
    if key == "symbol":
        return _safe_materialization_value("symbol", value)
    if key == "truth":
        return value == "observed"
    if key == "version":
        return value == "1.0"
    if key == "language":
        return value == "python"
    if key == "runtime":
        return _RUNTIME_RE.fullmatch(value) is not None
    if key == "git_revision":
        return _HEX_REVISION_RE.fullmatch(value) is not None
    if key == "fingerprint":
        return len(value) == 64 and _HEX_REVISION_RE.fullmatch(value) is not None
    return False
