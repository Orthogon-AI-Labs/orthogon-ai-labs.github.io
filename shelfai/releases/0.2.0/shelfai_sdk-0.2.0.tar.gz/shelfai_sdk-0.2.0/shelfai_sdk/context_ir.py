"""Provider-neutral Context IR v1 for observable agent context."""

from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from typing import Any, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field


CONTEXT_IR_VERSION = "1.0"

ContextItemType = Literal[
    "instruction",
    "message",
    "memory",
    "retrieved_evidence",
    "tool_definition",
    "tool_call",
    "tool_result",
    "artifact",
    "state_snapshot",
    "handoff",
    "policy",
    "goal",
    "human_decision",
    "compaction",
    "transformation",
]

SelectionState = Literal["selected", "available", "excluded", "produced", "unknown"]


class ContextIRItem(BaseModel):
    """One typed, causally attributable unit of agent context."""

    model_config = ConfigDict(extra="allow")

    id: str
    type: ContextItemType
    raw_payload: Any = None
    rendered_preview: Optional[str] = None
    parent_ids: list[str] = Field(default_factory=list)
    run_id: Optional[str] = None
    stage: Optional[str] = None
    source: Optional[str] = None
    source_hash: Optional[str] = None
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    token_estimate: Optional[int] = None
    selection: SelectionState = "unknown"
    origin: dict[str, Any] = Field(default_factory=dict)
    materialization: dict[str, Any] = Field(default_factory=dict)
    runtime_source: Optional[dict[str, Any]] = None
    actions: list[str] = Field(default_factory=list)
    provenance: dict[str, Any] = Field(default_factory=dict)
    permissions: dict[str, Any] = Field(default_factory=dict)
    side_effects: dict[str, Any] = Field(default_factory=dict)
    redaction: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)


class ContextIR(BaseModel):
    """A versioned provider-neutral envelope carried by snapshots and outputs."""

    model_config = ConfigDict(extra="allow")

    version: Literal["1.0"] = CONTEXT_IR_VERSION
    items: list[ContextIRItem] = Field(default_factory=list)


_MAX_JSONABLE_DEPTH = 64


def _jsonable(value: Any, _seen: set[int] | None = None, _depth: int = 0) -> Any:
    """Convert provider payloads to JSON without ever recursing forever.

    Customer objects can carry back-references (ORM rows, tree nodes, framework
    messages). A cycle or a pathological depth yields a placeholder instead of
    a ``RecursionError`` inside the customer's provider call.
    """

    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if _depth > _MAX_JSONABLE_DEPTH:
        return "<max-depth>"
    seen = _seen if _seen is not None else set()
    marker = id(value)
    if marker in seen:
        return "<cycle>"
    seen.add(marker)
    try:
        if isinstance(value, dict):
            return {str(key): _jsonable(item, seen, _depth + 1) for key, item in value.items()}
        if isinstance(value, (list, tuple)):
            return [_jsonable(item, seen, _depth + 1) for item in value]
        model_dump = getattr(value, "model_dump", None)
        if callable(model_dump):
            return _jsonable(model_dump(mode="json"), seen, _depth + 1)
        to_dict = getattr(value, "to_dict", None)
        if callable(to_dict):
            return _jsonable(to_dict(), seen, _depth + 1)
        if hasattr(value, "__dict__"):
            return _jsonable(vars(value), seen, _depth + 1)
        return str(value)
    finally:
        seen.discard(marker)


def context_payload_hash(value: Any) -> str:
    encoded = json.dumps(_jsonable(value), sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def context_payload_hashes(value: Any) -> set[str]:
    """Return fingerprints for a value and its nested context-bearing parts."""

    payload = _jsonable(value)
    hashes = {context_payload_hash(payload)}
    if isinstance(payload, dict):
        for item in payload.values():
            hashes.update(context_payload_hashes(item))
    elif isinstance(payload, list):
        for item in payload:
            hashes.update(context_payload_hashes(item))
    return hashes


def context_text_fragments(value: Any, *, minimum_length: int = 32) -> set[str]:
    """Return meaningful normalized text leaves for conservative lineage matching.

    Runtime handoff inference deliberately ignores short provider labels such as
    ``text`` and ``assistant``.  A prior model output must appear as a substantial
    text fragment in a later input before the SDK creates an automatic edge.
    """

    payload = _jsonable(value)
    fragments: set[str] = set()

    def visit(candidate: Any) -> None:
        if isinstance(candidate, str):
            normalized = " ".join(candidate.split()).strip()
            word_count = sum(
                1
                for part in normalized.split()
                if any(character.isalnum() for character in part)
            )
            if len(normalized) >= minimum_length and word_count >= 4:
                fragments.add(normalized)
            return
        if isinstance(candidate, dict):
            for item in candidate.values():
                visit(item)
            return
        if isinstance(candidate, list):
            for item in candidate:
                visit(item)

    visit(payload)
    return fragments


def _preview(value: Any, *, limit: int = 240) -> str:
    payload = _jsonable(value)
    if isinstance(payload, str):
        text = payload
    elif isinstance(payload, dict):
        text_parts: list[str] = []
        for key in ("text", "content", "name", "title", "output", "result"):
            candidate = payload.get(key)
            if isinstance(candidate, str):
                text_parts.append(candidate)
        text = " · ".join(text_parts) or json.dumps(payload, sort_keys=True, ensure_ascii=False)
    else:
        text = json.dumps(payload, sort_keys=True, ensure_ascii=False)
    normalized = " ".join(text.split())
    return normalized if len(normalized) <= limit else f"{normalized[: limit - 1]}…"


def context_item(
    item_type: ContextItemType,
    raw_payload: Any,
    *,
    ordinal: int = 0,
    run_id: Optional[str] = None,
    stage: Optional[str] = None,
    source: Optional[str] = None,
    parent_ids: Optional[list[str]] = None,
    selection: SelectionState = "selected",
    provenance: Optional[dict[str, Any]] = None,
    origin: Optional[dict[str, Any]] = None,
    materialization: Optional[dict[str, Any]] = None,
    permissions: Optional[dict[str, Any]] = None,
    side_effects: Optional[dict[str, Any]] = None,
    metadata: Optional[dict[str, Any]] = None,
) -> ContextIRItem:
    payload = _jsonable(raw_payload)
    source_hash = context_payload_hash(payload)
    identity = context_payload_hash({"type": item_type, "source_hash": source_hash, "ordinal": ordinal, "run_id": run_id})
    return ContextIRItem(
        id=f"ctx_{identity[:24]}",
        type=item_type,
        raw_payload=payload,
        rendered_preview=_preview(payload),
        parent_ids=parent_ids or [],
        run_id=run_id,
        stage=stage,
        source=source,
        source_hash=source_hash,
        selection=selection,
        origin=origin or {},
        materialization=materialization or {},
        provenance=provenance or {},
        permissions=permissions or {},
        side_effects=side_effects or {},
        metadata=metadata or {},
    )


def _block_type(block: Any) -> str:
    payload = _jsonable(block)
    if not isinstance(payload, dict):
        return ""
    return str(payload.get("type") or payload.get("kind") or "").strip().lower()


def _tool_definitions(tools: Any, *, run_id: Optional[str], stage: Optional[str], provider: str) -> list[ContextIRItem]:
    if not isinstance(tools, (list, tuple)):
        return []
    items: list[ContextIRItem] = []
    for ordinal, tool in enumerate(tools):
        payload = _jsonable(tool)
        function = payload.get("function") if isinstance(payload, dict) and isinstance(payload.get("function"), dict) else payload
        name = function.get("name") if isinstance(function, dict) else None
        items.append(
            context_item(
                "tool_definition",
                payload,
                ordinal=ordinal,
                run_id=run_id,
                stage=stage,
                source=f"{provider}.tools",
                provenance={"provider": provider, "tool_name": name},
                permissions={"declared": True},
            )
        )
    return items


def provider_input_ir(
    *,
    provider: str,
    system: Any = None,
    messages: Any = None,
    tools: Any = None,
    run_id: Optional[str] = None,
    stage: Optional[str] = None,
    runtime_source: Optional[dict[str, Any]] = None,
) -> ContextIR:
    """Parse provider request payloads without flattening structured blocks."""

    items: list[ContextIRItem] = []
    if system is not None:
        blocks = system if isinstance(system, (list, tuple)) else [system]
        for block in blocks:
            items.append(
                context_item(
                    "instruction",
                    block,
                    ordinal=len(items),
                    run_id=run_id,
                    stage=stage,
                    source=f"{provider}.system",
                    provenance={"provider": provider, "role": "system"},
                )
            )

    for message_index, message in enumerate(messages or []):
        payload = _jsonable(message)
        role = payload.get("role", "user") if isinstance(payload, dict) else "user"
        direct_block_type = _block_type(payload)
        direct_item_type: ContextItemType = "message"
        if direct_block_type in {"tool_use", "tool_call", "function_call"}:
            direct_item_type = "tool_call"
        elif direct_block_type in {"tool_result", "function_call_output"}:
            direct_item_type = "tool_result"
        message_item = context_item(
            direct_item_type,
            payload,
            ordinal=len(items),
            run_id=run_id,
            stage=stage,
            source=f"{provider}.messages",
            provenance={"provider": provider, "role": role, "message_index": message_index},
        )
        items.append(message_item)
        content = payload.get("content") if isinstance(payload, dict) else None
        blocks = content if isinstance(content, list) else []
        for block in blocks:
            block_payload = _jsonable(block)
            block_type = _block_type(block_payload)
            if block_type in {"tool_use", "tool_call", "function_call"}:
                item_type: ContextItemType = "tool_call"
            elif block_type in {"tool_result", "function_call_output"}:
                item_type = "tool_result"
            else:
                continue
            items.append(
                context_item(
                    item_type,
                    block_payload,
                    ordinal=len(items),
                    run_id=run_id,
                    stage=stage,
                    source=f"{provider}.messages.content",
                    parent_ids=[message_item.id],
                    provenance={"provider": provider, "role": role, "message_index": message_index},
                )
            )

        if isinstance(payload, dict):
            tool_calls = payload.get("tool_calls")
            if isinstance(tool_calls, list):
                for tool_call in tool_calls:
                    items.append(
                        context_item(
                            "tool_call",
                            tool_call,
                            ordinal=len(items),
                            run_id=run_id,
                            stage=stage,
                            source=f"{provider}.messages.tool_calls",
                            parent_ids=[message_item.id],
                            provenance={"provider": provider, "role": role, "message_index": message_index},
                        )
                    )
            function_call = payload.get("function_call")
            if isinstance(function_call, dict):
                items.append(
                    context_item(
                        "tool_call",
                        function_call,
                        ordinal=len(items),
                        run_id=run_id,
                        stage=stage,
                        source=f"{provider}.messages.function_call",
                        parent_ids=[message_item.id],
                        provenance={"provider": provider, "role": role, "message_index": message_index},
                    )
                )
            if role == "tool":
                items.append(
                    context_item(
                        "tool_result",
                        payload,
                        ordinal=len(items),
                        run_id=run_id,
                        stage=stage,
                        source=f"{provider}.messages.tool_result",
                        parent_ids=[message_item.id],
                        provenance={"provider": provider, "role": role, "message_index": message_index},
                    )
                )

    items.extend(_tool_definitions(tools, run_id=run_id, stage=stage, provider=provider))
    envelope = ContextIR(items=items)
    if runtime_source:
        from .runtime_source import attach_runtime_source_evidence

        envelope = attach_runtime_source_evidence(envelope, runtime_source)
    return envelope


def provider_output_ir(
    *,
    provider: str,
    response: Any,
    run_id: Optional[str] = None,
    stage: Optional[str] = None,
    runtime_source: Optional[dict[str, Any]] = None,
) -> ContextIR:
    """Parse provider response blocks into produced messages, calls, and results."""

    payload = _jsonable(response)
    items: list[ContextIRItem] = []
    content = payload.get("content") if isinstance(payload, dict) else None
    if not isinstance(content, list) and isinstance(payload, dict):
        # OpenAI Responses returns typed output items at the top level.
        output = payload.get("output")
        if isinstance(output, list):
            content = output
    if not isinstance(content, list) and isinstance(payload, dict):
        choices = payload.get("choices")
        if isinstance(choices, list) and choices and isinstance(choices[0], dict):
            message = choices[0].get("message")
            content = [message] if message is not None else []
    blocks = content if isinstance(content, list) else ([content] if content is not None else [])
    for block in blocks:
        block_payload = _jsonable(block)
        block_type = _block_type(block_payload)
        item_type: ContextItemType = "message"
        if block_type in {"tool_use", "tool_call", "function_call"}:
            item_type = "tool_call"
        elif block_type in {"tool_result", "function_call_output"}:
            item_type = "tool_result"
        item = context_item(
            item_type,
            block_payload,
            ordinal=len(items),
            run_id=run_id,
            stage=stage,
            source=f"{provider}.response",
            selection="produced",
            provenance={"provider": provider, "response_id": payload.get("id") if isinstance(payload, dict) else None},
        )
        items.append(item)
        if item_type == "message" and isinstance(block_payload, dict):
            tool_calls = block_payload.get("tool_calls")
            if isinstance(tool_calls, list):
                for tool_call in tool_calls:
                    items.append(
                        context_item(
                            "tool_call",
                            tool_call,
                            ordinal=len(items),
                            run_id=run_id,
                            stage=stage,
                            source=f"{provider}.response.tool_calls",
                            parent_ids=[item.id],
                            selection="produced",
                            provenance={
                                "provider": provider,
                                "response_id": payload.get("id") if isinstance(payload, dict) else None,
                            },
                        )
                    )
            function_call = block_payload.get("function_call")
            if isinstance(function_call, dict):
                items.append(
                    context_item(
                        "tool_call",
                        function_call,
                        ordinal=len(items),
                        run_id=run_id,
                        stage=stage,
                        source=f"{provider}.response.function_call",
                        parent_ids=[item.id],
                        selection="produced",
                        provenance={
                            "provider": provider,
                            "response_id": payload.get("id") if isinstance(payload, dict) else None,
                        },
                    )
                )
    envelope = ContextIR(items=items)
    if runtime_source:
        from .runtime_source import attach_runtime_source_evidence

        envelope = attach_runtime_source_evidence(envelope, runtime_source)
    return envelope
