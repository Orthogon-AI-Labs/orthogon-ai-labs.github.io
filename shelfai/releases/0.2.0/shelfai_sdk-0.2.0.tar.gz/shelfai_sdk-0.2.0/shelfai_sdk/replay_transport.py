"""Authenticated HTTPS transport for opaque generalized replay sessions."""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional
from urllib.parse import urlparse

import httpx

from .replay_targets import (
    ReplaySession,
    ReplayTargetError,
    ReplayTargetRegistry,
    ReplayTrace,
    ReplayWorker,
)


class ReplayBackendTransport:
    """Bridge a customer replay worker to trusted ShelfAI session state."""

    def __init__(
        self,
        *,
        api_key: str,
        api_url: str,
        target_name: str = "default",
        client: Optional[httpx.Client] = None,
    ) -> None:
        if not api_key:
            raise ValueError("Replay transport requires a ShelfAI API key.")
        if not target_name:
            raise ValueError("Replay transport requires a registered target name.")
        self.api_key = api_key
        self.api_url = api_url.rstrip("/")
        parsed = urlparse(self.api_url)
        if parsed.scheme != "https" and not (
            parsed.scheme == "http" and parsed.hostname in {"127.0.0.1", "localhost", "::1"}
        ):
            raise ValueError("Replay transport requires HTTPS except for a local development server.")
        self.target_name = target_name
        self.client = client or httpx.Client(timeout=10.0)
        self._owns_client = client is None

    def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        try:
            response = self.client.request(
                method,
                f"{self.api_url}{path}",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                    **kwargs.pop("headers", {}),
                },
                **kwargs,
            )
            if response.status_code >= 400:
                try:
                    detail = response.json().get("detail", {})
                    code = detail.get("code") if isinstance(detail, dict) else None
                except Exception:
                    code = None
                raise ReplayTargetError(str(code or "replay_backend_rejected"))
            return response
        except ReplayTargetError:
            raise
        except Exception as exc:
            raise ReplayTargetError("replay_backend_unavailable") from exc

    def activate(self, replay_session: str, tenant_id: str, target_name: str) -> ReplaySession:
        """Activate once; experiment scope remains the opaque session token."""

        if target_name != self.target_name:
            raise ReplayTargetError("replay_session_target_mismatch")
        payload = self._request(
            "POST",
            "/api/replay-sessions/activate",
            json={"replay_session": replay_session, "target_name": target_name},
        ).json()
        returned_tenant = str(payload.get("tenant_id") or "")
        if returned_tenant != tenant_id:
            raise ReplayTargetError("replay_session_tenant_mismatch")
        try:
            expires_at = datetime.fromisoformat(str(payload["expires_at"]).replace("Z", "+00:00"))
            if expires_at.tzinfo is None:
                expires_at = expires_at.replace(tzinfo=timezone.utc)
        except (KeyError, TypeError, ValueError) as exc:
            raise ReplayTargetError("invalid_replay_session") from exc
        return ReplaySession(
            session_id=str(payload.get("session_id") or ""),
            tenant_id=returned_tenant,
            target_name=str(payload.get("target_name") or ""),
            experiment_scope=replay_session,
            expires_at=expires_at,
        )

    def resolve_bundle(self, replay_session: str, *, target_name: Optional[str] = None) -> dict[str, Any]:
        """Resolve experiment scope inside SDK code, never customer business code."""

        target = target_name or self.target_name
        payload = self._request(
            "POST",
            "/api/replay-sessions/bundle",
            json={"replay_session": replay_session, "target_name": target},
        ).json()
        bundle = payload.get("bundle")
        if not isinstance(bundle, dict):
            raise ReplayTargetError("invalid_replay_session")
        return payload

    def resolve_trace(self, session: ReplaySession) -> ReplayTrace:
        payload = self._request(
            "GET",
            f"/api/replay-sessions/{session.session_id}/trace",
        ).json()
        return ReplayTrace(
            trace_id=str(payload.get("trace_id") or ""),
            replay_session_id=str(payload.get("replay_session_id") or ""),
            tenant_id=str(payload.get("tenant_id") or ""),
            target_name=str(payload.get("target_name") or ""),
            sdk_captured=payload.get("sdk_captured") is True,
            persisted=payload.get("persisted") is True,
            offline=payload.get("offline") is True,
        )

    def complete(self, session_id: str, succeeded: bool) -> None:
        self._request(
            "POST",
            f"/api/replay-sessions/{session_id}/complete",
            json={"succeeded": bool(succeeded)},
        )

    def worker(
        self,
        *,
        tenant_id: Optional[str] = None,
        signing_secret: str,
        registry: ReplayTargetRegistry,
        shelf: Any,
    ) -> ReplayWorker:
        """Build the standard worker without customer-written session plumbing."""

        return ReplayWorker(
            tenant_id=tenant_id,
            signing_secret=signing_secret,
            registry=registry,
            resolve_session=self.activate,
            complete_session=self.complete,
            activate_scope=lambda replay_session, callback: shelf._run_with_replay_session(
                replay_session,
                self.target_name,
                callback,
            ),
            resolve_trace=self.resolve_trace,
        )

    def close(self) -> None:
        if self._owns_client:
            self.client.close()


__all__ = ["ReplayBackendTransport"]
