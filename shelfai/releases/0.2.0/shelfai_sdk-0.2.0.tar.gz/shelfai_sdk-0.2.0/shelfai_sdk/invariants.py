"""Invariant parsing and evaluation for the ShelfAI SDK."""

from __future__ import annotations

from dataclasses import dataclass
import operator
import re
from typing import Callable, Dict, List, Optional

from .snapshot import Context

_OPERATORS = {
    "<=": operator.le,
    ">=": operator.ge,
    "<": operator.lt,
    ">": operator.gt,
    "==": operator.eq,
}

_METRIC_RULE = re.compile(r"^(token_count|chunk_count|message_count)\s*(<=|>=|==|<|>)\s*(\d+)$")
_PRESENCE_RULE = re.compile(r"^chunk:([A-Za-z0-9._:-]+)\s+must\s+be\s+present$")


@dataclass
class InvariantCheck:
    name: str
    severity: str
    passed: bool
    message: str
    rule: str


@dataclass
class Invariant:
    name: str
    rule: str
    severity: str
    checker: Callable[[Context, dict[str, list[str]]], tuple[bool, str]]

    @classmethod
    def parse(cls, rule: str, severity: str = "warning") -> "Invariant":
        stripped = rule.strip()
        metric_match = _METRIC_RULE.match(stripped)
        if metric_match:
            metric, op_symbol, raw_value = metric_match.groups()
            comparator = _OPERATORS[op_symbol]
            expected = int(raw_value)

            def _metric_checker(context: Context, _registry: dict[str, list[str]]):
                observed = getattr(context, metric)
                passed = comparator(observed, expected)
                message = (
                    f"{metric} {op_symbol} {expected} passed"
                    if passed
                    else f"{metric} {observed} violates {metric} {op_symbol} {expected}"
                )
                return passed, message

            return cls(name=stripped, rule=stripped, severity=severity, checker=_metric_checker)

        presence_match = _PRESENCE_RULE.match(stripped)
        if presence_match:
            chunk_name = presence_match.group(1)

            def _presence_checker(context: Context, registry: dict[str, list[str]]):
                expected_ids = registry.get(chunk_name, [chunk_name])
                present = set(context.chunk_ids())
                missing = [chunk_id for chunk_id in expected_ids if chunk_id not in present]
                if not missing:
                    return True, f"Required chunk present: {chunk_name}"
                return False, f"Missing required chunk(s): {', '.join(missing)}"

            return cls(name=chunk_name, rule=stripped, severity=severity, checker=_presence_checker)

        raise ValueError(f"Unsupported invariant rule: {rule}")

    @classmethod
    def custom(
        cls,
        name: str,
        callback: Callable[[Context], tuple[bool, str]],
        severity: str = "warning",
    ) -> "Invariant":
        def _checker(context: Context, _registry: dict[str, list[str]]):
            passed, message = callback(context)
            return bool(passed), str(message)

        return cls(name=name, rule=name, severity=severity, checker=_checker)

    def check(self, context: Context, registry: Optional[Dict[str, List[str]]] = None) -> InvariantCheck:
        registry = registry or {}
        passed, message = self.checker(context, registry)
        return InvariantCheck(
            name=self.name,
            severity=self.severity,
            passed=passed,
            message=message,
            rule=self.rule,
        )
