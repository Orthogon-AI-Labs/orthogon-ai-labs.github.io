"""Read-only, secret-safe ShelfAI integration diagnostics."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from enum import Enum
import argparse
import json
import os
import re
from typing import Any, Callable, Iterable, Optional

import httpx


class DiagnosticStatus(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"
    SKIP = "skip"


@dataclass(frozen=True)
class DiagnosticCheck:
    name: str
    status: DiagnosticStatus
    message: str
    details: dict[str, Any] = field(default_factory=dict)


@dataclass
class DiagnosticReport:
    checks: list[DiagnosticCheck]
    mode: str = "local"

    @property
    def ok(self) -> bool:
        return not any(check.status is DiagnosticStatus.FAIL for check in self.checks)

    @property
    def complete(self) -> bool:
        return self.ok and not any(check.status is DiagnosticStatus.SKIP for check in self.checks)

    def safe_dict(self) -> dict[str, Any]:
        return _scrub({"mode": self.mode, "ok": self.ok, "complete": self.complete, "checks": [asdict(c) for c in self.checks]})


@dataclass
class DiagnosticProbes:
    checks: list[Callable[[], DiagnosticCheck]] = field(default_factory=list)


_SENSITIVE_KEY = re.compile(
    r"(?:authorization|cookie|password|passphrase|secret|token|credential|api[_-]?key|client[_-]?secret|private[_-]?key|signing[_-]?key|session[_-]?(?:key|cookie)|webhook[_-]?secret)$",
    re.I,
)
_AUTH = re.compile(r"\b(?:Bearer|Basic)\s+[A-Za-z0-9._~+\-/=]+", re.I)
_PEM = re.compile(r"-----BEGIN [^-]*PRIVATE KEY-----.*?-----END [^-]*PRIVATE KEY-----", re.S)
_URI_USERINFO = re.compile(r"(\b[a-z][a-z0-9+.-]*://)[^/@\s]+@", re.I)
_QUERY_SECRET = re.compile(r"([?&](?:[^=&]*(?:token|secret|password|key|credential)[^=&]*)=)[^&#\s]+", re.I)
_ASSIGNMENT_SECRET = re.compile(
    r"\b((?:client[_-]?secret|access[_-]?token|refresh[_-]?token|api[_-]?key|password|passphrase|private[_-]?key|signing[_-]?key|session[_-]?(?:key|cookie)|webhook[_-]?secret|credentials?|authorization)\s*[:=]\s*)[^\s,;]+",
    re.I,
)


def _scrub_text(value: str) -> str:
    value = _PEM.sub("[REDACTED_SECRET]", value)
    value = _AUTH.sub("[REDACTED_SECRET]", value)
    value = _URI_USERINFO.sub(r"\1[REDACTED_SECRET]@", value)
    value = _QUERY_SECRET.sub(r"\1[REDACTED_SECRET]", value)
    return _ASSIGNMENT_SECRET.sub(r"\1[REDACTED_SECRET]", value)


def _scrub(value: Any, key: str = "") -> Any:
    if _SENSITIVE_KEY.search(key):
        return "[REDACTED_SECRET]"
    if isinstance(value, dict):
        return {str(k): _scrub(v, str(k)) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_scrub(item) for item in value]
    if isinstance(value, str):
        return _scrub_text(value)
    return value


def _client_shape_check(client: Any) -> DiagnosticCheck:
    if client is None:
        return DiagnosticCheck("wrapper_compatibility", DiagnosticStatus.SKIP, "No provider client was supplied.")
    try:
        anthropic = callable(getattr(getattr(client, "messages", None), "create", None))
        chat = getattr(client, "chat", None)
        openai_chat = callable(getattr(getattr(chat, "completions", None), "create", None))
        openai_responses = callable(getattr(getattr(client, "responses", None), "create", None))
    except Exception as exc:
        return DiagnosticCheck(
            "wrapper_compatibility",
            DiagnosticStatus.WARN,
            "Provider shape could not be inspected safely.",
            {"error_type": type(exc).__name__},
        )
    supported = anthropic or openai_chat or openai_responses
    return DiagnosticCheck(
        "wrapper_compatibility",
        DiagnosticStatus.PASS if supported else DiagnosticStatus.WARN,
        "Supported provider client detected." if supported else "Client is unchanged; use a framework adapter or supported raw provider.",
    )


def doctor(*, client: Any = None) -> DiagnosticReport:
    """Run local-only checks. No model or network operation is performed."""

    configured = bool(os.getenv("SHELFAI_API_KEY") and os.getenv("SHELFAI_AGENT_ID"))
    checks = [
        DiagnosticCheck(
            "configuration",
            DiagnosticStatus.PASS if configured else DiagnosticStatus.WARN,
            "Required ShelfAI configuration is present." if configured else "ShelfAI credentials are not configured; the integration will remain inactive.",
        )
    ]
    if client is not None:
        checks.append(_client_shape_check(client))
    return DiagnosticReport(checks)


def read_only_backend_probes(
    trace_id: str,
    *,
    api_url: Optional[str] = None,
    api_key: Optional[str] = None,
    http_client: Optional[Any] = None,
) -> DiagnosticProbes:
    """Build GET-only probes for one explicitly named, existing run."""

    base = (api_url or os.getenv("SHELFAI_API_URL") or "http://127.0.0.1:8000").rstrip("/")
    key = api_key or os.getenv("SHELFAI_API_KEY") or ""
    client = http_client or httpx.Client(timeout=5.0)
    cache: dict[str, Any] = {}

    def check(name: str, path: str) -> Callable[[], DiagnosticCheck]:
        def run() -> DiagnosticCheck:
            try:
                if path not in cache:
                    response = client.get(f"{base}{path}", headers={"Authorization": f"Bearer {key}"})
                    cache[path] = response
                response = cache[path]
                ok = 200 <= int(response.status_code) < 300
                return DiagnosticCheck(name, DiagnosticStatus.PASS if ok else DiagnosticStatus.FAIL, "Read-only endpoint verified." if ok else "Read-only endpoint did not verify.", {"status_code": int(response.status_code)})
            except Exception as exc:
                return DiagnosticCheck(name, DiagnosticStatus.FAIL, "Read-only endpoint could not be reached.", {"error_type": type(exc).__name__})
        return run

    return DiagnosticProbes([
        check("replay_hook", "/api/context/replay-hook"),
        check("trace", f"/api/context/traces/{trace_id}"),
        check("context_ir", f"/api/context/traces/{trace_id}/ir"),
        check("run_graph", f"/api/context/runs/{trace_id}/graph"),
    ])


def verify_integration(
    trace_id: Optional[str] = None,
    *,
    probes: Optional[DiagnosticProbes] = None,
    client: Any = None,
    **kwargs: Any,
) -> DiagnosticReport:
    """Verify one existing run using GET requests only."""

    resolved = trace_id or os.getenv("SHELFAI_VERIFY_TRACE_ID")
    checks: list[DiagnosticCheck] = []
    # Deterministically prove the central fail-open promise without telemetry.
    if client is not None:
        checks.append(_client_shape_check(client))
        from .integration import integrate
        handle = integrate(client=client, enabled=False)
        checks.append(DiagnosticCheck("disabled_fail_open", DiagnosticStatus.PASS if handle.client is client else DiagnosticStatus.FAIL, "Disabled integration preserves the exact client object."))
    if not resolved:
        checks.append(DiagnosticCheck("existing_trace", DiagnosticStatus.SKIP, "Provide --trace-id to run read-only backend verification."))
        return DiagnosticReport(checks, mode="read_only")
    selected = probes or read_only_backend_probes(resolved, **kwargs)
    for probe in selected.checks:
        try:
            checks.append(probe())
        except Exception as exc:
            checks.append(DiagnosticCheck("probe", DiagnosticStatus.FAIL, "Diagnostic probe failed safely.", {"error_type": type(exc).__name__}))
    return DiagnosticReport(checks, mode="read_only")


def _print_report(report: DiagnosticReport) -> None:
    print(json.dumps(report.safe_dict(), indent=2, default=str))


def main(argv: Optional[Iterable[str]] = None) -> int:
    parser = argparse.ArgumentParser(prog="shelfai")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("doctor")
    verify = sub.add_parser("verify-integration")
    verify.add_argument("--trace-id")
    args = parser.parse_args(list(argv) if argv is not None else None)
    report = doctor() if args.command == "doctor" else verify_integration(args.trace_id)
    _print_report(report)
    if not report.ok:
        return 1
    return 0 if report.complete else 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
