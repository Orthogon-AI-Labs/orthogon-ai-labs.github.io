"""Local, owner-approved handoff instrumentation proposals.

The scanner is intentionally deterministic and network-free.  It identifies
likely context assembly assignments, shows the exact neutral observer patch,
and applies only one proposal whose ID the owner explicitly approves.
"""

from __future__ import annotations

import argparse
import ast
from dataclasses import asdict, dataclass
import hashlib
import json
from pathlib import Path
import re
from typing import Any, Iterable


CONTEXT_NAMES = {
    "assignment",
    "brief",
    "context",
    "handoff",
    "input",
    "instruction",
    "instructions",
    "message",
    "messages",
    "payload",
    "prompt",
    "request",
    "task",
}
EXCLUDED_PARTS = {
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    ".shelfai-pro",
    ".venv",
    "__pycache__",
    "build",
    "dist",
    "node_modules",
    "venv",
}
OBSERVER_HELPER = "observe_handoff"


@dataclass(frozen=True)
class HandoffSuggestion:
    proposal_id: str
    path: str
    line: int
    symbol: str
    target: str
    before: str
    after: str
    observer_import: str
    confidence: float
    rationale: str
    direct_mutation: bool = False
    approval_required: bool = True

    def payload(self) -> dict[str, Any]:
        return asdict(self)


def _valid_observer_import(value: str) -> str:
    normalized = str(value or "").strip()
    if not re.fullmatch(r"[A-Za-z_]\w*(?:\.[A-Za-z_]\w*)*", normalized):
        raise ValueError("observer import must be a dotted Python module path")
    return normalized


def _is_excluded(path: Path) -> bool:
    return any(part in EXCLUDED_PARTS for part in path.parts)


def _python_files(workspace: Path) -> Iterable[Path]:
    for path in sorted(workspace.rglob("*.py")):
        relative = path.relative_to(workspace)
        if _is_excluded(relative) or path.is_symlink():
            continue
        try:
            if path.stat().st_size <= 256_000:
                yield path
        except OSError:
            continue


def _target_name(node: ast.Assign | ast.AnnAssign) -> str | None:
    target: ast.expr | None
    if isinstance(node, ast.Assign):
        target = node.targets[0] if len(node.targets) == 1 else None
    else:
        target = node.target
    return target.id if isinstance(target, ast.Name) else None


def _looks_like_context(name: str) -> bool:
    words = {part for part in name.lower().split("_") if part}
    return bool(words & CONTEXT_NAMES)


def _call_symbol(call: ast.Call) -> str | None:
    if isinstance(call.func, ast.Name):
        return call.func.id
    if isinstance(call.func, ast.Attribute):
        return ast.unparse(call.func)
    return None


def _used_after(scope: ast.AST, name: str, line: int) -> bool:
    return any(
        isinstance(node, ast.Name)
        and isinstance(node.ctx, ast.Load)
        and node.id == name
        and int(getattr(node, "lineno", 0) or 0) > line
        for node in ast.walk(scope)
    )


def _byte_offset(source: bytes, line: int, column: int) -> int:
    lines = source.splitlines(keepends=True)
    return sum(len(item) for item in lines[: line - 1]) + column


def _replacement(call: ast.Call, *, target: str, path: str, indent: str) -> str:
    expression = ast.unparse(call)
    symbol = _call_symbol(call)
    derived = ast.unparse(call.args[0]) if call.args else None
    nested = f"{indent}    "
    lines = [f"{OBSERVER_HELPER}(", f"{nested}{expression},"]
    if derived:
        lines.append(f"{nested}derived_from={derived},")
    if symbol:
        lines.append(f"{nested}materialized_by={symbol},")
    lines.extend(
        [
            f"{nested}source_path={json.dumps(path)},",
            f"{nested}name={json.dumps(f'{target} handoff')},",
            f"{indent})",
        ]
    )
    return "\n".join(lines)


def discover_handoff_suggestions(
    workspace: str | Path,
    *,
    observer_import: str = "shelfai_observer",
) -> list[HandoffSuggestion]:
    """Return reviewable proposals without writing to the workspace."""

    root = Path(workspace).expanduser().resolve()
    module = _valid_observer_import(observer_import)
    suggestions: list[HandoffSuggestion] = []
    if not root.is_dir():
        return suggestions

    for path in _python_files(root):
        try:
            text = path.read_text(encoding="utf-8")
            tree = ast.parse(text, filename=str(path))
        except (OSError, UnicodeError, SyntaxError):
            continue
        relative = path.relative_to(root).as_posix()
        lines = text.splitlines()
        scopes = [tree, *(node for node in ast.walk(tree) if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)))]
        seen: set[tuple[int, int]] = set()
        for scope in scopes:
            for node in ast.walk(scope):
                if not isinstance(node, (ast.Assign, ast.AnnAssign)) or not isinstance(node.value, ast.Call):
                    continue
                key = (node.value.lineno, node.value.col_offset)
                if key in seen:
                    continue
                seen.add(key)
                target = _target_name(node)
                symbol = _call_symbol(node.value)
                if not target or not symbol or symbol.endswith(OBSERVER_HELPER):
                    continue
                if not _looks_like_context(target) or not _used_after(scope, target, int(node.end_lineno or node.lineno)):
                    continue
                before = ast.get_source_segment(text, node.value)
                if not before:
                    continue
                line_text = lines[node.value.lineno - 1] if node.value.lineno <= len(lines) else ""
                indent = line_text[: len(line_text) - len(line_text.lstrip())]
                after = _replacement(node.value, target=target, path=relative, indent=indent)
                digest = hashlib.sha256(
                    f"{relative}:{node.value.lineno}:{before}:{module}".encode("utf-8")
                ).hexdigest()[:12]
                suggestions.append(
                    HandoffSuggestion(
                        proposal_id=f"handoff_{digest}",
                        path=relative,
                        line=node.value.lineno,
                        symbol=symbol,
                        target=target,
                        before=before,
                        after=after,
                        observer_import=module,
                        confidence=0.86 if node.value.args else 0.72,
                        rationale=(
                            f"{target} is assembled by {symbol} and then consumed later in the same scope. "
                            "The proposed neutral observer preserves the value and gives ShelfAI a durable source locator."
                        ),
                    )
                )
    return sorted(suggestions, key=lambda item: (item.path, item.line, item.proposal_id))[:50]


def _import_offset(tree: ast.Module, source: bytes) -> int:
    insertion_line = 0
    body = list(tree.body)
    index = 0
    if body and isinstance(body[0], ast.Expr) and isinstance(body[0].value, ast.Constant) and isinstance(body[0].value.value, str):
        insertion_line = int(body[0].end_lineno or body[0].lineno)
        index = 1
    while index < len(body):
        node = body[index]
        if isinstance(node, ast.ImportFrom) and node.module == "__future__":
            insertion_line = int(node.end_lineno or node.lineno)
            index += 1
            continue
        break
    if insertion_line == 0:
        return 0
    lines = source.splitlines(keepends=True)
    return sum(len(item) for item in lines[:insertion_line])


def approve_handoff_suggestion(
    workspace: str | Path,
    proposal_id: str,
    *,
    observer_import: str = "shelfai_observer",
) -> dict[str, Any]:
    """Apply exactly one still-current proposal after explicit owner approval."""

    root = Path(workspace).expanduser().resolve()
    module = _valid_observer_import(observer_import)
    suggestion = next(
        (item for item in discover_handoff_suggestions(root, observer_import=module) if item.proposal_id == proposal_id),
        None,
    )
    if suggestion is None:
        raise ValueError("proposal not found or source changed; scan again before approving")
    path = (root / suggestion.path).resolve()
    if root not in path.parents or not path.is_file():
        raise ValueError("proposal path is outside the approved workspace")

    source = path.read_bytes()
    text = source.decode("utf-8")
    tree = ast.parse(text, filename=str(path))
    candidate = next(
        (
            node.value
            for node in ast.walk(tree)
            if isinstance(node, (ast.Assign, ast.AnnAssign))
            and isinstance(node.value, ast.Call)
            and node.value.lineno == suggestion.line
            and ast.get_source_segment(text, node.value) == suggestion.before
        ),
        None,
    )
    if candidate is None or candidate.end_lineno is None or candidate.end_col_offset is None:
        raise ValueError("proposal source no longer matches; scan again before approving")

    start = _byte_offset(source, candidate.lineno, candidate.col_offset)
    end = _byte_offset(source, candidate.end_lineno, candidate.end_col_offset)
    patches: list[tuple[int, int, bytes]] = [(start, end, suggestion.after.encode("utf-8"))]
    import_pattern = re.compile(
        rf"^\s*from\s+{re.escape(module)}\s+import\s+[^\n]*\b{OBSERVER_HELPER}\b",
        flags=re.MULTILINE,
    )
    helper_defined = re.search(rf"^\s*def\s+{OBSERVER_HELPER}\s*\(", text, flags=re.MULTILINE)
    if not import_pattern.search(text) and not helper_defined:
        offset = _import_offset(tree, source)
        patches.append((offset, offset, f"from {module} import {OBSERVER_HELPER}\n".encode("utf-8")))
    for patch_start, patch_end, replacement in sorted(patches, key=lambda item: item[0], reverse=True):
        source = source[:patch_start] + replacement + source[patch_end:]
    path.write_bytes(source)
    return {
        "command": "instrument",
        "status": "applied",
        "proposal": suggestion.payload(),
        "changed_files": [suggestion.path],
        "direct_mutation": True,
        "approved": True,
        "next_action": "Review the local diff and run the existing workflow tests before committing.",
    }


def _scan_payload(workspace: Path, observer_import: str) -> dict[str, Any]:
    suggestions = discover_handoff_suggestions(workspace, observer_import=observer_import)
    return {
        "command": "instrument",
        "status": "review_required" if suggestions else "no_candidates",
        "workspace": str(workspace.expanduser().resolve()),
        "suggestions": [item.payload() for item in suggestions],
        "direct_mutation": False,
        "approval_required": True,
        "privacy": "Local deterministic scan; no source code was transmitted.",
        "next_action": (
            "Approve one proposal ID with --approve after reviewing its before/after patch."
            if suggestions
            else "Run a real wrapped workflow first; automatic runtime lineage may already cover the handoff."
        ),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Let Shelfy propose owner-approved handoff annotations.")
    parser.add_argument("workspace", nargs="?", default=".", type=Path)
    parser.add_argument("--observer-import", default="shelfai_observer")
    parser.add_argument("--approve", metavar="PROPOSAL_ID")
    args = parser.parse_args()
    try:
        payload = (
            approve_handoff_suggestion(
                args.workspace,
                args.approve,
                observer_import=args.observer_import,
            )
            if args.approve
            else _scan_payload(args.workspace, args.observer_import)
        )
    except (OSError, SyntaxError, ValueError) as exc:
        payload = {"command": "instrument", "status": "blocked", "error_type": type(exc).__name__}
        print(json.dumps(payload, indent=2, sort_keys=True))
        raise SystemExit(2) from exc
    print(json.dumps(payload, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
