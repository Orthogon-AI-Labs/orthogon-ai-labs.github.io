"""Framework-neutral helpers for customer-owned ShelfAI replays."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import hmac
import inspect
import json
import threading
from typing import Any, Callable, Mapping, Optional


class ReplayRequestError(ValueError):
    """Raised when an inbound replay request is invalid or cannot be run safely."""


@dataclass(frozen=True)
class ReplayRequest:
    """Metadata-only request to run one Workbench experiment."""

    experiment_id: str
    baseline_trace_id: str
    agent_id: str
    bundle_path: str
    verify_path: str
    delivery_id: Optional[str] = None
    requested_at: Optional[str] = None


ReplayCallback = Callable[..., Any]
ActivateExperiment = Callable[[str, Callable[[], Any]], Any]
MAX_REPLAY_BODY_BYTES = 64 * 1024


def _header(headers: Mapping[str, Any], name: str) -> str:
    expected = name.lower()
    for key, value in headers.items():
        if str(key).lower() == expected:
            if isinstance(value, (list, tuple)):
                return str(value[0]) if value else ""
            return str(value or "")
    return ""


def _raw_body(body: bytes | bytearray | memoryview | str) -> bytes:
    if isinstance(body, str):
        return body.encode("utf-8")
    return bytes(body)


def verify_replay_request(
    body: bytes | bytearray | memoryview | str,
    headers: Mapping[str, Any],
    *,
    signing_secret: str,
    agent_id: str,
    now: Optional[datetime] = None,
    max_age_seconds: int = 300,
) -> ReplayRequest:
    """Verify a signed metadata-only replay request and return its typed payload."""

    if len(signing_secret) < 16:
        raise ReplayRequestError("ShelfAI replay signing secret must contain at least 16 characters.")
    raw = _raw_body(body)
    supplied = _header(headers, "X-ShelfAI-Signature")
    if supplied.startswith("sha256="):
        supplied = supplied[len("sha256=") :]
    expected = hmac.new(signing_secret.encode("utf-8"), raw, hashlib.sha256).hexdigest()
    try:
        matches = bool(supplied) and hmac.compare_digest(supplied, expected)
    except (TypeError, ValueError):
        matches = False
    if not matches:
        raise ReplayRequestError("ShelfAI replay signature is invalid.")
    try:
        payload = json.loads(raw)
    except (TypeError, ValueError, json.JSONDecodeError) as exc:
        raise ReplayRequestError("ShelfAI replay body must be valid JSON.") from exc
    if not isinstance(payload, dict):
        raise ReplayRequestError("ShelfAI replay body must be a JSON object.")
    if payload.get("version") != "1.0" or payload.get("event") != "context.experiment.replay_requested":
        raise ReplayRequestError("ShelfAI replay event is not supported.")
    if str(payload.get("agent_id") or "") != agent_id:
        raise ReplayRequestError("ShelfAI replay request is scoped to a different agent.")

    required = ("experiment_id", "baseline_trace_id", "agent_id", "bundle_path", "verify_path")
    if any(not str(payload.get(field) or "").strip() for field in required):
        raise ReplayRequestError("ShelfAI replay request is missing required metadata.")

    requested_at = str(payload.get("requested_at") or "").strip() or None
    if requested_at:
        try:
            parsed = datetime.fromisoformat(requested_at.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=timezone.utc)
        except ValueError as exc:
            raise ReplayRequestError("ShelfAI replay request has an invalid timestamp.") from exc
        age = abs(((now or datetime.now(timezone.utc)) - parsed.astimezone(timezone.utc)).total_seconds())
        if age > max_age_seconds:
            raise ReplayRequestError("ShelfAI replay request has expired.")

    return ReplayRequest(
        experiment_id=str(payload["experiment_id"]),
        baseline_trace_id=str(payload["baseline_trace_id"]),
        agent_id=str(payload["agent_id"]),
        bundle_path=str(payload["bundle_path"]),
        verify_path=str(payload["verify_path"]),
        delivery_id=str(payload.get("delivery_id") or "").strip() or None,
        requested_at=requested_at,
    )


def _invoke(callback: ReplayCallback, request: ReplayRequest) -> Any:
    try:
        signature = inspect.signature(callback)
        accepts_request = any(
            parameter.kind in (parameter.POSITIONAL_ONLY, parameter.POSITIONAL_OR_KEYWORD)
            for parameter in signature.parameters.values()
        )
    except (TypeError, ValueError):
        accepts_request = True
    return callback(request) if accepts_request else callback()


def _trace_id(result: Any) -> str:
    if isinstance(result, str):
        value = result
    elif isinstance(result, Mapping):
        value = str(result.get("replay_trace_id") or result.get("trace_id") or "")
    else:
        value = str(getattr(result, "replay_trace_id", None) or getattr(result, "trace_id", None) or "")
    value = value.strip()
    if not value:
        raise ReplayRequestError("Replay workflow must return its ShelfAI trace ID.")
    return value


class ReplayHandler:
    """Callable core used by web-framework adapters at one application endpoint."""

    def __init__(
        self,
        *,
        agent_id: str,
        signing_secret: str,
        callback: ReplayCallback,
        activate_experiment: ActivateExperiment,
    ) -> None:
        self.agent_id = agent_id
        self.signing_secret = signing_secret
        self.callback = callback
        self.activate_experiment = activate_experiment
        self._seen_deliveries: set[str] = set()
        self._delivery_lock = threading.Lock()

    async def __call__(
        self,
        body: bytes | bytearray | memoryview | str,
        headers: Mapping[str, Any],
    ) -> dict[str, str]:
        request = verify_replay_request(
            body,
            headers,
            signing_secret=self.signing_secret,
            agent_id=self.agent_id,
        )
        if request.delivery_id:
            with self._delivery_lock:
                if request.delivery_id in self._seen_deliveries:
                    raise ReplayRequestError("ShelfAI replay delivery has already been handled.")
                self._seen_deliveries.add(request.delivery_id)
                if len(self._seen_deliveries) > 1024:
                    self._seen_deliveries.pop()

        if inspect.iscoroutinefunction(self.callback):
            async def execute_callback():
                return await _invoke(self.callback, request)
        else:
            def execute_callback():
                return _invoke(self.callback, request)

        try:
            result = self.activate_experiment(
                request.experiment_id,
                execute_callback,
            )
            if inspect.isawaitable(result):
                result = await result
            return {"replay_trace_id": _trace_id(result)}
        except Exception:
            if request.delivery_id:
                with self._delivery_lock:
                    self._seen_deliveries.discard(request.delivery_id)
            raise

    def asgi(self):
        """Return a dependency-free ASGI callable that preserves the signed raw body."""

        return _LegacyReplayASGIApp(self)

    async def serve(self, scope, receive, send) -> None:
        handler = self

        async def app(scope, receive, send):
            if scope.get("type") != "http" or scope.get("method") != "POST":
                await _asgi_json(send, 405, {"error": "method_not_allowed"})
                return
            headers = {
                key.decode("latin-1"): value.decode("latin-1")
                for key, value in scope.get("headers", [])
            }
            content_length = _header(headers, "content-length")
            if content_length:
                try:
                    if int(content_length) > MAX_REPLAY_BODY_BYTES:
                        await _asgi_json(send, 413, {"error": "replay_request_too_large"})
                        return
                except ValueError:
                    pass
            chunks: list[bytes] = []
            total = 0
            while True:
                message = await receive()
                if message.get("type") == "http.disconnect":
                    return
                chunk = message.get("body", b"")
                total += len(chunk)
                if total > MAX_REPLAY_BODY_BYTES:
                    await _asgi_json(send, 413, {"error": "replay_request_too_large"})
                    return
                chunks.append(chunk)
                if not message.get("more_body", False):
                    break
            try:
                result = await handler(b"".join(chunks), headers)
            except ReplayRequestError:
                await _asgi_json(send, 401, {"error": "invalid_replay_request"})
                return
            except Exception:
                await _asgi_json(send, 500, {"error": "replay_failed"})
                return
            await _asgi_json(send, 200, result)

        await app(scope, receive, send)


class _LegacyReplayASGIApp:
    """ASGI callable object so ``add_route`` and ``mount`` both work."""

    def __init__(self, handler: ReplayHandler) -> None:
        self._handler = handler

    async def __call__(self, scope, receive, send) -> None:
        await self._handler.serve(scope, receive, send)


async def _asgi_json(send, status: int, payload: Mapping[str, Any]) -> None:
    body = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    await send(
        {
            "type": "http.response.start",
            "status": status,
            "headers": [
                (b"content-type", b"application/json"),
                (b"content-length", str(len(body)).encode("ascii")),
            ],
        }
    )
    await send({"type": "http.response.body", "body": body})
