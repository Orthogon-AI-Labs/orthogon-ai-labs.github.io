"""Background transport for the ShelfAI SDK."""

from __future__ import annotations

import json
import logging
import threading
import time
from typing import Any, Optional

import httpx

from .capture_mode import DEFAULT_CAPTURE_MODE, sanitize_event_for_capture_mode
from .queue import OfflineQueue

logger = logging.getLogger(__name__)


class Transport:
    def __init__(
        self,
        api_key: str,
        agent_id: str,
        api_url: str,
        offline_queue: OfflineQueue,
        batch_size: int = 100,
        batch_interval_seconds: int = 5,
        flush_offline_interval_seconds: int = 30,
        client: Optional[httpx.Client] = None,
        start_background_thread: bool = True,
        capture_mode: str = DEFAULT_CAPTURE_MODE,
    ):
        self.api_key = api_key
        self.agent_id = agent_id
        self.api_url = api_url.rstrip("/")
        self.offline_queue = offline_queue
        self.batch_size = batch_size
        self.batch_interval_seconds = batch_interval_seconds
        self.flush_offline_interval_seconds = flush_offline_interval_seconds
        self.client = client or httpx.Client(timeout=5.0)
        self.capture_mode = capture_mode
        self._buffer: list[dict[str, Any]] = []
        self._lock = threading.Lock()
        self._last_flush_at = time.monotonic()
        self._last_offline_flush_at = 0.0
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        if start_background_thread:
            self._thread = threading.Thread(target=self._run_loop, daemon=True)
            self._thread.start()

    def enqueue_event(self, event: dict[str, Any]) -> None:
        try:
            with self._lock:
                self._buffer.append(sanitize_event_for_capture_mode(dict(event), self.capture_mode))
        except Exception as exc:
            logger.warning("ShelfAI enqueue_event (%s)", type(exc).__name__)

    def _run_loop(self) -> None:
        while not self._stop.wait(0.25):
            self.flush_if_needed()

    def flush_if_needed(self) -> None:
        try:
            events = None
            with self._lock:
                age = time.monotonic() - self._last_flush_at
                if self._buffer and (len(self._buffer) >= self.batch_size or age >= self.batch_interval_seconds):
                    events = list(self._buffer)
                    self._buffer.clear()
                    self._last_flush_at = time.monotonic()
            if events:
                self._post_or_queue(events)
            if time.monotonic() - self._last_offline_flush_at >= self.flush_offline_interval_seconds:
                self.flush_offline_queue()
                self._last_offline_flush_at = time.monotonic()
        except Exception as exc:
            logger.warning("ShelfAI background_flush (%s)", type(exc).__name__)

    def flush(self) -> None:
        with self._lock:
            events = list(self._buffer)
            self._buffer.clear()
            self._last_flush_at = time.monotonic()
        if events:
            self._post_or_queue(events)
        self.flush_offline_queue()

    def _post_or_queue(self, events: list[dict[str, Any]]) -> None:
        if not events:
            return
        try:
            response = self.client.post(
                f"{self.api_url}/api/events/batch",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={"agent_id": self.agent_id, "capture_mode": self.capture_mode, "events": events},
            )
            response.raise_for_status()
            self._warn_on_capture_policy(response)
        except Exception as exc:
            logger.warning("ShelfAI flush_events (%s)", type(exc).__name__)
            for event in events:
                self.offline_queue.enqueue(self.agent_id, event)

    def flush_offline_queue(self) -> None:
        queued = self.offline_queue.load_batch(limit=self.batch_size)
        if not queued:
            return
        events = []
        row_ids = []
        for item in queued:
            row_ids.append(item.row_id)
            events.append(json.loads(item.event_json))
        try:
            response = self.client.post(
                f"{self.api_url}/api/events/batch",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json",
                },
                json={"agent_id": self.agent_id, "capture_mode": self.capture_mode, "events": events},
            )
            response.raise_for_status()
            self._warn_on_capture_policy(response)
            self.offline_queue.mark_success(row_ids)
        except Exception as exc:
            self.offline_queue.mark_failure(row_ids, type(exc).__name__)

    @staticmethod
    def _warn_on_capture_policy(response: httpx.Response) -> None:
        try:
            policy = response.json().get("capture_policy", {})
            warning = policy.get("warning") if isinstance(policy, dict) else None
            if isinstance(warning, dict) and warning.get("code") == "capture_mode_mismatch":
                logger.warning("ShelfAI capture_policy_mismatch (CapturePolicyMismatch)")
        except Exception:
            # Older servers and non-JSON test doubles remain compatible.
            return

    def close(self) -> None:
        self._stop.set()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        try:
            self.flush()
        finally:
            self.client.close()
