"""Fail-open helpers: telemetry must never break a customer's provider call."""

from __future__ import annotations

import logging
from typing import Any, Callable, Optional, TypeVar

logger = logging.getLogger("shelfai_sdk")

_T = TypeVar("_T")
_warned: set[str] = set()


def telemetry_guard(operation: str, fn: Callable[..., _T], *args: Any, default: Any = None, **kwargs: Any) -> Optional[_T]:
    """Run one telemetry step; swallow and log any failure exactly once per shape.

    The provider call itself is never wrapped by this helper. Only ShelfAI's
    own observation work (IR extraction, event emission, output recording) is,
    so a bug in the observer cannot surface as an application exception.
    """

    try:
        return fn(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001 - deliberate fail-open boundary
        key = f"{operation}:{type(exc).__name__}"
        if key not in _warned:
            _warned.add(key)
            logger.warning(
                "ShelfAI telemetry step '%s' was skipped (%s); the provider call was not affected.",
                operation,
                type(exc).__name__,
            )
        return default


def reset_guard_warnings() -> None:
    """Test helper: allow the same warning to be logged again."""

    _warned.clear()


__all__ = ["telemetry_guard", "reset_guard_warnings", "logger"]
